local io = ba.openio(_G.diskIOName)
local Chart = io:dofile('platform/.lua/data-access/Chart.lua')

function Chart.getChartVariables(chartName)
    local env = luasql.sqlite()
    local connection = env:connect(Constants.DB_PATH, 'READONLY')
    local cursor, errorMsg = nil
	local chartVars = {}
	local resultObj = {}
	resultObj.variables = {}

    if chartName ~= nil and chartName:len() > 0 then
        -- Build Prepared Statement
        cursor =
			connection:prepare(
				[[
					SELECT *
					FROM   chart_variable, chart
					WHERE  chart_variable.chart_name = (?)
					AND chart.name = chart_variable.chart_name
				]])
        if not cursor then
            return nil, ErrorCodes.INVALID_SQL_SYNTAX
        end

        -- Bind chart to the prepared statement
        cursor:bind{{'TEXT', chartName}}
    else
        return nil, ErrorObject.new(ErrorCodes.CHART_NAME_REQUIRED)
    end

    local exec = cursor:execute()

	if exec then
		-- Grab results in a table
		cursor:fetch(chartVars, 'a')

		if chartVars then
			resultObj.plotFrequency = tonumber(chartVars.plot_frequency)
			resultObj.autoScale = tonumber(chartVars.auto_scale)
			resultObj.yMin = tonumber(chartVars.y_min)
			resultObj.yMax = tonumber(chartVars.y_max)
			resultObj.plotPoints = tonumber(chartVars.plot_points)
		end

		-- While chart is not nil and is not an empty table
		while (chartVars and next(chartVars)) do
			local obj = {
                id        = chartVars.mnemonic,
                mnemonic  = chartVars.mnemonic,
                unit      = chartVars.unit,
                scale     = chartVars.scale,
                datatype = chartVars.data_type,
                readonly = chartVars.read_only
			}
			table.insert(resultObj.variables, gf.deepCopy(obj))
			-- Grab results in a table
			chartVars = cursor:fetch(chartVars, 'a')
		end
	else
        resultObj = false
		errorMsg = ErrorObject.new(ErrorCodes.GET_CHART_FAILED)
    end

    -- Close database connection as soon as it is no longer needed
    if not cursor:close() then
        trace('FAILED TO CLOSE CURSOR')
    end

    if not connection:close() then
        trace('FAILED TO CLOSE SQLITE CONNECTION')
    end

    if not env:close() then
        trace('FAILED TO CLOSE SQLITE ENVIRONMENT')
    end

	if resultObj.variables then
		-- TODO possibly make a switch here to use the readparamsnoncons after first poll...
		-- resultObj.variables = Variable.getVariableValues(resultObj.variables)
		-- Or, make a separate call and handle it on the front end???
		-- Currently, it is polling on the GetParamsDescription, but it should be polling on ReadParamsNonCons...
		resultObj.variables = Chart.getVariableDesc(resultObj.variables)
	end

    return resultObj, errorMsg
end


function Chart.getVariableDesc(variables)
    local errorMsg = nil

    local result = {}
    local addresses = {}
    local mVariables = {}

    if ParametersTable ~= nil then
        for i,v in pairs(variables) do
            local mAddress = ParametersTable['parameterlist'][v.mnemonic]
            if(mAddress and mAddress:len() > 0) then
                mAddress = tonumber(mAddress)
                table.insert( addresses, mAddress )
                table.insert( mVariables, v.mnemonic ) --so, we know which value is for which mnemonic...
            end
        end
    end


    --After building the array of addresses above, make a call to adl.ReadParamsNonCons(....)
    if #addresses > 0 then
        local response, errorMsg = ADL.GetParamsDescription(248, addresses)

        if response then
            for i=1, #response do
                local tmpTbl = response[i]
                tmpTbl.id = mVariables[i]
                tmpTbl.mnemonic = mVariables[i]
                table.insert(result, tmpTbl)
            end
        end
    end

    return result, errorMsg
end


function Chart.addVariablesToChart(variables, chartName)
	local result = false
	local errorMsg = nil
	-- Check input types
    if (type(chartName) ~= 'string') or (type(variables) ~= 'table') then
        return result, ErrorCodes.INVALID_REQUEST
    end
	-- Check to make sure variables and chartName are the correct length
	if #variables < Constants.MIN_NUM_VARS_PER_CHART or #variables > Constants.MAX_NUM_VARS_PER_CHART then
        return result, ErrorObject.new(ErrorCodes.NUM_CHART_VARS_OUT_OF_RANGE, '', nil, HTTPStatusCode.BadRequest)
	elseif chartName:len() < Constants.MIN_CHART_NAME_LENGTH
		or chartName:len() > Constants.MAX_CHART_NAME_LENGTH then
		return result, ErrorObject.new(ErrorCodes.INVALID_CHART_NAME_LENGTH)
	end

	if #variables > 0 then
		local env = luasql.sqlite()
		local connection = env:connect(Constants.DB_PATH)
		local isLockAcquired = connection:setautocommit('IMMEDIATE', 1000)

		if isLockAcquired then
			-- Check to make sure that the table actually exists
			local chartExists = false
			chartExists, errorMsg = Chart.exists(connection, chartName)
			if chartExists then
				local varsExist = false
				varsExist, errorMsg = Variable.variablesExist(connection, variables)
				if varsExist then
					local numVarsExisting = 0
					numVarsExisting, errorMsg =
						Chart.getNumberOfVariablesInChart(connection, chartName)
					if not errorMsg then
						local cursor = nil
						local maxVarsToAdd = Constants.MAX_NUM_VARS_PER_CHART + 1 - numVarsExisting
						for el,var in pairs(variables) do
							--We can only support 5 variables at a time
							if(el < maxVarsToAdd) then
								cursor = connection:prepare(
									[[INSERT INTO chart_variable (mnemonic, chart_name)
									VALUES (?, ?)]])
								cursor:bind{
									{'TEXT', var.mnemonic},
									{'TEXT', chartName}
								}
								local varsAdded, errorMsg = cursor:execute()
								if(varsAdded ~= 1) then
									trace('Variable ' .. var.mnemonic ..
										' unable to be added to chart ' .. chartName .. '.')
								end
							else
								break
							end
						end

						-- Commit the transaction
						if connection:commit() then
							result = true
						else
							errorMsg = ErrorObject.new(ErrorCodes.COMMIT_FAIL)
						end

						-- Close cursor connection
						if not cursor:close() then
							trace('FAILED TO CLOSE CURSOR')
						end
					end
				elseif not varsExist and not errorMsg then
					errorMsg = ErrorObject.new(ErrorCodes.VARS_DO_NOT_EXIST)
				end
			elseif not chartExists and not errorMsg then
				errorMsg = ErrorObject.new(ErrorCodes.CHART_DOES_NOT_EXIST)
			end
		else
			errorMsg = ErrorObject.new(ErrorCodes.LOCK_FAIL)
		end
		-- Clean up
		if not connection:close() then
			trace('FAILED TO CLOSE SQLITE CONNECTION')
		end
		if not env:close() then
			trace('FAILED TO CLOSE SQLITE ENVIRONMENT')
		end
	else
		errorMsg = ErrorObject.new(ErrorCodes.NOT_ENOUGH_VARIABLES, '', nil, HTTPStatusCode.BadRequest)
	end
	return result, errorMsg
end

function Chart.deleteVariables(variables, chartName)
    local result = false
    local errorMsg = nil

    -- Check input types
    if (type(chartName) ~= 'string') or (type(variables) ~= 'table') then
        return result, ErrorCodes.INVALID_REQUEST
    end
    -- Check to make sure variables and chartName are the correct length
    if #variables < 0 then
        return result, ErrorCodes.INVALID_REQUEST
    elseif chartName:len() < Constants.MIN_CHART_NAME_LENGTH
        or chartName:len() > Constants.MAX_CHART_NAME_LENGTH then
        return result, ErrorCodes.INVALID_CHART_NAME_LENGTH
    end

    local env = luasql.sqlite()
    local connection = env:connect(Constants.DB_PATH)
    local isLockAcquired = connection:setautocommit('IMMEDIATE', 1000)
    if isLockAcquired then
        -- Check to make sure that the table actually exists
        local chartExists = false
        chartExists, errorMsg = Chart.exists(connection, chartName)
        if chartExists then
            local statement = 'DELETE FROM chart_variable WHERE ('
            local ctr = 0;
            local numVars = #variables
            --Loop to build statement
            for el,var in pairs(variables) do
                ctr = ctr + 1
                statement = statement .. ' mnemonic = ( ? )'
                if ctr < numVars then
                    statement = statement .. ' OR'
                end
            end
            statement = statement .. ') AND chart_name = ( ? )'

            local cursor = connection:prepare(statement)
            local bindings = {}

            for el,var in pairs(variables) do
                table.insert(bindings,{'TEXT', var.mnemonic})
            end
            table.insert(bindings,{'TEXT',chartName})

            cursor:bind( bindings )
            local exec = cursor:execute()

            if exec then
                -- Commit the transaction
                if connection:commit() then
                    result = true
                else
                    errorMsg = ErrorCodes.COMMIT_FAIL
                end
            else
                errorMsg = ErrorCodes.DELETE_VARS_FAILED
            end
            -- Close cursor connection
            if not cursor:close() then
                trace('FAILED TO CLOSE CURSOR')
            end
        elseif not chartExists and not errorMsg then
            errorMsg = ErrorCodes.CHART_DOES_NOT_EXIST
        end
    else
        errorMsg = ErrorCodes.LOCK_FAIL
    end
    -- Clean up
    if not connection:close() then
        trace('FAILED TO CLOSE SQLITE CONNECTION')
    end
    if not env:close() then
        trace('FAILED TO CLOSE SQLITE ENVIRONMENT')
    end

    return result, errorMsg
end

return Chart
