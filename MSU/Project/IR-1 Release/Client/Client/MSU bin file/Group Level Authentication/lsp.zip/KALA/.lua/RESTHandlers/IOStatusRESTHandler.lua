local IOStatusRESTHandler = {}

function IOStatusRESTHandler.getHandler(_ENV,path)
	 local method = request:method()
    -- Ensure that the response is has a content type of JSON
     response:setheader('content-type', 'application/json; charset=UTF-8')
	if (method == 'GET') then
		HTTPMethods.get(_ENV, IOStatusRESTHandler.getIOStatus, HTTPStatusCode.InternalServerError)
	else
	    gf.sendError(_ENV, {},ErrorObject.new(ErrorCodes.INVALID_REQUEST, '', nil, HTTPStatusCode.NotImplemented))
	end
end

function IOStatusRESTHandler.getIOStatus()
	local ioStatus, errorMsg = nil,nil
	if _G.isWindows then
		ioStatus, errorMsg = IOStatusRESTHandler.readIOStatusFile()
	else
		ioStatus, errorMsg = IOStatusRESTHandler.readIOStatusFile("ram")
	end

	if (ioStatus ~= nil and errorMsg == nil) then
		-- Modbus if i can read the file
		-- Variable use in IOStatusRESTHandler.readObjectCall()
		local parsingData = {}
		parsingData['AIList'], errorMsg = BinParser.AnalogicIOStatus(Constants.AI_Status_ObjectID)
		parsingData['AOList'], errorMsg = BinParser.AnalogicIOStatus(Constants.AO_Status_ObjectID )
		parsingData['DIList'], errorMsg = BinParser.LogicIORelayStatus(Constants.DI_Status_ObjectID)
		parsingData['DOList'], errorMsg = BinParser.LogicIORelayStatus(Constants.DO_Status_ObjectID)
		parsingData['RelayList'], errorMsg = BinParser.LogicIORelayStatus(Constants.Relays_Status_ObjectID)
		
		if (errorMsg == nil) then
			if ParametersTable ~= nil then
			    parsingData['listdef'] = ParametersTable['listdef']
			else
			    return nil, ErrorObject.new(ErrorCodes.PARAMETER_LIST_UNAVAILABLE)
			end 

			local result, errMsg = IOStatusRESTHandler.parseIOStatusFile(ioStatus, parsingData)
			if (result ~= nil and errMsg == nil) then
				return ba.json.encode(result), nil
			else
				return nil, errMsg
			end
		else
			return nil, errorMsg
		end
	else
		return nil, errorMsg
	end
end

function IOStatusRESTHandler.readIOStatusFile(ioType)
	local fileContent, errMsg = gf.readFile(Constants.IOSTATUS, ioType)
	if fileContent then
		return ba.json.decode(fileContent), nil
	else
		return nil, ErrorObject.new(ErrorCodes.FILE_EMPTY)
	end
end

function IOStatusRESTHandler.parseIOStatusFile(flux, parsingData)
	local objectResult, errMsg = {}, nil
	local arrayResult = nil	
	for k, v in pairs(flux) do
		arrayResult, errMsg = IOStatusRESTHandler.readArray(flux[k], parsingData)
		if (arrayResult) then
			objectResult[k:lower()] = arrayResult
		end
	end
	return objectResult, errMsg
end

function IOStatusRESTHandler.readArray(array, parsingData)
	local arrayResult = nil
	if (array ~= nil) then
		arrayResult = {}
		for i=1, #array do
			local res, errorMessage = IOStatusRESTHandler.readLine(array[i], parsingData)
			if (errorMessage == nil) then
				table.insert(arrayResult, res)
			else
				return nil, errorMessage
			end
		end
	end
	return arrayResult, nil
end

function IOStatusRESTHandler.readLine(line, parsingData)
	--type = line['TY'],
	local input =  {label = line['LA']:gsub('P#', '')}
	local objectCall, errMsg = IOStatusRESTHandler.readObjectCall(line['ID'], line['TY'], parsingData)
	if (objectCall ~= nil) and (errMsg == nil) then
		input['value'] = objectCall['Value']	
		input['dot'] = objectCall["Dot"]
		input['signed'] = objectCall["Signed"]
		input['unit'] =  objectCall['Unit']
		-- Find the assignment value in the WebDescription
		if objectCall['Assignment'] ~= nil then
			input['assignment'] = IOStatusRESTHandler.retrieveAssignmentList(objectCall['Assignment'], line['LS'], parsingData['listdef'])
		end
	end
	return input, errMsg
end

function IOStatusRESTHandler.readObjectCall(id, inputType, modusReturn)
	local object, errorMsg = nil, nil
	if (inputType == "AI") then
		object, errorMsg = IOStatusRESTHandler.findInList(id, modusReturn['AIList'])
	elseif (inputType == "AO") then
		object, errorMsg = IOStatusRESTHandler.findInList(id, modusReturn['AOList'])
	elseif (inputType == "DIL" or inputType == "DIH") then
		object, errorMsg = IOStatusRESTHandler.findInList(id, modusReturn['DIList'])
	elseif (inputType == "DO") then
		object, errorMsg = IOStatusRESTHandler.findInList(id, modusReturn['DOList'])
	elseif (inputType == "R") then
		object, errorMsg = IOStatusRESTHandler.findInList(id, modusReturn['RelayList'])
	else
		return nil, ErrorObject.new(ErrorCodes.INPUT_TYPE_UNKNOWN)
	end
	return object, errorMsg
end

function IOStatusRESTHandler.findInList(id, list)
	if (list ~= nil) then
		for k, v in pairs(list) do
			if v["ID"] == tonumber(id) then
				return v
			end
		end
	else
		return nil, ErrorObject.new(ErrorCodes.PARAMETER_LIST_UNAVAILABLE, id)
	end
end

function IOStatusRESTHandler.retrieveAssignmentList(listAssign, lsType, listDef)
	local assignValue = {}
	if (listDef ~= nil) then
		-- Foreach value of assignments
		for i=1, #listAssign do
			if (listDef[lsType] ~= nil) then
				local assign = {}
				assign['Value'] = listDef[lsType][tostring(tonumber(listAssign[i]))]
				assign['List'] = lsType
				table.insert(assignValue, assign)
			else
				ErrorObject.new(ErrorCodes.PARAMETER_LIST_UNAVAILABLE, 'List type not available')
			end
			--Retrieve the value of lsType in the webDescription
		end
	else
		ErrorObject.new(ErrorCodes.PARAMETER_LIST_UNAVAILABLE, 'ListDef not available')	
	end
	-- Return table of webDescription value
	return assignValue
end


return IOStatusRESTHandler