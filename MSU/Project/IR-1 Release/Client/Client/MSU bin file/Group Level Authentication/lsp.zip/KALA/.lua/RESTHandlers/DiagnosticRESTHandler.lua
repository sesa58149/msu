numberFault, numberAlarmHist = 0, 0
local DiagnosticRESTHandler = {}

function DiagnosticRESTHandler.getHandler(_ENV,path)
    local method = request:method()
    -- Ensure that the response has a content type of JSON
    response:setheader('content-type', 'application/json; charset=UTF-8')
    -- http://domain/rest/user
    if path:len() < 1 then
        gf.sendError(_ENV, HTTPStatusCode.BadRequest, ErrorCodes.UNSPECIFIED_DIAG)
	-- elseif path:lower() == 'getsummarydata' then
 --        if method == 'GET' then
 --            HTTPMethods.get(_ENV, DiagnosticRESTHandler.getSummaryData)
 --        else
 --            gf.sendError(_ENV)
 --        end
	-- elseif path:lower() == 'getperformancedata' then
 --        if method == 'GET' then
 --            HTTPMethods.get(_ENV, DiagnosticRESTHandler.getPerformanceData)
 --        else
 --            gf.sendError(_ENV)
 --        end
	-- elseif path:lower() == 'getlogdata' then
 --        if method == 'GET' then
 --            HTTPMethods.get(_ENV, DiagnosticRESTHandler.getLogData)
 --        else
 --            gf.sendError(_ENV)
 --        end
	-- elseif path:lower() == 'getportstatsdata' then
 --        if method == 'GET' then
 --            HTTPMethods.get(_ENV, DiagnosticRESTHandler.getPortStatisticsData)
 --        else
 --            gf.sendError(_ENV)
 --        end
	-- elseif path:lower() == 'getautotest' then
 --        if method == 'GET' then
 --            HTTPMethods.get(_ENV, DiagnosticRESTHandler.getAutoTest)
 --        else
 --            gf.sendError(_ENV)
 --        end
	-- elseif path:lower() == 'getethernetipdata' or path:lower() == 'getethernetipdata/' then
 --        if method == 'GET' then
 --            HTTPMethods.get(_ENV, DiagnosticRESTHandler.getEthernetIpData)
 --        else
 --            gf.sendError(_ENV)
 --        end
	elseif path:lower() == 'getmodbustcpipdata' or path:lower() == 'getmodbustcpipdata/' then
        if method == 'GET' then
            HTTPMethods.get(_ENV, DiagnosticRESTHandler.getModbusTcpIpData)
        else
            gf.sendError(_ENV)
        end
	-- elseif path:lower() == 'getethernetportdata' then
 --        if method == 'GET' then
 --            HTTPMethods.get(_ENV, DiagnosticRESTHandler.getEthernetPortData)
 --        else
 --            gf.sendError(_ENV)
 --        end
	elseif path:lower() == 'getmodbustcpport502connectiontabledata' or path:lower() == 'getmodbustcpport502connectiontabledata/' then
        if method == 'GET' then
            HTTPMethods.get(_ENV, DiagnosticRESTHandler.getModbusTcpPort502ConnectionTabledata)
        else
            gf.sendError(_ENV)
        end
	-- elseif path:lower() == 'getmodbustcpport502data' or path:lower() == 'getmodbustcpport502data/' then
 --        if method == 'GET' then
 --            HTTPMethods.get(_ENV, DiagnosticRESTHandler.getModbusTcpPort502data)
 --        else
 --            gf.sendError(_ENV)
 --        end
	-- elseif path:lower() == 'getioscannerdata' then
 --        if method == 'GET' then
 --            HTTPMethods.get(_ENV, DiagnosticRESTHandler.getIOScannerData)
 --        else
 --            gf.sendError(_ENV)
 --        end
	-- elseif path:lower() == 'getmessagingdata' then
 --        if method == 'GET' then
 --            HTTPMethods.get(_ENV, DiagnosticRESTHandler.getMessagingData)
 --        else
 --            gf.sendError(_ENV)
 --        end
	-- elseif path:lower() == 'getdeviceiddata' then
 --        if method == 'GET' then
 --            HTTPMethods.get(_ENV, DiagnosticRESTHandler.getDeviceIdData)
 --        else
 --            gf.sendError(_ENV)
 --        end
	-- elseif path:lower() == 'getemaildata' then
 --        if method == 'GET' then
 --            HTTPMethods.get(_ENV, DiagnosticRESTHandler.getEmailData)
 --        else
 --            gf.sendError(_ENV)
 --        end
	-- elseif path:lower() == 'getqosdata' then
 --        if method == 'GET' then
 --            HTTPMethods.get(_ENV, DiagnosticRESTHandler.getQosData)
 --        else
 --            gf.sendError(_ENV)
 --        end
	-- elseif path:lower() == 'getntpdata' then
 --        if method == 'GET' then
 --            HTTPMethods.get(_ENV, DiagnosticRESTHandler.getNTPData)
 --        else
 --            gf.sendError(_ENV)
 --        end
	-- elseif path:lower() == 'getredundancydata' then
 --        if method == 'GET' then
 --            HTTPMethods.get(_ENV, DiagnosticRESTHandler.getRedundancyData)
 --        else
 --            gf.sendError(_ENV)
 --        end
	elseif path:lower() == 'maintenance' or path:lower() == 'maintenance/' then
        if method == 'GET' then
            HTTPMethods.get(_ENV, DiagnosticRESTHandler.getMaintenanceData)
		elseif (method == 'POST') then
            HTTPMethods.post(_ENV, DiagnosticRESTHandler.updateMaintenanceData)
		else
            gf.sendError(_ENV)
        end
    elseif path:lower() == 'messaging' or path:lower() == 'messaging/' then
        if method == 'GET' then
            HTTPMethods.get(_ENV, DiagnosticRESTHandler.resetMessagingData)
        else
            gf.sendError(_ENV)
        end
    elseif path:lower() == 'fault' or path:lower() == 'fault/' then
        if method == 'GET' then
            HTTPMethods.get(_ENV, DiagnosticRESTHandler.getFaultHistoryData, HTTPStatusCode.InternalServerError)
        end
     elseif path:lower() == 'newfault' or path:lower() == 'newfault/' then
        if method == 'GET' then
            HTTPMethods.get(_ENV, DiagnosticRESTHandler.getNewFault)
        end
    elseif path:lower() == 'currentalarm' or path:lower() == 'currentalarm/' then
        if method == 'GET' then
            HTTPMethods.get(_ENV, DiagnosticRESTHandler.getCurrentAlarmData)
        end 
    elseif path:lower() == 'alarmhistory' or path:lower() == 'alarmhistory/' then
        if method == 'GET' then
            HTTPMethods.get(_ENV, DiagnosticRESTHandler.getAlarmHistoryData)
        end
     elseif path:lower() == 'newalarmhistory' or path:lower() == 'newalarmhistory/' then
        if method == 'GET' then
            HTTPMethods.get(_ENV, DiagnosticRESTHandler.getNewAlarmHistory)
        end
    -- elseif path:lower() == 'getalarmdata' then
 --        if method == 'GET' then
 --            HTTPMethods.get(_ENV, DiagnosticRESTHandler.getAlarmData)
 --        else
 --            gf.sendError(_ENV)
 --        end
    elseif path:lower() == 'ethernet' or path:lower() == 'ethernet/' then
        if method == "GET" then
            HTTPMethods.get(_ENV, DiagnosticRESTHandler.resetEthernetData)
        end
    else
        gf.sendError(_ENV, HTTPStatusCode.BadRequest, ErrorCodes.DIAG_DOES_NOT_EXIST)
    end
end

function DiagnosticRESTHandler.getMaintenanceData()
	local result, errorMsg = Diagnostic.getMaintenanceData()
	if result then

        -- Serialize object using JSON
        result = ba.json.encode( result )
    end

    return result, errorMsg
end

function DiagnosticRESTHandler.updateMaintenanceData(messageData)
    local message = messageData.message
	-- Ensure a new password is provided and that it doesn't go out of the max boundary of MAX_PASSWORD_LENGTH
	if message and message:len() > 0 then
		local result, errorMsg = Diagnostic.updateMaintenanceData(message)
		if result then
			return ba.json.encode({result}), nil
		else
			return nil, errorMsg
		end
	else
		return nil, errorMsg
	end
end

function DiagnosticRESTHandler.getModbusTcpIpData()
    local data, errorMsg = Diagnostic.getModbusTcpIpData()
	local result = nil

    if data then

        -- Serialize object using JSON
        result = ba.json.encode( data )
    end

    return result, errorMsg
end

function DiagnosticRESTHandler.getModbusTcpPort502ConnectionTabledata()
    local data, errorMsg = Diagnostic.getModbusTcpPort502ConnectionTabledata()
	local result = nil

    if data then

        -- Serialize object using JSON
        result = ba.json.encode( data )
    end

    return result, errorMsg
end

function DiagnosticRESTHandler.getNewFault()
    if (ParametersTable ~= nil) then
        local adresse = ParametersTable["parameterlist"]["PS30"]
        local result = {newFault = false}
        if (adresse) then
            local response, errorMsg =  ADL.ReadParamsNonCons(248, {adresse})
            if response then
                if (response[1].value ~= numberFault) then
                     result["newFault"] = true
                end
                numberFault = response[1].value
            else
                return nil, errorMsg
            end
        end
        return ba.json.encode(result), nil
    else
        return nil, ErrorObject.new(ErrorCodes.FILE_NOT_AVAILABLE, 'Parameter table not available')       
    end  
end

function DiagnosticRESTHandler.getNewAlarmHistory()
    if (ParametersTable ~= nil) then
        local adresse = ParametersTable["parameterlist"]["ALCT"]
        local result = {newAlarm = false}
        if (adresse) then
            local response, errorMsg =  ADL.ReadParamsNonCons(248, {adresse})
            if response then
                if (response[1].value ~= numberAlarmHist) then
                     result["newAlarm"] = true
                end
                numberAlarmHist = response[1].value
            else
                return nil, errorMsg
            end
         end
        return ba.json.encode(result), nil
    else
        return nil, ErrorObject.new(ErrorCodes.FILE_NOT_AVAILABLE, 'Parameter table not available')       
    end 
end

function DiagnosticRESTHandler.getFaultHistoryData()
    if (ParametersTable ~= nil) then
        local contentFile, errMsg = DiagnosticRESTHandler.readFaultHistoryFile()
        if contentFile then
            local result = {}
            local listParam = contentFile["PRM"]
            local listFault = ParametersTable['listdef'][contentFile["LIST"]]
            -- Get Current Fault
            result[#result+1] = DiagnosticRESTHandler.getLastFault()
            for k,v in pairs(contentFile["OBJID"]) do
                local data, errorMsg = BinParser.ReadFaultObject(v)
                if data ~= nil and errorMsg == nil then
                    result[#result+1] = DiagnosticRESTHandler.parseFaultData(listParam, data, listFault)
                else
                    return nil, errorMsg
                end
            end
            return ba.json.encode(result), nil
        else
            return nil, errMsg
        end
    else
        return nil, ErrorObject.new(ErrorCodes.FILE_NOT_AVAILABLE, 'Parameter table not available')       
    end   
end

function DiagnosticRESTHandler.readFaultHistoryFile()
    local fileContent, errMsg = gf.readFile(Constants.FAULTHISTORY,  "ram")
    if fileContent then
        return ba.json.decode(fileContent), nil
    else
        return nil, errMsg
    end  
end

function DiagnosticRESTHandler.getLastFault()
    if _G.isWindows then
        return {labelId = 'INF1'}
    end
    if (ParametersTable ~= nil) then
        local adresse = ParametersTable['parameterlist']["LFT"]
        local faultObject = {}
        if adresse then
            local response, errorMsg = ADL.GetParamsDescription(248, {adresse})
            if response then
                faultObject["labelId"] = ParametersTable['listdef']["LFT"][tostring(response[1].value)]
            else
                return nil, errorMsg
            end
        else
            faultObject["labelId"] = ParametersTable['listdef']["LFT"]["0"]
        end
        return faultObject
    else
        return nil, ErrorObject.new(ErrorCodes.FILE_NOT_AVAILABLE, 'Parameter table not available')   
    end
end

function DiagnosticRESTHandler.parseFaultData(params, data, listFault)
    if (data) then
        local faultObject = {}
        faultObject["labelId"] = listFault[tostring(data["FaultCode"])]
        local paramArray = {}
        for k,v in pairs(data["Context"]) do
            local parameter = {}
            if (params[k] ~= nil) then
                parameter["labelId"] = string.gsub(params[k], 'P#', '')
                parameter["dot"] = v["Dot"]
                parameter["type"] = v["Type"]
                if (v["Type"] == 0) then
                    if ParametersTable.listdef[parameter["labelId"]] then
                        if ParametersTable.listdef[parameter["labelId"]][tostring(v["Value"])] then
                            parameter["value"] = ParametersTable.listdef[parameter["labelId"]][tostring(v["Value"])]
                        else
                            parameter["value"] = v["Value"] .. ' No Label'
                        end   
                    else
                        parameter["value"] = v["Value"]
                    end   
                else
                    parameter["value"] = v["Value"]
                    parameter["signed"] = v["Signed"]
                    parameter["unit"] = v["Unit"]
                end
                
                
                table.insert(paramArray, parameter)
            end
        end
        faultObject["parameters"] = paramArray
        return faultObject 
    end
    return nil
end

function DiagnosticRESTHandler.getCurrentAlarmData()
    if (ParametersTable ~= nil) then
        local contentFile, errMsg = DiagnosticRESTHandler.readAlarmDescFile()

        if contentFile then
            local addresses, tempKeyValue = {}, {}
            for k,v in pairs(contentFile) do
                -- Get Address parameterlist
                local address = ParametersTable["parameterlist"][k]
                -- Save paramId/Adress
                tempKeyValue[address] = k
                if (address) then
                    table.insert(addresses, address)
                end
            end
            -- Call ReadParamsNonCons  
            local resultAlarm, errorMsg =  ADL.ReadParamsNonCons(248, addresses)
            local parseAlarm = {}
            local index = 0
            if resultAlarm then
                for j = 1, #resultAlarm do
                    local paramID = tempKeyValue[resultAlarm[j].address]
                    local alarms = DiagnosticRESTHandler.readBitFieldAlarm(contentFile[paramID] , paramID, resultAlarm[j].value, index)
                    if alarms then
                        parseAlarm = gf.merge(parseAlarm, alarms)
                    end
                    index = index + 15
                end
                return ba.json.encode(parseAlarm), nil
            else
                -- COM error
                return nil, errorMsg --errMsg
            end
        else
            return nil, errMsg
        end
    else
        return nil, ErrorObject.new(ErrorCodes.FILE_NOT_AVAILABLE, 'Parameter table not available')       
    end 
end

function DiagnosticRESTHandler.readAlarmDescFile()
    local fileContent, errMsg = gf.readFile(Constants.CURRENTALARM,  "ram")
     if fileContent then
        return ba.json.decode(fileContent), nil
    else
        return nil, errMsg
    end 
end

function DiagnosticRESTHandler.readBitFieldAlarm(bitfieldDesc, param, result, index)
    local alarms = {}
    for i = 1, #bitfieldDesc do
        local alarm = {}
        -- Read byte 
        local active = bit32.extract(result, bitfieldDesc[i], 1)
        if active == 1 then
            alarm['list'] = param
            --List Element add the number of bit already ready ALR1 : 0-15, ALR2 : 16 - 31 ....
            --local label =  ParametersTable["listdef"]["ALR"][tostring(bitfieldDesc[i] + index)];
            alarm['labelId'] = ParametersTable["listdef"]["ALR"][tostring(bitfieldDesc[i] + index)]
            table.insert(alarms, alarm)    
        end
    end
    return alarms
end

function DiagnosticRESTHandler.getAlarmHistoryData()
    if (ParametersTable ~= nil) then
        local content, err = DiagnosticRESTHandler.readAlarmHistoryFile()
        if (content) then
            local historyAlarms, listName = {}, content["LN"]
            for k,v in pairs(content.ALARMS) do
                local alarms = {}
                alarms['id'] = v['ID']
                alarms['list'] = listName
                alarms['labelId'] = ParametersTable["listdef"][listName][tostring(v["VAL"])]
                alarms['date'] = v["DATE"]
                alarms['time'] = v["TIME"]
                table.insert(historyAlarms, alarms)
            end
            return ba.json.encode(historyAlarms), nil
        end
        return nil, err
    else
        return nil, ErrorObject.new(ErrorCodes.FILE_NOT_AVAILABLE, 'Parameter table not available')       
    end 
end

function DiagnosticRESTHandler.readAlarmHistoryFile()
    local fileContent, errMsg = nil, nil
    if (_G.isWindows) then
        fileContent, errMsg = gf.readFile(Constants.ALARMHISTORY)
    else
        fileContent, errMsg = gf.readCompleteFileDrive(Constants.ALARMHISTORY)
    end
    if fileContent ~= nil then
        return ba.json.decode(fileContent), nil
    else
        return nil, errMsg 
    end
end

function DiagnosticRESTHandler.resetMessagingData()
    local result, errorMsg = Diagnostic.resetMessagingData()

    return result,errorMsg
end

function DiagnosticRESTHandler.resetEthernetData()
    local result, errorMsg = Diagnostic.resetEthernetData()

    return result,errorMsg
end

return DiagnosticRESTHandler
