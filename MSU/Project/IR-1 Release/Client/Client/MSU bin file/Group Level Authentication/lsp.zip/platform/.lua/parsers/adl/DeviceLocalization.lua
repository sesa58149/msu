local DeviceLocalization = {}

function DeviceLocalization.fetch()
    local data, errorMsg

    if LuaADL and not _G.forceSimulation then
        -- Default to 0 if no session is provided
        local session = 0

        -- Perform Request
        data, errorMsg = LuaADL.ExecuteService(Constants.DRIVE_UNIT_ID, 0, 4, 3, 1, {1})
    else

        data, errorMsg = DeviceLocalization.getSimulationData()
    end

    if DeviceLocalization.isValidResponse(data) then
        local status = data[1]
        -- One indicates success
        if status == 1 then
            return ba.json.encode({success=true})
        end


        local developerMsg
        if status == 0 then
            developerMsg = ErrorCodes.SERVICE_READY
        elseif status == 4 then
            developerMsg = ErrorCodes.SERVICE_ASYNC_PROGRESS
        elseif status == 5 then
            developerMsg = ErrorCodes.SERVICE_ASYNC_BUSY
        else
            developerMsg = ErrorCodes.SERVICE_UNKNOWN_STATUS
        end

        return nil, ErrorObject.new(ErrorCodes.DEVICE_LOCAL_FAILED, developerMsg)
    else
        return nil, ErrorObject.new(ErrorCodes.DEVICE_LOCAL_FAILED, ErrorCodes.INVALID_SERVER_RESPONSE)
    end
end

function DeviceLocalization.isValidResponse(response)
    return response ~= nil and type(response) == 'table' and #response == 3 and type(response[1]) == 'number'
end

function DeviceLocalization.getSimulationData()
    return {1,0,0}
end

return DeviceLocalization