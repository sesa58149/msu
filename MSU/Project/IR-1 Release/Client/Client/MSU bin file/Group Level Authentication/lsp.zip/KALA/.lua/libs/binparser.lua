local binparser = {}

-- Parse a ReadObject Result for Analogic IO 
function binparser.AnalogicIOStatus(ObjectID)
	--Call ReadObject(DeviceId, {id})
	local callReadObject = binparser.LuaADLCall(ObjectID)
	if callReadObject == nil then
		return nil, ErrorObject.new(ErrorCodes.INVALID_RESPONSE_FROM_SERVER)
	end
	local arrayResult, errorMsg = {}, nil
	local readObject = callReadObject[2]
	--Number of AIs [1] (1 bytes : U8)
	local indexLoop = tonumber(readObject[1])
	local nbrBytesRead = 2
	--For number of AIs
	for i=1, indexLoop do
		local result= {}
		-- ID [1]
		nbrBytesRead, result["ID"], errorMsg = binparser.readNumber(readObject, nbrBytesRead)
		-- Nb of Assignement [1]
		local nbAssign = ""
		nbrBytesRead, nbAssign, errorMsg = binparser.readNumber(readObject, nbrBytesRead)

		if (nbAssign > 0) then
			local tableAssign = {}
			-- For number of Assignment
			for j=1, nbAssign do
				--Assignment value [2] (2 bytes : U16)
				local strNbAssign = ""
				nbrBytesRead, strNbAssign, errorMsg = binparser.readNumber16(readObject, nbrBytesRead)
				table.insert(tableAssign, strNbAssign)
			end
			result["Assignment"] = tableAssign
		end
		-- Value [2] - U16
		nbrBytesRead, result["Value"], errorMsg = binparser.readNumber16(readObject, nbrBytesRead)
		-- Signed [1]
		nbrBytesRead, result["Signed"], errorMsg = binparser.readString(readObject, nbrBytesRead, 1 )
		-- Dot [1]
		nbrBytesRead,result["Dot"], errorMsg = binparser.readNumber(readObject, nbrBytesRead)
		-- UnitSize [1]
		nbrBytesRead,result["UnitSize"], errorMsg = binparser.readNumber(readObject, nbrBytesRead)
		-- Unit [UnitSize*1]
		nbrBytesRead, result["Unit"], errorMsg = binparser.readASCII(readObject, nbrBytesRead, result["UnitSize"])
		
		if (errorMsg == nil) then
			table.insert(arrayResult, result)
		else
			return nil, errorMsg
		end
	end
	return arrayResult, nil
end
-- Parse a ReadObject result for Logic IO and Relays
function binparser.LogicIORelayStatus(ObjectID)
	local callReadObject = binparser.LuaADLCall(ObjectID)
	if callReadObject == nil then
		return nil, ErrorObject.new(ErrorCodes.INVALID_RESPONSE_FROM_SERVER)
	end

	local arrayResult, errorMsg = {}, nil
	local readObject = callReadObject[2]
	--Number of DIs [1] (1 bytes : U8)
	local indexLoop = tonumber(readObject[1])
	local nbrBytesRead = 2
	--For number of AIs
	for i=1, indexLoop do
		local result= {}
		-- ID [1]
		nbrBytesRead, result["ID"], errorMsg = binparser.readNumber(readObject, nbrBytesRead)
		-- Nb of Assignement [1]
		local nbAssign = ""
		nbrBytesRead, nbAssign, errorMsg = binparser.readNumber(readObject, nbrBytesRead)
		if (nbAssign > 0) then
			local tableAssign = {}
			-- For number of Assignment
			for j=1, tonumber(nbAssign) do
				--Assignment value [2] (2 bytes : U16)
				local strNbAssign = ""
				nbrBytesRead, strNbAssign, errorMsg = binparser.readNumber16(readObject, nbrBytesRead)
				table.insert(tableAssign, strNbAssign)
			end
			result["Assignment"] = tableAssign
		end
		-- Value [1] - U8
		nbrBytesRead, result["Value"], errorMsg = binparser.readNumber(readObject, nbrBytesRead)
		if (errorMsg == nil) then
			table.insert(arrayResult, result)
		else
			return nil, errorMsg
		end
	end
	return arrayResult, nil
end

function binparser.ReadFaultObject(ObjectID)
	local callReadObject = binparser.LuaADLCall(ObjectID)
	if callReadObject == nil then
		return nil, ErrorObject.new(ErrorCodes.INVALID_RESPONSE_FROM_SERVER)
	end
	local arrayResult, nbrBytesRead, indexContext, errorMsg = {}, 1, 0, nil
	local readObject = callReadObject[2]
	--FaultCode U8
	nbrBytesRead, arrayResult["FaultCode"], errorMsg = binparser.readNumber(readObject, nbrBytesRead)

	nbrBytesRead, indexContext, errorMsg = binparser.readNumber(readObject, nbrBytesRead)

	if (errorMsg ~= nil) then return nil, errorMsg end

	arrayResult["Context"] = {}
	for i =1, indexContext do
		local context,buffer = {}, nil

		nbrBytesRead, buffer, errorMsg = binparser.readNumber(readObject, nbrBytesRead)
		if (errorMsg ~= nil) then return nil, errorMsg end
		
		-- Bytes 7 - 4 = Type
		-- Bytes 3 = Signed
		-- Bytes 2 - 0 = Reserved
		local typeData = bit32.extract(buffer, 4, 4)
		context["Signed"] = bit32.extract(buffer, 3, 1)
		context["Type"] = typeData
	
		--List16
		if typeData == 0 then
			nbrBytesRead, context["Value"], errorMsg = binparser.readNumber16(readObject, nbrBytesRead)
		-- Num16
		elseif typeData == 1 then
			if i == 1 then
				-- Date
				local date
				nbrBytesRead, date, errorMsg = binparser.readNumber16(readObject, nbrBytesRead)
				if (errorMsg == nil) then 
					-- MSB to LSB : 
					--7 bits Year (2000 + Value of 7 bits)
					local year = 2000 + bit32.extract(date, 9, 7)
					--4 bits Month
					local month = bit32.extract(date, 5, 4)
					--5 bits Day
					local day = bit32.extract(date, 0, 5)
					context["Value"] = {year = year, month = month, day = day}
				else
					return nil, errorMsg 
				end
			elseif  i == 2 then
				local time
				nbrBytesRead, time, errorMsg = binparser.readNumber16(readObject, nbrBytesRead)
				if (errorMsg == nil) then 
					--Time
					--Hour MSB 
					local hour = bit32.extract(time, 8, 7)
					--Minute LSB
					local minute = bit32.extract(time,0, 7)
					context["Value"] = {hour = hour, minute = minute}
				else
					return nil, errorMsg 
				end
			else
				nbrBytesRead, context["Value"], errorMsg = binparser.readNumber16(readObject, nbrBytesRead)
			end
			nbrBytesRead, context["Dot"], errorMsg = binparser.readNumber(readObject, nbrBytesRead)
			local unitSize
			nbrBytesRead, unitSize = binparser.readNumber(readObject, nbrBytesRead)
			nbrBytesRead, context["Unit"], errorMsg = binparser.readASCII(readObject, nbrBytesRead, unitSize)
		-- Num32
		elseif typeData == 2 then
			nbrBytesRead, context["Value"], errorMsg = binparser.readNumber32(readObject, nbrBytesRead)
			nbrBytesRead, context["Dot"], errorMsg = binparser.readNumber(readObject, nbrBytesRead)
			local unitSize
			nbrBytesRead, unitSize, errorMsg = binparser.readNumber(readObject, nbrBytesRead)
			nbrBytesRead, context["Unit"], errorMsg = binparser.readASCII(readObject, nbrBytesRead, unitSize)
		-- Registre 16
		elseif typeData == 3 then
			nbrBytesRead, context["Value"], errorMsg = binparser.readNumber16(readObject, nbrBytesRead)
		-- MultipleList08
		elseif typeData == 4 then
			nbrBytesRead, context["Value"], errorMsg = binparser.readNumber16(readObject, nbrBytesRead)
		end
		
		if (errorMsg == nil) then 
			table.insert(arrayResult["Context"], context)
		else
			return nil, errorMsg 
		end
	end
	return arrayResult, nil
end

-- Read value in a string and increment the cursor
function binparser.readString(str, cursor, length)
	if (str ~= nil and #str >= cursor+(length-1)) then
		local strResult = ""
		for i = cursor, cursor+(length-1) do
			strResult = strResult .. tostring(str[i])
		end
		return cursor + length, strResult 
	else
		return nil, nil, ErrorObject.new(ErrorCodes.INVALID_RESPONSE_FROM_SERVER) 
	end
end

function binparser.readASCII(str, cursor, length)
	if (str ~= nil and #str >= cursor+(length-1)) then
		local strResult = ""
		for i = cursor, cursor+(length-1) do
			strResult = strResult .. string.char(str[i])
		end
		return cursor + length, strResult 
	else
		return nil, nil, ErrorObject.new(ErrorCodes.INVALID_RESPONSE_FROM_SERVER) 
	end
end

function binparser.readNumber(numb, cursor)
	if (numb[cursor] ~= nil) then
		return cursor + 1, tonumber(numb[cursor]) 
	else
		return nil,nil, ErrorObject.new(ErrorCodes.INVALID_RESPONSE_FROM_SERVER) 
	end	
end

function binparser.readNumber16(numb, cursor)
	local l1 = bit32.lshift(numb[cursor], 8)
	local l2 = numb[cursor+1]
	
	if (l1 ~= nil and l2 ~= nil) then
		return cursor + 2, bit32.bor(l1, l2), nil
	else
		return nil,nil, ErrorObject.new(ErrorCodes.INVALID_RESPONSE_FROM_SERVER) 
	end
end

function binparser.readNumber32(numb, cursor)
	local l1 = bit32.lshift(numb[cursor], 24)
	local l2 = bit32.lshift(numb[cursor+1], 16)
	local l3 = bit32.lshift(numb[cursor+2], 8)
	local l4 = numb[cursor+3]

	if (l1 ~= nil and l2 ~= nil and l3 ~= nil and l4 ~= nil) then
		return cursor + 4, bit32.bor(l1, l2, l3, l4), nil
	else
		return nil,nil, ErrorObject.new(ErrorCodes.INVALID_RESPONSE_FROM_SERVER) 
	end
end

function binparser.StringBytesToNumber(str)
	local num = 0
	local len = #str
	for i = 1,len do
		num = num + string.byte(str,i) * 256^(len-i)
	end
	return num
end

function binparser.StringBytesString(str)
	local val = ''
	local len = #str
	for i = 1,len do
		val = string.format('%s%s',val,string.char(string.byte(str,i)))
	end
	return val
end

function binparser.LuaADLCall(ObjectID)
	local callReadObject = nil
	if LuaADL then
		callReadObject = LuaADL.ReadObject(Constants.KALA_READ_OBJECT, 0 ,{0, ObjectID})
	else
		callReadObject = binparser.mockLuaADL(ObjectID)
	end

	if callReadObject == nil or #callReadObject < 2 then
		return nil, ErrorObject.new(ErrorCodes.INVALID_RESPONSE_FROM_SERVER) 
	else
		return callReadObject, nil
	end
end

function binparser.mockLuaADL(ObjectID)
	if ObjectID == Constants.AI_Status_ObjectID then
		return {0, {3,0,1,0,129,0,0,1,3,1,86,1,1,0,0,0,0,1,3,1,86,2,1,0,0,0,0,1,3,2,109,65}}
	elseif ObjectID == Constants.AO_Status_ObjectID then
		return {0, {2,15,1,0,130,0,0,1,3,2,109,65,16,1,0,129,0,0,1,3,2,109,65}}
	elseif ObjectID == Constants.DI_Status_ObjectID then
		return {0, {6,30,1,0,2,0,31,1,0,3,0,32,1,0,0,0,33,1,0,0,0,34,1,0,0,0,35,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}}
	elseif ObjectID == Constants.DO_Status_ObjectID then
		return {0, {0,0,0,0,0,0,0,0}}
	elseif ObjectID == Constants.Relays_Status_ObjectID then
		return {0,{3,70,1,0,1,0,71,1,0,0,0,72,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,00,0,0,0,0,0,0,0,0,0,0}}
	elseif ObjectID > 4607 and ObjectID < 4637 then
		--date = 7242 (10/02/14) 2874 heure = 2084 (08h36min) 836
		return {0,{42,16,16,28,74,0,0,16,8,36,0,0,0,30,48,2,80,48,64,2,48,0,0,24,0,0,2,1,65,16,9,16,1,1,86,24,0,0,1,2,72,122,24,0,0,1,1,37,16,0,22,0,1,37,16,0,0,0,2,176,67,16,31,59,0,2,72,122,16,0,0,0,1,104,16,0,0,0,1,37,48,15,15}}
	end	
end

return binparser