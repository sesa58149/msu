local KWReportRESTHandler = {}

function KWReportRESTHandler.getHandler(_ENV, path)
	 local method = request:method()
    -- Ensure that the response is has a content type of JSON
     response:setheader('content-type', 'application/json; charset=UTF-8')
	if (method == 'GET') then
		local typeReport = path:lower()
		HTTPMethods.get(_ENV, KWReportRESTHandler.getKWReport)
	else
	    gf.sendError(_ENV, {},ErrorObject.new(ErrorCodes.INVALID_REQUEST, '', nil, HTTPStatusCode.NotImplemented))
	end
end

function KWReportRESTHandler.getKWReport()
	local collectionReport, errMsg = {}, nil
	collectionReport, errMsg = KWReportRESTHandler.addReport(collectionReport, 'hourly')
	collectionReport, errMsg = KWReportRESTHandler.addReport(collectionReport, 'daily')
	collectionReport, errMsg = KWReportRESTHandler.addReport(collectionReport, 'monthly')
	collectionReport, errMsg = KWReportRESTHandler.addReport(collectionReport, 'yearly')
	if (#collectionReport > 0) then
		return ba.json.encode(collectionReport), nil
	else
		return nil, errMsg
	end
end

function KWReportRESTHandler.addReport(collection, typeReport)
	local report, errorMsg = nil,nil
	if _G.isWindows then
		report, errorMsg =  KWReportRESTHandler.readReportDisk(typeReport)
	else
		report, errorMsg =  KWReportRESTHandler.readReport(typeReport)
	end
	if (errorMsg == nil) then
		table.insert(collection, report)
		return collection, nil
	else
		return nil, errorMsg
	end
end

function KWReportRESTHandler.readReport(typeReport)
	local fileContent, errMsg = gf.readCompleteFileDrive(KWReportRESTHandler.getPath(typeReport))
	
	if fileContent ~= nil then
        return ba.json.decode(fileContent), nil
    else
        return nil, errMsg 
    end
end

function KWReportRESTHandler.readReportDisk(typeReport)
	local fileContent, errMsg = gf.readFile(KWReportRESTHandler.getPath(typeReport))
	if fileContent then
		return ba.json.decode(fileContent), nil
	else
		return nil, ErrorObject.new(ErrorCodes.FILE_EMPTY)
	end
end

function KWReportRESTHandler.getPath(typeReport)
	if (typeReport == 'hourly') then
		return Constants.KWREPORT_H
	elseif (typeReport == 'daily') then
		return Constants.KWREPORT_D
	elseif (typeReport == 'monthly') then
		return Constants.KWREPORT_M
	elseif (typeReport == 'yearly') then
		return Constants.KWREPORT_Y
	end
end

return KWReportRESTHandler