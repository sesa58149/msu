local DBCnxnHandler = {}

-- Create a new DiskIo instance by using the sub directory "/" as the base directory for the new I/O:
local dbio = ba.mkio(ba.openio("disk"), "/")

function DBCnxnHandler.getDataSource(name)
	if name then
		return dbio:realpath(name) -- I/O from above
	end
	trace('Data source does not exist')
	return nil
end

function DBCnxnHandler.openDB(mode)
	local env = luasql.sqlite()
	if env then
		local conn, err = env:connect(Constants.DB_PATH, mode)
		if conn then
			return env, conn
		end
		env:close()
	end
	trace("Opening DB failed due to the following error: " .. err)
	return nil, err
end

function DBCnxnHandler.getLock(conn, autocommit)
	if conn then
		if not autocommit then
			return conn:setautocommit(false)
		else
			return conn:setautocommit(autocommit, 1000)
		end
	end
	return false, "Unable to connect"
end

function DBCnxnHandler.getQueryResponse(conn, query, bindings, errMsg)
	if conn then
		local cursor = conn:prepare(query)
		if cursor then
			cursor:bind(bindings)
		end
		local response = cursor:execute()
		if not response then
			return nil, errMsg
		else
			return response
		end
	end
	return false, "A problem occurred while querying the database"
end

function DBCnxnHandler.commit(conn)
	if conn then
		if not conn:commit() then
			trace('Commit failed')
			local rollback = conn:rollback('IMMEDIATE')
			if not rollback then
				trace('Rollback failed')
			end
		else
			return true
		end
	end
end

function DBCnxnHandler.closeCursor(cursor)
	if cursor then
		if not cursor:close() then
			trace('Failed to close the cursor')
		end
	end
end

function DBCnxnHandler.closeDB(env, conn)
	if env then
		if conn then
			if not conn:close() then
				trace('Failed to close sqlite connection')
			end
		end
		if not env:close() then
			trace('Failed to close sqlite environment')
		end
	end
end

return DBCnxnHandler