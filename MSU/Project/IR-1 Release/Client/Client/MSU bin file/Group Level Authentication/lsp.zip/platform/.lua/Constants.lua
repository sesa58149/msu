local Constants = {}

--------------------------------------
-- GENERAL
--------------------------------------
-- Debug mode: 1 - on, 0 - off
Constants.DEBUG_MODE = 1

-- Max Length for raw data coming in a request
Constants.MAX_RAW_DATA_LENGTH = 100000

-- Demo mode: 1 - on, 0 - off
Constants.isDemo = 0

--------------------------------------
-- USER MANAGEMENT
--------------------------------------

-- Max number of users in a system
Constants.MAX_NUMBER_OF_USERS = 25

-- First name
Constants.MIN_USER_FIRST_NAME_LENGTH = 1
Constants.MAX_USER_FIRST_NAME_LENGTH = 50
-- Last name
Constants.MIN_USER_LAST_NAME_LENGTH = 1
Constants.MAX_USER_LAST_NAME_LENGTH = 50

-- Username
Constants.MIN_USERNAME_LENGTH = 1
Constants.MAX_USERNAME_LENGTH = 127

-- Password
Constants.MIN_PASSWORD_LENGTH = 6
Constants.MAX_PASSWORD_LENGTH = 127
Constants.MAX_PASS_STRENGTH = 46

--------------------------------------
-- THEME MANAGEMENT
--------------------------------------

-- Name
Constants.MIN_THEME_NAME_LENGTH = 1
Constants.MAX_THEME_NAME_LENGTH = 20

-- Description
Constants.MIN_THEME_DESC_LENGTH = 0
Constants.MAX_THEME_DESC_LENGTH = 128

-- Logo
Constants.MIN_THEME_LOGO_LENGTH = 5 -- _.png
Constants.MAX_THEME_LOGO_LENGTH = 1024

-- Site Title
Constants.MIN_SITE_TITLE_LENGTH = 1
Constants.MAX_SITE_TITLE_LENGTH = 32

-- Colors
Constants.MIN_COLOR_VALUE_LENGTH = 4 -- #FFF
Constants.MAX_COLOR_VALUE_LENGTH = 7 -- #FFFFFF

if _G.isWindows then
    Constants.TEMP_UPLOAD_PATH = "web_content\\"
else
    Constants.TEMP_UPLOAD_PATH = ""
end

--------------------------------------
-- DATA TABLES
--------------------------------------

-- Table Name
Constants.MIN_TABLE_NAME_LENGTH = 1
Constants.MAX_TABLE_NAME_LENGTH = 20

-- Description
Constants.MIN_TABLE_DESC_LENGTH = 0
Constants.MAX_TABLE_DESC_LENGTH = 128

-- Number of Variables
Constants.MIN_NUM_VARS_PER_TABLE = 0
Constants.MAX_NUM_VARS_PER_TABLE = 120

-- Number of Tables
Constants.MAX_NUM_TABLES = 30

--------------------------------------
-- CHART VIEWER
--------------------------------------

-- Chart Name
Constants.MIN_CHART_NAME_LENGTH = 1
Constants.MAX_CHART_NAME_LENGTH = 20

-- Plot Frequency
Constants.MIN_PLOT_FREQUENCY = 1
Constants.MAX_PLOT_FREQUENCY = 10000

-- Frequency UoM
Constants.MIN_FREQUENCY_UM = 0
Constants.MAX_FREQUENCY_UM = 3

-- Auto Scale
Constants.MIN_AUTO_SCALE = 0
Constants.MAX_AUTO_SCALE = 1

-- Y-Min (Must be lower than Y-Max)
Constants.MIN_Y_MIN = -4294967294
Constants.MAX_Y_MIN = 4294967294

-- Y-Max
Constants.MIN_Y_MAX = -4294967294
Constants.MAX_Y_MAX = 4294967294

-- Plot points
Constants.MIN_PLOT_POINTS = 3
Constants.MAX_PLOT_POINTS = 20

-- Number of variables
Constants.MIN_NUM_VARS_PER_CHART = 1
Constants.MAX_NUM_VARS_PER_CHART = 5

-- Number of Charts
Constants.MAX_NUM_CHARTS = 10

-- Other
Constants.MILLISECONDS = 0
Constants.SECONDS = 1
Constants.MINUTES = 2
Constants.HOURS = 3
Constants.LOW_MS = 500

return Constants