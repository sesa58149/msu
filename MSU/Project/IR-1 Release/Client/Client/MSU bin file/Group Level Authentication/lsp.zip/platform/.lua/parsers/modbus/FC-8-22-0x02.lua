local FC8220x02 = {}

-- Send the modbus request and parse the result
function FC8220x02.fetch()
    local data = nil
    if LuaModBus then
        data = LuaModBus.DiagnosticsData( 22, 1, {2, 1, 0} )
    end

    if not data then
        data = {
            22,0,0,0,                            -- Diag header (Port Diagnostics Data Validity?)
            80,250,                              -- Logical/Physical Port Number
            0,1,                                 -- Ether Control Capability
            1,3,                                 -- Link Speed Capability
            0,4,                                 -- Ether Control Configuration
            1,22,                                -- Link Speed Configuration
            0,5,                                 -- Ether Control Operational
            1,6,                                 -- Link Speed Operational
            0,17,0,19,128,160,                   -- Port MAC Address
            9,7,8,1,                             -- Num Frames Xmit OK
            8,8,7,1,                             -- Num Frames Received OK
            7,8,6,1,                             -- Num Ether Collisions
            6,7,5,1,                             -- Carrier Sense Errors
            5,6,4,1,                             -- Num Ether Excessive Collisions
            0,1,3,1,                             -- CRC Errors
            0,1,2,1,                             -- FCS Errors
            2,3,9,1,                             -- Alignment Errors
            2,2,8,0,                             -- Num Internal Mac Tx Errors
            3,2,7,0,                             -- Late Collisions
            4,3,6,0,                             -- Num Internal MAC Rx Errors
            5,4,5,1,                             -- Multiple Collisions
            6,5,4,1,                             -- Single Collisions
            7,6,1,1,                             -- Deferred Transmissions
            8,7,0,3,                             -- Frames Too Long
            9,8,1,1                              -- Frames Too Short (Runt packets)
        }
        --Test data from Device
        data = {22,0,1,2,1,0,0,50,135,252,1,0,32,25,0,100,32,25,0,100,32,9,0,10,0,0,0,0,0,0,0,120,0,0,0,0,5,0,0,2,186,0,0,0,0,0,0,2,139,0,0,0,0,0,0,0,0}
        
    end

    return FC8220x02.parse(data)
end

-- Parse the result
function FC8220x02.parse(data)
    local result = {}
    local c = 9
    local field = 0
    --result["diagnostic_header"] = Utils.convertBytesToInt32(
    --    data[c],
    --    data[c+1],
    --    data[c+2],
    --    data[c+3]
    --);
    --c = c + 4

    result.validity = Utils.convertBytesToInt16(
        data[c],
        data[c+1]
    )
    c = c + 2

    local validity = result.validity

    if(bit32.extract(validity, 10, 1) == 1) then
        result["port_number"] = {
    		["logical"] = data[c],
    		["physical"] = data[c+1]
    	}
        c = c + 2
    end

    if(bit32.extract(validity, 9, 1) == 1) then
        field = bit32.bor( -- Concatenates the two bytes to use masks
            bit32.lrotate(data[c  ], 8*1),
            bit32.lrotate(data[c+1], 8*0)
        )
    	result["ether_control_capability"] = {
    		["LINK"] = (bit32.extract(field, 13, 1) == 1), -- 0=NOT SUPPORTED, 1=SUPPORTED
    		["DUPLEX"] = bit32.extract(field, 3, 2), -- 00=NONE, 01=HALF-DUPLEX, 10=FULL-DUPLEX, 11=AUTO-NEGOTIATE
    		["FIBER"] = (bit32.extract(field, 1, 1) == 1), -- 0=NOT SUPPORTED, 1=SUPPORTED
    		["TWISTED_PAIR"] = (bit32.extract(field, 0, 1) == 1) -- 0=NOT SUPPORTED, 1=SUPPORTED
        }
        c = c + 2
    end

    if(bit32.extract(validity, 8, 1) == 1) then
        result["link_speed_capability"] = Utils.convertBytesToInt16(
            data[c],
            data[c+1]
        );
        c = c + 2
    end

    if(bit32.extract(validity, 7, 1) == 1) then
        field = bit32.bor( -- Concatenates the two bytes to use masks
            bit32.lrotate(data[c  ], 8*1),
            bit32.lrotate(data[c+1], 8*0)
        )

        result["ether_control_configuration"] = {
    		["LINK"] = (bit32.extract(field, 13, 1) == 1), -- 0=Link Down, 1=Link Up
    		["DUPLEX"] = bit32.extract(field, 3, 2), -- 00=NONE, 01=HALF-DUPLEX, 10=FULL-DUPLEX, 11=AUTO-NEGOTIATE
    		["FIBER"] = (bit32.extract(field, 1, 1) == 1), -- 0=DISABLED, 1=ENABLED
    		["TWISTED_PAIR"] = (bit32.extract(field, 0, 1) == 1), -- 0=DISABLED, 1=ENABLED
        }
        c = c + 2
    end

    if(bit32.extract(validity, 6, 1) == 1) then
        result["link_speed_configuration"] = Utils.convertBytesToInt16(
            data[c],
            data[c+1]
        );
        c = c + 2
    end

    if(bit32.extract(validity, 5, 1) == 1) then
        field = bit32.bor( -- Concatenates the two bytes to use masks
            bit32.lrotate(data[c  ], 8*1),
            bit32.lrotate(data[c+1], 8*0)
        )

        result["ether_control_operational"] = {
    		["LINK"] = (bit32.extract(field, 13, 1) == 1), -- 0=Link Down, 1=Link Up
    		["DUPLEX"] = bit32.extract(field, 3, 2), -- 00=None, 01=HALF-DUPLEX, 10=FULL-DUPLEX, 11=Auto-Negotiate
    		["FIBER"] = (bit32.extract(field, 1, 1) == 1), -- 0=NOT OPERATIONAL, 1=OPERATIONAL
    		["TWISTED_PAIR"] = (bit32.extract(field, 0, 1) == 1), -- 0=NOT OPERATIONAL, 1=OPERATIONAL
        }
        c = c + 2
    end

    if(bit32.extract(validity, 4, 1) == 1) then
        result["link_speed_operational"] = Utils.convertBytesToInt16(
            data[c],
            data[c+1]
        );
        c = c + 2
    end

    if(bit32.extract(validity, 3, 1) == 1) then
        result["port_MAC_address"] = Utils.convertBytesToMac({
            data[c],
            data[c+1],
            data[c+2],
            data[c+3],
            data[c+4],
            data[c+5]
        });
        c = c + 6
    end
    local totalError = 0
    if(bit32.extract(validity, 2, 1) == 1) then
        if (c < #data - 4)  then
            result["num_frames_xmit_ok"] = Utils.convertBytesToInt32(data[c], data[c+1], data[c+2], data[c+3])
            c = c + 4
        end
        if (c < #data - 4)  then
            result["num_frames_received_ok"] = Utils.convertBytesToInt32(data[c], data[c+1], data[c+2], data[c+3])
            c = c + 4
        end
        if (c < #data - 4)  then
            result["num_ether_collisions"] = Utils.convertRegistersToInt32(data[c], data[c+1], data[c+2], data[c+3])
            c = c + 4
        end
        if (c < #data - 4) then
            result["carrier_sense_errors"] = Utils.convertRegistersToInt32(data[c], data[c+1], data[c+2], data[c+3])
            totalError = totalError + result["carrier_sense_errors"]
            c = c + 4
        end
        if (c < #data - 4) then
            result["num_ether_excessive_collisions"] = Utils.convertBytesToInt32(data[c], data[c+1], data[c+2], data[c+3])
            c = c + 4
        end
        if (c < #data - 4) then
            result["crc_errors"] = Utils.convertBytesToInt32(data[c], data[c+1], data[c+2], data[c+3])
            totalError = totalError +  result["crc_errors"]
            c = c + 4
        end
        if (c < #data - 4) then
            result["fcs_errors"] = Utils.convertBytesToInt32(data[c], data[c+1], data[c+2], data[c+3])
            totalError = totalError +  result["fcs_errors"] 
            c = c + 4
        end
        if (c < #data - 4) then
            result["alignment_errors"] = Utils.convertBytesToInt32(data[c], data[c+1], data[c+2], data[c+3])
            totalError = totalError +  result["alignment_errors"] 
            c = c + 4
        end
        if (c < #data - 4) then
            result["num_internal_MAC_tx_errors"] = Utils.convertBytesToInt32(data[c], data[c+1], data[c+2], data[c+3])
            totalError = totalError +  result["num_internal_MAC_tx_errors"]
            c = c + 4
        end
        if (c < #data - 4)  then
            result["late_collisions"] = Utils.convertBytesToInt32(data[c], data[c+1], data[c+2], data[c+3])
            c = c + 4
        end
        if (c < #data - 4) then
            result["num_internal_MAC_rx_errors"] = Utils.convertBytesToInt32(data[c], data[c+1], data[c+2], data[c+3])
            totalError = totalError +  result["num_internal_MAC_rx_errors"]
            c = c + 4
        end
        if (c < #data - 4) then
            result["multiple_collisions"] = Utils.convertBytesToInt32(data[c], data[c+1], data[c+2], data[c+3])
            c = c + 4
        end
        if (c < #data - 4)  then
            result["single_collisions"] = Utils.convertBytesToInt32(data[c], data[c+1], data[c+2], data[c+3])
            c = c + 4
        end
        if (c < #data - 4)  then
            result["deferred_transmissions"] = Utils.convertBytesToInt32(data[c], data[c+1], data[c+2], data[c+3])
            c = c + 4
        end
        if (c < #data - 4)  then
            result["frames_too_long"] = Utils.convertBytesToInt32(data[c], data[c+1], data[c+2], data[c+3])
            c = c + 4
        end
        if (c < #data - 4)  then
            result["frames_too_short"] = Utils.convertBytesToInt32(data[c], data[c+1], data[c+2], data[c+3])
            c = c + 4
        end

        result["total_errors"] = totalError

        if result.num_frames_xmit_ok == 0 then
            result["success_rate"] = '0.00'
        else
            local frames = result.num_frames_xmit_ok + result.num_frames_received_ok
            result["success_rate"] = string.format('%.2f',((frames - result.total_errors)/frames) * 100)
        end
    else
        result.total_errors = 'not_supported'
        result.success_rate = 'not_supported'
    end

    return result
end
return FC8220x02
