local MessageBoardRESTHandler = {}

function MessageBoardRESTHandler.getHandler(_ENV, path)
	local result, errorMsg, MessageBoardData = nil
	local method = request:method()
	local userRef = request:user()
	local user_name = nil
	if _G.securityMode == '0' then
		userRef = 'admin'
	end
	if userRef then
		user_name = userRef:match('[%w_]+')
		response:setheader('content-type', 'application/json; charset=UTF-8')
		if(path == '') then
			if(method == 'GET') then
				HTTPMethods.get(_ENV, MessageBoardRESTHandler.getMessageBoard, nil, user_name)
			elseif(method == 'POST') then
				HTTPMethods.post(_ENV, MessageBoardRESTHandler.saveMessageBoard, {}, user_name)
			else
				gf.sendError(_ENV)
			end
		end
	else
		gf.sendError(_ENV, HTTPStatusCode.InternalServerError, ErrorCodes.INVALID_REQUEST)
	end
end

function MessageBoardRESTHandler.getMessageBoard(user_name)
	local result, errorMsg = MessageBoard.get(user_name)
	if not errorMsg then
		return ba.json.encode( result ), nil
	else
		return nil, errorMsg
	end
end

function MessageBoardRESTHandler.saveMessageBoard(data, user_name)
	local result, errorMsg = MessageBoard.save(data, user_name)
	if result then
		return ba.json.encode({success = result})
	else
		return nil, errorMsg
	end
end

return MessageBoardRESTHandler