local io = ba.openio(_G.diskIOName)
local Constants = io:dofile('platform/.lua/Constants.lua')

-- Path to database
if LuaModBus then
	Constants.DB_PATH = '/fw/lsp/.kala.db'
else
	Constants.DB_PATH = '.kala.db'
end

--248: drive - notice FB vs F8
Constants.MULTI_REG_DEVICE_ID = 0xFB

-- Unit ID for the drive
Constants.DRIVE_UNIT_ID = 0xF8

Constants.CONF_ACTION_COUNT = 1
Constants.CONF_ACTION_OFFSET = 503

Constants.FDR_STATUS_COUNT = 3
Constants.FDR_STATUS_OFFSET = 1700

--Function code 8/21
Constants.ETH_STATS_OPCODE = 3
Constants.EXT_ETH_STATS_OPCODE = 100
Constants.MESSAGING_DATA_OPCODE = 101
Constants.MESSAGING_CNXNS_OPCODE = 102
Constants.IO_SCANNER_TX_RX_OPCODE = 114
Constants.IO_SCANNER_DEVICES_OPCODE = 115
Constants.PROCESSOR_LOAD_OPCODE = 117
Constants.STATUS_SUMMARY_OPCODE = 118
--Constants.VERSION_INFO_OPCODE = 0

-- Function code 8/22
Constants.PORT_STATISTICS_OPCODE = 1
Constants.BASIC_NETWORK_OPCODE = 1
Constants.ETHERNET_PORT_OPCODE = 2
Constants.MODBUS_TCP_PORT502_OPCODE = 3
Constants.MODBUS_TCP_PORT502_CONNECTION_TABLE_OPCODE = 4

-- TCPIP Page
Constants.MIN_AUTO_SYNC_TIME = 10
Constants.MAX_AUTO_SYNC_TIME = 655350
Constants.MAX_DEVICENAME_LENGTH = 16

-- SNMP Page
Constants.MAX_LOCATION_LENGTH = 32
Constants.MAX_CONTACT_LENGTH = 32
Constants.MAX_GET_LENGTH = 32
Constants.MAX_SET_LENGTH = 32
Constants.MAX_TRAP_LENGTH = 32
-- SNTP Page
Constants.MIN_POLL_INTERVAL = 0
Constants.MAX_POLL_INTERVAL = 63

-- IOStatus page
Constants.KALA_READ_OBJECT			= 248
Constants.AI_Status_ObjectID 		= 513 -- HEX : 0x0201 = DEC : 513
Constants.AO_Status_ObjectID 		= 529 -- HEX : 0x0211 = DEC : 529
Constants.DI_Status_ObjectID 		= 545 -- HEX : 0x0221 = DEC : 545
Constants.DO_Status_ObjectID 		= 561 -- HEX : 0x0231 = DEC : 561
Constants.Relays_Status_ObjectID 	= 577 -- HEX : 0x0241 = DEC : 577
--------------------------------------
-- UPLOADER
--------------------------------------
if  _G.isWindows then

	Constants.UPLOADTYPE = {
	    driveconfigreport			= 'ConfPackage.cfg',
	    firmwarereport	 			= 'update.zip'
	}
	Constants.UPLOADTYPEDRIVE = {
	}

	Constants.DOWNLOADPATH = {
		driveconfigreport			= 'ConfPackage.cfg',
	}
else
	Constants.UPLOADTYPE = {
	    --driveconfigreport			= 'User:/Drive/Conf/ConfPackage.cfg', --'Proc:/Configuration/ConfPackage.cfg',
	    --firmwarereport	 			= 'update/update.zip' --'\\update\\update.zip'
	}
	Constants.UPLOADTYPEDRIVE = {
		driveconfigreport 			= 'User:/Drive/Conf/ConfPackage.cfg',--'Internal:/ConfPackage.cfg'
		--firmwarereport	 			= 'local:/update/update.zip'
	}
	Constants.DOWNLOADPATH = {
		driveconfigreport			= 'User:/Drive/Conf/ConfPackage.cfg'
	}
end
--------------------------------------
-- Parser
--------------------------------------
if  _G.isWindows then
	Constants.IDENTITY = '.Identity.json'
	Constants.WEBDESCRIPTIONPATH = '.WebDesc.json'
	Constants.WEBCONFPATH = '.webconf.json'
	Constants.IOSTATUS	= '.IOStatus.json'
	Constants.FAULTHISTORY	= '.FaultsDesc.json'
	Constants.CURRENTALARM	= '.AlarmsDesc.json'
	Constants.ALARMHISTORY= '.AlarmsHist.json'
	Constants.KWREPORT_H = '.KWReport_H.json'
	Constants.KWREPORT_D = '.KWReport_D.json'
	Constants.KWREPORT_M = '.KWReport_M.json'
	Constants.KWREPORT_Y = '.KWReport_Y.json'
	Constants.TRENDVIEWER = '.TrendData.json'
	Constants.CURVEMONIT = '.CurveMonitoring.json'
	Constants.CURVEUPDATE = '.CurveMonitoringUpdate.json'
else
	Constants.IDENTITY = 'drive\\data\\Identity.json' --'drive\\data\\Identity.jso'
	Constants.WEBDESCRIPTIONPATH = 'drive\\data\\WebDesc.json' -- B:\drive\data
	Constants.WEBCONFPATH = 'webconf.json' --'somewhere\\on\\B:\\Drive'
	Constants.IOSTATUS	= 'drive\\data\\IOsDesc.json'
	Constants.FAULTHISTORY	= 'drive\\data\\FaultsDesc.json'
	Constants.CURRENTALARM	= 'drive\\data\\AlarmsDesc.json'
	Constants.ALARMHISTORY  = 'Proc:/Drive/Log/AlarmsHist.json'
	Constants.KWREPORT_H = 'Proc:/Drive/Log/KWReport_H.json'
	Constants.KWREPORT_D = 'Proc:/Drive/Log/KWReport_D.json'
	Constants.KWREPORT_M = 'Proc:/Drive/Log/KWReport_M.json'
	Constants.KWREPORT_Y = 'Proc:/Drive/Log/KWReport_Y.json'
	Constants.TRENDVIEWER = 'EthDyn:/TrendData.json'
	Constants.CURVEMONIT = '.CurveMonitoring.json'
	Constants.CURVEUPDATE = '.CurveMonitoringUpdate.json'
	Constants.CURVEMONITDRIVE = 'Proc:/Drive/Log/PumpCurves.json'
	Constants.CURVEUPDATEDRIVE = 'Proc:/Drive/Log/PumpCurvesDyn.json'	
end
--------------------------------------
-- END
--------------------------------------

return Constants