local Utils = {}

function Utils.getMSB(data)
    return bit32.band(bit32.rshift(data, 8), 0xFF)
end

function Utils.getLSB(data)
    return bit32.band(data, 0xFF)
end

function Utils.convertHexIP(address)
    local pieces = {}

    pieces[1] = tonumber(address:sub(1, 2), 16)
    pieces[2] = tonumber(address:sub(3, 4), 16)
    pieces[3] = tonumber(address:sub(5, 6), 16)
    pieces[4] = tonumber(address:sub(7, 8), 16)

    return pieces[1] .. '.' .. pieces[2] .. '.' .. pieces[3] .. '.' .. pieces[4]
end

function Utils.parseMonthDay(data)
    local monthPos = tonumber(data:find("^[0-9]+[/%-]"))
    local dayPos = tonumber(data:find("[/%-][0-9]+$")) + 1
    local sepPos = dayPos - 1
    local month = tonumber(string.sub(data,1,sepPos-1))
    local day = tonumber(string.sub(data,dayPos,string.len(data)))
    return Utils.convertBytesToInt16(month,day)
end

function Utils.parseDate(date)
    local yearPos  = 3 --Year is only 2 digits - starts after "20"
    local monthPos = tonumber(date:find("[/%-][0-9]+[/%-]")) + 1
    local dayPos   = tonumber(date:find("[/%-][0-9]+$")) + 1
    local sepPos1  = monthPos - 1
    local sepPos2  = dayPos - 1
    return {
        year = tonumber(string.sub(date, yearPos, sepPos1-1)),
        month = tonumber(string.sub(date, monthPos, sepPos2-1)),
        day = tonumber(string.sub(date, dayPos, string.len(date)))
    }
end

function Utils.parseTime(time)
    local hourPos  = 1
    local minPos   = tonumber(time:find("[:][0-9]+[:]")) + 1
    local secPos   = tonumber(time:find("[:][0-9]+$")) + 1
    local sepPos1  = minPos - 1
    local sepPos2  = secPos - 1
    return {
        hours   = tonumber(string.sub(time, hourPos, sepPos1-1)),
        minutes = tonumber(string.sub(time, minPos, sepPos2-1)),
        seconds = tonumber(string.sub(time, secPos, string.len(time)))
    }
end

--[[
    Checks to see if the string passed in is an IPv4 address.
    If it is, the address is converted to a hex format string (C0A8xxxx)
    If it is IPv6, it just returns the address passed in
]]
function Utils.checkIfIPv4AndConvert(addr)
    local hexString = ''
    if addr:find('%.') then --Yes, it's IPv4
        for number in string.gmatch(addr, "[0-9]+") do
            local tempHex = string.format("%02X", number)
            hexString = hexString .. tempHex
        end
    else    --No, it's IPv6
        return addr
    end
    return hexString
end

--[[
    Converts an ascii string into a register array
]]
function Utils.asciiToWordArray(phrase)
    local array = {}
    local word, lsb, msb, i = 0, 0, 0, 1
    local len = phrase:len()
    for i = 1, len, 2 do
        msb = phrase:byte(i)
        if i+1 <= len then
            lsb = phrase:byte(i+1)
        end
        word = Utils.convertBytesToInt16(msb,lsb)
        table.insert(array, word)
        lsb = 0
        msb = 0
    end
    return array
end

--[[
    Takes in an array of data and the data and position to replace in the array
    and returns a new array with the new information overwriting the old info
    in the same position of the array
]]
function Utils.overwriteAscii(data, currentPos, regArr, expectedLength)
    local n, temp = 1, nil
    temp = Utils.asciiToWordArray(data)
    for i = 1, #temp do
        regArr[i + currentPos] = temp[i]
        n = i
    end
    n = n + 1
    while n <= expectedLength do
        regArr[n+currentPos] = 0
        n = n + 1
    end
    return regArr
end

--[[
    Converts an IPv4 string to a register array and returns the array.
    If the bw parameter is true, the address is returned backwards
]]
function Utils.ipv4AddressToWordArray(addr, bw)
    local array = {}
    local tempStr1, tempStr2 = '-', nil
    local start, stop = 0, 0
    while true do
        --Get first and third parts of the address
        stop = addr:find('%.', start+1)
        if stop and stop > 0 then
            tempStr1 = addr:sub(start, stop-1)
        else break end
        start = stop+1
        --Get second and fourth parts of the address
        stop = addr:find('%.', start+1)
        if stop and stop > 0 then
            tempStr2 = addr:sub(start, stop-1)
        else
            tempStr2 = addr:sub(start)
            stop = #addr
        end
        start = stop+1
        table.insert(array, Utils.convertBytesToInt16(tonumber(tempStr1),tonumber(tempStr2)))
    end
    if bw then
        local temp = array[1]
        array[1] = array[2]
        array[2] = temp
    end
    return array
end

--[[
    Takes an array of registers and converts them to an ASCII string.
    startReg is 0 based, ctr is 1 based because of Lua
]]
function Utils.convertRegistersToAscii(regArr, startReg, numRegs)
    local ctr, str, char = 1, "", 0
    for ctr = 0, numRegs-1 do
        local twoChars = regArr[ctr + startReg]
        if twoChars ~= nil then
            char = bit32.rshift(twoChars, 8)
            if  char > 0 then
                str = str .. string.char(char)
            else
                break
            end
            char = bit32.band(twoChars, 0xFF)
            if  char > 0 then
                str = str .. string.char(char)
            else
                break
            end
        end
    end
    return str
end

function Utils.convertBytesToAscii(dataArr, start, length)
    local ctr, str, char = 1, "", 0
    for ctr = 0, length-1 do
        char = dataArr[ctr + start]
        if  char > 0 then
            str = str .. string.char(char)
        else
            break
        end
    end
    return str
end

function Utils.convertBytesToInt32(byte1, byte2, byte3, byte4)
    -- Shift first byte left 24 bits
    byte1 = bit32.lshift(byte1, 24)
    -- Shift second byte left 16 bits
    byte2 = bit32.lshift(byte2, 16)
    -- Shift third byte left 8 bits
    byte3 = bit32.lshift(byte3, 8)
    -- OR byte 1 and 2 together
    byte1 = bit32.bor(byte1, byte2)
    -- OR together
    byte1 = bit32.bor(byte1, byte3)
    -- OR together
    byte1 = bit32.bor(byte1, byte4)
    return byte1
end

function Utils.convertRegistersToInt32(reg1, reg2)
    if reg1 ~= 0 then
        reg1 = bit32.lshift(reg1, 16)
        return (bit32.bor(reg1, reg2))
    else
        return reg2
    end
end

function Utils.convertBytesToInt16(byte1, byte2)
    -- Shift first byte left 8 bits
    byte1 = bit32.lshift(byte1, 8)
    -- OR byte 1 and 2 together
    byte1 = bit32.bor(byte1, byte2)
    return byte1
end

function Utils.convertBytesToInt16BigEndian(byte1, byte2)
    -- Shift first byte left 8 bits
    byte2 = bit32.lshift(byte2, 8)
    -- OR byte 1 and 2 together
    byte2 = bit32.bor(byte2, byte1)
    return byte2
end

function Utils.convertBytesToInt32Array(arr, isLittleEndian)
    if (#arr % 4) ~= 0 then
        return nil, ErrorCodes.INT32_CONVERSION_ERR
    end
    local result = {}
    if not isLittleEndian then
        for i=1, #arr, 4 do
            table.insert(result, Utils.convertBytesToInt32(arr[i], arr[i+1], arr[i+2], arr[i+3]))
        end
    else
        for i=1, #arr, 4 do
            table.insert(result, Utils.convertBytesToInt32(arr[i+3], arr[i+2], arr[i+1], arr[i]))
        end
    end
    return result, nil
end

function Utils.convertRegistersToInt32Array(arr)
    if (#arr % 2) ~= 0 then
        return nil, ErrorCodes.INT32_CONVERSION_ERR
    end
    local result = {}
    for i=1, #arr, 2 do
        table.insert(result, Utils.convertRegistersToInt32(arr[i], arr[i+1]))
    end
    return result, nil
end

function Utils.convertRegistersToAddress(reg1, reg2, le)
    if not le then
       return
            bit32.rshift(reg1, 8) .. '.' ..
            bit32.band(reg1, 0xFF) .. '.' ..
            bit32.rshift(reg2, 8) .. '.' ..
            bit32.band(reg2, 0xFF)
    else
        return
            bit32.band(reg2, 0xFF) .. '.' ..
            bit32.rshift(reg2, 8) .. '.' ..
            bit32.band(reg1, 0xFF) .. '.' ..
            bit32.rshift(reg1, 8)
    end
end

function Utils.convertBytesToAddress(byte1, byte2, byte3, byte4)
    if(byte1 ~= nil and byte2 ~= nil and byte3 ~= nil and byte4 ~= nil) then
       return byte1 .. '.' .. byte2 .. '.' .. byte3 .. '.' .. byte4
    else
        return ''   --Invalid IP
    end
end

function Utils.convertBytesToMac(bytes)
    local macAddress, byte = '', ''
    for el = 1, 6 do
        byte = string.format("%02X", bytes[el])
        macAddress = macAddress .. byte .. " "
    end
    return macAddress
end

function Utils.convertBytesToVersion(majorByte, minorByte)
    return tostring(majorByte) .. '.' .. string.format("%02u", minorByte)
end

-- Simulates a response from the server
function Utils.generateRandomNumberTable(numberOfNumbers)
    local result = {}
    for i=1, numberOfNumbers do
        table.insert(result, math.random(100))
    end
    return result
end

function Utils.nToBinStr(num, bits)
    if not bits then bits = 0 end
    local t={} -- will contain the bits
    local bit
    local ctr = 0
    while num>0 do
        bit = bit32.band(num,1)
        table.insert(t, 1, bit)
        num = bit32.rshift(num,1)
        ctr = ctr + 1
    end
    while #t < bits do
        table.insert(t, 1, 0)
    end
    return table.concat(t)
end

return Utils