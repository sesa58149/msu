local Chart = {}

--Convert everything to milliseconds to store in the database
function Chart.convertPlotFrequency(plotFrequency, plotFrequencyUnit)
    plotFrequencyUnit = tonumber(plotFrequencyUnit)
    plotFrequency = tonumber(plotFrequency)

    if plotFrequencyUnit == Constants.SECONDS then
        plotFrequency = plotFrequency * 1000
    elseif plotFrequencyUnit == Constants.MINUTES then
        plotFrequency = plotFrequency * 1000 * 60
    elseif plotFrequencyUnit == Constants.HOURS then
        plotFrequency = plotFrequency * 1000 * 60 * 60
    end

    return plotFrequency
end
function Chart.create(chartData)
    local env = luasql.sqlite()
    local connection = env:connect(Constants.DB_PATH)
    local isLockAcquired = connection:setautocommit('IMMEDIATE', 1000)
    local result = false
    local errorMsg = nil

    if isLockAcquired then
        local validChart = false
        --Avoid XSS
        chartData.id = gf.htmlspecialchars(chartData.id)

        validChart, errorMsg = Chart.validateChart(connection, chartData, false)
        if validChart then
            --if chartData.autoScale then chartData.autoScale = 1 else chartData.autoScale = 0 end
            chartData.plotFrequency = Chart.convertPlotFrequency(chartData.plotFrequency, chartData.plotFrequencyUnit);
            local cursor = connection:prepare([[
                    INSERT INTO chart
                        (name, plot_frequency, plot_frequency_unit, auto_scale, y_min, y_max, plot_points)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                ]])
            cursor:bind{
                {'TEXT', chartData.id},
                {'INTEGER', tonumber(chartData.plotFrequency)},
                {'INTEGER', tonumber(chartData.plotFrequencyUnit)},
                {'INTEGER', tonumber(chartData.autoScale)},
                {'INTEGER', tonumber(chartData.yMin)},--REAL causes error in KALA
                {'INTEGER', tonumber(chartData.yMax)},--REAL causes error in KALA
                {'INTEGER', tonumber(chartData.plotPoints)}
            }

            local exec = cursor:execute()
            if not exec then
                errorMsg = ErrorCodes.CREATE_CHART_FAILED
            else
                if connection:commit() then
                    result = true
                else
                    errorMsg = ErrorCodes.COMMIT_FAIL
                end
            end

            if not cursor:close() then
                trace('FAILED TO CLOSE CURSOR')
            end
        end
    else
        errorMsg = ErrorCodes.LOCK_FAIL
    end
    -- Close connection to database
    if not connection:close() then
        trace('FAILED TO CLOSE SQLITE CONNECTION')
    end
    -- Close connection to SQLite
    if not env:close() then
        trace('FAILED TO CLOSE SQLITE ENVIRONMENT')
    end

    return result, errorMsg
end

function Chart.update(chartData)
    local env = luasql.sqlite()
    local connection = env:connect(Constants.DB_PATH)
    local isLockAcquired = connection:setautocommit('IMMEDIATE', 1000)
    local result = false
    local errorMsg = nil

    if isLockAcquired then
        local validChart = false
        --Avoid XSS
        chartData.id = gf.htmlspecialchars(chartData.id)
        
        validChart, errorMsg = Chart.validateChart(connection, chartData, true)
        if validChart then
            --if chartData.autoScale then chartData.autoScale = 1 else chartData.autoScale = 0 end
            chartData.plotFrequency = Chart.convertPlotFrequency(chartData.plotFrequency, chartData.plotFrequencyUnit);
            local cursor = connection:prepare([[
                UPDATE chart SET
                    name = ( ? ),
                    plot_frequency = ( ? ),
                    plot_frequency_unit = ( ? ),
                    auto_scale = ( ? ),
                    y_min = ( ? ),
                    y_max = ( ? ),
                    plot_points = ( ? )
                WHERE name NOT NULL and name == ( ? )
            ]])
            cursor:bind{
                {'TEXT', chartData.id},
                {'INTEGER', tonumber(chartData.plotFrequency)},
                {'INTEGER', tonumber(chartData.plotFrequencyUnit)},
                {'INTEGER', tonumber(chartData.autoScale)},
                {'INTEGER', tonumber(chartData.yMin)},
                {'INTEGER', tonumber(chartData.yMax)},
                {'INTEGER', tonumber(chartData.plotPoints)},
                {'TEXT', chartData.previousId}
            }

            local numberOfRows = cursor:execute()

            if(numberOfRows == 1) then
                cursor = connection:prepare([[
                    UPDATE chart_variable
                        SET chart_name = ( ? )
                    WHERE chart_name == ( ? )
                ]])
                cursor:bind{
                    {'TEXT', chartData.id},
                    {'TEXT', chartData.previousId}
                }

                local exec = cursor:execute()
                if not exec then
                    errorMsg = ErrorCodes.UPDATE_CHART_VARS_FAILED
                else
                    if connection:commit() then
                        result = true
                    else
                        errorMsg = ErrorCodes.COMMIT_FAIL
                    end
                end
            else
                errorMsg = ErrorCodes.UPDATE_CHART_FAILED
            end
            if not cursor:close() then
                trace('FAILED TO CLOSE CURSOR')
            end
        end
    else
        errorMsg = ErrorCodes.LOCK_FAIL
    end
    -- Close connection to database
    if not connection:close() then
        trace('FAILED TO CLOSE SQLITE CONNECTION')
    end
    -- Close connection to SQLite
    if not env:close() then
        trace('FAILED TO CLOSE SQLITE ENVIRONMENT')
    end

    return result, errorMsg
end

function Chart.delete(chartName)
    local result = false
    local errorMsg = nil
    -- Grab a references to the SQLite environment
    local env = luasql.sqlite()
    -- Connect to the database with write permissions
    local connection = env:connect(Constants.DB_PATH)
    -- Establish how long to wait for the write lock on the database and acquire the lock
    local isLockAcquired = connection:setautocommit('IMMEDIATE', 1000)
    -- Delete the page if the lock has been acquired
    if isLockAcquired then
        local chartExists = false
        chartExists, errorMsg = Chart.exists(connection, chartName)
        if chartExists then
            -- Prepare the query
            local cursor = connection:prepare([[
                DELETE FROM chart_variable
                WHERE chart_name = ( ? )
            ]])
            -- Bind chart to the prepared statement
            cursor:bind{{'TEXT', chartName}}

            -- Execute query
            local variableRowsDeleted = cursor:execute()

            if not variableRowsDeleted then
                errorMsg = ErrorCodes.DEL_CHART_VARS_FAILED

                --if not connection:rollback() then
                --  trace('ROLLBACK FAILED')
                --end
            else
                -- Prepare the query
                local cursor =
                    connection:prepare([[
                        DELETE FROM chart
                        WHERE chart.name = ( ? )
                    ]])

                -- Bind chart to the prepared statement
                cursor:bind{{'TEXT', chartName}}

                -- Execute query
                local numChartsDeleted = cursor:execute()

                if not numChartsDeleted then
                    errorMsg = ErrorCodes.DELETE_CHART_FAILED

                    --if not connection:rollback() then
                    --  trace('ROLLBACK FAILED')
                    --end
                else
                    -- Commit the transaction
                    if connection:commit() then
                        result = true
                    else
                        errorMsg = ErrorCodes.COMMIT_FAIL
                    end
                end
                -- Close cursor connection to database
                if not cursor:close() then
                    trace('FAILED TO CLOSE CURSOR')
                end
            end
            -- Close cursor connection to database
            if not cursor:close() then
                trace('FAILED TO CLOSE CURSOR')
            end
        elseif not chartExists and not errorMsg then
            errorMsg = ErrorCodes.CHART_DOES_NOT_EXIST
        end
    else
        errorMsg = ErrorCodes.LOCK_FAIL
    end
    -- Close connection to database
    if not connection:close() then
        trace('FAILED TO CLOSE SQLITE CONNECTION')
    end
    -- Close connection to SQLite
    if not env:close() then
        trace('FAILED TO CLOSE SQLITE ENVIRONMENT')
    end

    return result, errorMsg
end

function Chart.getCharts(chartName)
    local env = luasql.sqlite()
    local connection = env:connect(Constants.DB_PATH, 'READONLY')
    local errorMsg = nil
    local result = {}
    local chart = {}
    local cursor = nil
    if chartName then
        local chartExists = false
        chartExists, errorMsg = Chart.exists(connection, chartName)

        if chartExists then
            cursor = connection:prepare([[SELECT * FROM chart WHERE name == ( ? )]])
            cursor:bind{{'TEXT', chartName}}

            local exec = cursor:execute()
            if exec then
                -- Grab results in a table
                cursor:fetch(chart, 'a')
                local obj = {
                    id = chart.name,
                    plotFrequency = tonumber(chart.plot_frequency),
                    plotFrequencyUnit = tonumber(chart.plot_frequency_unit),
                    autoScale = tonumber(chart.auto_scale),
                    yMin = tonumber(chart.y_min),
                    yMax = tonumber(chart.y_max),
                    plotPoints = tonumber(chart.plot_points)
                }
                table.insert(result, obj)
            else
                errorMsg = ErrorCodes.GET_CHART_FAILED
                result = nil
            end
        elseif not chartExists and not errorMsg then
            errorMsg = ErrorCodes.CHART_DOES_NOT_EXIST
            result = nil
        end
    else
        cursor = connection:prepare([[SELECT * FROM chart]])

        local exec = cursor:execute()
        if exec then
            -- Grab results in a table
            cursor:fetch(chart, 'a')

            -- While chart is not nil and is not an empty table
            while (chart and next(chart)) do
                local numVars = Chart.getNumberOfVariablesInChart(connection, chart.name)
                local obj = {
                    id = chart.name,
                    numVars = numVars
                }
                table.insert(result, obj)
                -- Grab results in a table
                chart = cursor:fetch(chart, 'a')
            end
        else
            errorMsg = ErrorCodes.GET_CHART_NAMES_ERROR
            result = nil
        end
    end


    -- Clean up
    if not cursor:close() then
        trace('FAILED TO CLOSE CURSOR')
    end

    if not connection:close() then
        trace('FAILED TO CLOSE SQLITE CONNECTION')
    end

    if not env:close() then
        trace('FAILED TO CLOSE SQLITE ENVIRONMENT')
    end

    return result, errorMsg
end

-- @func exists
-- @desc Detects whether a user exists with a specific chart
-- @param chart [String] The chart that you wish to see if a user already exists for
function Chart.exists(connection, chartName)
    local result = false
    local errorMsg = nil
    -- Prepare query to identify whether the user exists or not
    local cursor =
        connection:prepare([[
            SELECT count(*)
            FROM chart
            WHERE chart.name = ( ? )
        ]])

    if cursor then
        -- Bind chart to the prepared statement
        cursor:bind{{'TEXT', chartName}}
        -- Execute query
        local exec = cursor:execute()
        if exec then
            local queryResult = {}
            cursor:fetch(queryResult)

            local numberOfCharts = queryResult[1]
            result = tonumber(numberOfCharts) > 0
        else
            errorMsg = ErrorCodes.DATABASE_ERROR
        end
        -- Clean up database connections
        if not cursor:close() then
            trace('FAILED TO CLOSE CURSOR')
        end
    else
        errorMsg = ErrorCodes.INVALID_SQL_SYNTAX
    end

    return result, errorMsg
end

--TODO: Handle constructed error messages for i18n
function Chart.validateChart(connection, chartData, isUpdate)
    local errorMsg = nil
    local result = nil

    if not type(chartData.id) == "string" or chartData.id == "" then
        errorMsg = ErrorObject.new(ErrorCodes.FIELD_REQUIRED, '', {field = 'id'})
        return false, errorMsg
    end
    if not type(chartData.plotFrequency) == 'string' or chartData.plotFrequency == "" then
        errorMsg = ErrorObject.new(ErrorCodes.FIELD_REQUIRED, '', {field = 'plotFrequency'})
        return false, errorMsg
    end
    if not type(chartData.plotFrequencyUnit) == 'string' or chartData.plotFrequencyUnit == "" then
        errorMsg = ErrorObject.new(ErrorCodes.FIELD_REQUIRED, '', {field = 'plotFrequencyUnit'})
        return false, errorMsg
    end
    if type(chartData.autoScale) ~= 'boolean' or chartData.autoScale == nil then
        errorMsg = ErrorObject.new(ErrorCodes.FIELD_REQUIRED, '', {field = 'autoScale'})
        return false, errorMsg
    end
    if not type(chartData.yMin) == 'string' or tonumber(chartData.yMin) == nil then
        errorMsg = ErrorObject.new(ErrorCodes.FIELD_INVALID, '', {field = 'yMin'})
        return false, errorMsg
    end
    if not type(chartData.yMax) == 'string'or tonumber(chartData.yMax) == nil then
        errorMsg = ErrorObject.new(ErrorCodes.FIELD_INVALID, '', {field = 'yMax'})
        return false, errorMsg
    end
    if not type(chartData.plotPoints) == 'string' or chartData.plotPoints == "" then
        errorMsg = ErrorObject.new(ErrorCodes.FIELD_REQUIRED, '', {field = 'plotPoints'})
        return false, errorMsg
    end
    if not gf.checkLength(chartData.id, Constants.MIN_CHART_NAME_LENGTH, Constants.MAX_CHART_NAME_LENGTH) then
       -- local msg = "Chart name must be between "..Constants.MIN_CHART_NAME_LENGTH.." and "..Constants.MAX_CHART_NAME_LENGTH.." characters long."
        errorMsg = ErrorObject.new(ErrorCodes.FIELD_LENGTH_BETWEEN_RANGE , '' , {field = 'id', parameterMsg = {Constants.MIN_CHART_NAME_LENGTH, Constants.MAX_CHART_NAME_LENGTH}})
        return false, errorMsg
    end

    if not (chartData.id):match('^[%w_]+$') then
        errorMsg = ErrorObject.new(ErrorCodes.FIELD_INVALID, '', {field = 'id'})
        return false, errorMsg
    end

    result, errorMsg = Chart.exists(connection, chartData.id)
    if result and not isUpdate then
        errorMsg = ErrorObject.new(ErrorCodes.FIELD_ALREADY_EXIST, '', {field = 'id'})
        return false, errorMsg
    elseif errorMsg then
        return false, errorMsg
    end
    if tonumber(chartData.plotFrequencyUnit) == nil or not gf.checkValue(chartData.plotFrequencyUnit, Constants.MIN_FREQUENCY_UM, Constants.MAX_FREQUENCY_UM) then
        errorMsg = ErrorObject.new(ErrorCodes.FIELD_INVALID, '', {field = 'plotFrequencyUnit'})
        return false, errorMsg
    end
    --[TODO]: No max plot frequency - currently set at 10,000
    if  tonumber(chartData.plotFrequency) == nil or not gf.checkValue(chartData.plotFrequency, Constants.MIN_PLOT_FREQUENCY, Constants.MAX_PLOT_FREQUENCY) then
        local msg = "Chart's plot frequency must be between "..Constants.MIN_PLOT_FREQUENCY.." and "..Constants.MAX_PLOT_FREQUENCY.."."
        errorMsg = ErrorObject.new(ErrorCodes.FIELD_VALUE_BETWEEN_RANGE, '', {field = 'plotFrequency', parameterMsg = {Constants.MIN_PLOT_FREQUENCY, Constants.MAX_PLOT_FREQUENCY}})
        return false, errorMsg
    end
    if chartData.plotFrequencyUnit == Constants.MILLISECONDS and
        chartData.plotFrequency < Constants.LOW_MS then
            errorMsg = ErrorObject.new(ErrorCodes.LESS_THAN_500_MS)
        return false, errorMsg
    end
    -- TODO: Need to define what the types are going to be for all inputs.
    if chartData.autoScale then chartData.autoScale = 1 else chartData.autoScale = 0 end

    if not gf.checkValue(chartData.autoScale, Constants.MIN_AUTO_SCALE, Constants.MAX_AUTO_SCALE) then
        local msg = "Chart's auto scale must be between "..Constants.MIN_AUTO_SCALE.." and "..Constants.MAX_AUTO_SCALE.."."
        errorMsg = ErrorObject.new(ErrorCodes.FIELD_INVALID, msg, {field = 'autoScale'})
        return false, errorMsg
    end

    if type(chartData.yMin) == "string" then
        chartData.yMin = tonumber(chartData.yMin)
    end

    if type(chartData.yMax) == "string" then
        chartData.yMax = tonumber(chartData.yMax)
    end

    if chartData.yMin >= chartData.yMax then
        errorMsg = ErrorCodes.YMIN_GT_YMAX
        return false,  ErrorObject.new(errorMsg)
    end
    if not gf.checkValue(chartData.yMin, Constants.MIN_Y_MIN, chartData.yMax) then
        --local msg = "Chart's Y-Min value must be between "..Constants.MIN_Y_MIN.." and "..chartData.yMax.."."
        errorMsg = ErrorObject.new(ErrorCodes.FIELD_VALUE_BETWEEN_RANGE, '', {field = 'yMin', parameterMsg = {Constants.MIN_Y_MIN, chartData.yMax}})
        return false, errorMsg
    end
    if not gf.checkValue(chartData.yMax, chartData.yMin, Constants.MAX_Y_MAX) then
        --local msg = "Chart's Y-Max value must be between "..chartData.yMin.." and "..Constants.MAX_Y_MAX.."."
        errorMsg = ErrorObject.new(ErrorCodes.FIELD_VALUE_BETWEEN_RANGE, '', {field = 'yMax', parameterMsg = {chartData.yMin, Constants.MAX_Y_MAX}})
        return false, errorMsg
    end
    if tonumber(chartData.plotPoints) == nil or not gf.checkValue(chartData.plotPoints, Constants.MIN_PLOT_POINTS, Constants.MAX_PLOT_POINTS) then
        --local msg = "Chart's plot points value must be between "..Constants.MIN_PLOT_POINTS.." and "..Constants.MAX_PLOT_POINTS.."."
        errorMsg = ErrorObject.new(ErrorCodes.FIELD_VALUE_BETWEEN_RANGE, '', {field = 'plotPoints', parameterMsg = {Constants.MIN_PLOT_POINTS,Constants.MAX_PLOT_POINTS}})
        return false, errorMsg
    end

    return true, nil
end

function Chart.getNumberOfVariablesInChart(connection, chartName)
    local result = false
    local errorMsg = nil

    local cursor = connection:prepare([[
        SELECT COUNT(*)
        FROM chart_variable
        WHERE chart_name == ( ? )
    ]])
    if cursor then
        cursor:bind{{'TEXT', chartName}}
        local exec = cursor:execute()
        if exec then
            -- Get the result
            local queryResult = {}
            cursor:fetch(queryResult)

            result = tonumber(queryResult[1])
        else
            errorMsg = ErrorCodes.DATABASE_ERROR
        end
        -- Close cursor
        if not cursor:close() then
            trace('FAILED TO CLOSE CURSOR')
        end
    else
        errorMessage = ErrorCodes.INVALID_SQL_SYNTAX
    end

    return result, errorMsg
end

function Chart.deleteVariables(variables, chartName)
    local result = false
    local errorMsg = nil

    -- Check input types
    if (type(chartName) ~= 'string') or (type(variables) ~= 'table') then
        return result, ErrorCodes.INVALID_REQUEST
    end
    -- Check to make sure variables and chartName are the correct length
    if #variables < 0 then
        return result, ErrorCodes.INVALID_REQUEST
    elseif chartName:len() < Constants.MIN_CHART_NAME_LENGTH
        or chartName:len() > Constants.MAX_CHART_NAME_LENGTH then
        return result, ErrorCodes.INVALID_CHART_NAME_LENGTH
    end

    local env = luasql.sqlite()
    local connection = env:connect(Constants.DB_PATH)
    local isLockAcquired = connection:setautocommit('IMMEDIATE', 1000)
    if isLockAcquired then
        -- Check to make sure that the table actually exists
        local chartExists = false
        chartExists, errorMsg = Chart.exists(connection, chartName)
        if chartExists then
            local statement = 'DELETE FROM chart_variable WHERE ('
            local ctr = 0;
            local numVars = #variables
            --Loop to build statement
            for el,var in pairs(variables) do
                ctr = ctr + 1
                statement = statement .. ' (symbol = ( ? ) AND address = ( ? ))'
                if ctr < numVars then
                    statement = statement .. ' OR'
                end
            end
            statement = statement .. ') AND chart_name = ( ? )'

            local cursor = connection:prepare(statement)
            local bindings = {}
            local temp = {}

            for el,var in pairs(variables) do
                temp = {'TEXT', var.symbol}
                table.insert(bindings,temp)
                temp = {'TEXT', var.address}
                table.insert(bindings,temp)
            end
            table.insert(bindings,{'TEXT',chartName})

            cursor:bind( bindings )
            local exec = cursor:execute()

            if exec then
                -- Commit the transaction
                if connection:commit() then
                    result = true
                else
                    errorMsg = ErrorCodes.COMMIT_FAIL
                end
            else
                errorMsg = ErrorCodes.DELETE_VARS_FAILED
            end
            -- Close cursor connection
            if not cursor:close() then
                trace('FAILED TO CLOSE CURSOR')
            end
        elseif not chartExists and not errorMsg then
            errorMsg = ErrorCodes.CHART_DOES_NOT_EXIST
        end
    else
        errorMsg = ErrorCodes.LOCK_FAIL
    end
    -- Clean up
    if not connection:close() then
        trace('FAILED TO CLOSE SQLITE CONNECTION')
    end
    if not env:close() then
        trace('FAILED TO CLOSE SQLITE ENVIRONMENT')
    end

    return result, errorMsg
end

function Chart.getChartCount()
    if luasql == nil then
        return false, ErrorCodes.NO_SQL -- ONLY FOR THE NOSQL VERSION
    end

    local result = false
    local errorMsg = nil
    -- Reference SQLite environment
    local env = luasql.sqlite()
    --Create DB connection
    local connection = env:connect(Constants.DB_PATH)
    -- Establish a lock to prevent conflicting db calls
    local isLockAcquired = connection:setautocommit('IMMEDIATE', 1000)
    if isLockAcquired then

        local cursor = connection:prepare([[
            SELECT COUNT(*)
            FROM chart
        ]])
        if cursor then
            local exec = cursor:execute()
            if exec then
                local queryResult = {}
                cursor:fetch(queryResult)
                result = tonumber(queryResult[1])
            else
                errorMsg = ErrorCodes.DATABASE_ERROR
            end
            if not cursor:close() then
                trace('FAILED TO CLOSE CURSOR')
            end
        else
            errorMessage = ErrorCodes.INVALID_SQL_SYNTAX
        end

    end

    -- Close db connection
    if not connection:close() then
        trace('FAILED TO CLOSE DB CONNECTION')
    end
    if not env:close() then
        trace('FAILED TO CLOSE DB ENVIRONMENT')
    end

    return result, errorMsg
end

return Chart