local ADLRESTHandler = {}

function ADLRESTHandler.getHandler(_ENV, path)
	local result, tableData, errorMsg = nil, nil, nil
    local method = request:method()

	-- Ensure that the response is has a content type of JSON
    response:setheader('content-type', 'application/json; charset=UTF-8')

    -- Case insensitive
    path = path:lower()

    if(path == '') then
		gf.sendError(_ENV)
    elseif(path == 'readparamsnoncons' or path == 'readparamsnoncons/') then
    	if (method == 'POST') then
    		HTTPMethods.post(_ENV, ADLRESTHandler.ReadParamsNonCons, {}, nil)
	    else
	    	gf.sendError(_ENV)
	    end
	elseif(path == 'writeparamsnoncons' or path == 'writeparamsnoncons/') then
    	if (method == 'POST') then
    		HTTPMethods.post(_ENV, ADLRESTHandler.WriteParamsNonCons, {}, nil)
	    else
	    	gf.sendError(_ENV)
	    end
	elseif(path == 'getparamsdescription' or path == 'getparamsdescription/') then
		if (method == 'POST') then
			HTTPMethods.post(_ENV, ADLRESTHandler.GetParamsDescription, {}, nil)
	    else
	    	gf.sendError(_ENV)
	    end
	elseif(path == 'opensession' or path == 'opensession/') then
		if (method == 'POST') then
			HTTPMethods.post(_ENV, ADLRESTHandler.getInputDataFunc(ADL.OpenSession), {}, nil)
		else
			gf.sendError(_ENV)
		end
	elseif(path == 'closesession' or path == 'closesession/') then
		if (method == 'POST') then
			HTTPMethods.post(_ENV, ADLRESTHandler.getInputDataFunc(ADL.CloseSession), {}, nil)
		else
			gf.sendError(_ENV)
		end
	elseif(path == 'acquirecommandlock' or path == 'acquirecommandlock/') then
		if (method == 'POST') then
			HTTPMethods.post(_ENV, ADLRESTHandler.getInputDataFunc(ADL.AcquireCommandLock), {}, nil)
		else
			gf.sendError(_ENV)
		end
	elseif(path == 'heartbeat' or path == 'heartbeat/') then
		if (method == 'POST') then
			HTTPMethods.post(_ENV, ADLRESTHandler.getInputDataFunc(ADL.Heartbeat), {}, nil)
		else
			gf.sendError(_ENV)
		end
	elseif(path == 'releasecommandlock' or path == 'releasecommandlock/') then
		if (method == 'POST') then
			HTTPMethods.post(_ENV, ADLRESTHandler.getInputDataFunc(ADL.ReleaseCommandLock), {}, nil)
		else
			gf.sendError(_ENV)
		end
	elseif(path == 'getdrivestate' or path == 'getdrivestate/') then
		if (method == 'POST') then
			HTTPMethods.post(_ENV, ADLRESTHandler.getInputDataFunc(ADL.GetDriveState), {}, nil)
		else
			gf.sendError(_ENV)
		end
	elseif(path == 'writecmdandtarget' or path == 'writecmdandtarget/') then
		if (method == 'POST') then
			HTTPMethods.post(_ENV, ADLRESTHandler.getInputDataFunc(ADL.WriteCmdAndTarget), {}, nil)
		else
			gf.sendError(_ENV)
		end
	elseif(path == 'lockunlockdrive' or path == 'lockunlockdrive/') then
		if (method == 'POST') then
			HTTPMethods.post(_ENV, ADLRESTHandler.getInputDataFunc(ADL.LockUnlockDrive), {}, nil)
		else
			gf.sendError(_ENV)
		end
	elseif(path == 'devicelocalization' or path == 'devicelocalization/') then
		if (method == 'GET') then
			HTTPMethods.get(_ENV, ADL.DeviceLocalization, {}, nil)
		else
			gf.sendError(_ENV)
		end
    else
    	gf.sendError(_ENV)
    end
end

function ADLRESTHandler.getInputDataFunc(getInputDataFunc)
	return function(input)
		local result, errorMsg = nil, nil
		result, errorMsg = getInputDataFunc(input)
		if result ~= nil then
			if type(result) == 'table' then
				result, errorMsg = ba.json.encode(result)
			end
		end
		return result, errorMsg
	end
end
function ADLRESTHandler.ReadParamsNonCons(jsonObject)
	local result, errMsg = nil, nil
	local unitID = jsonObject.unitID
	local addresses = jsonObject.addresses

	if not unitID or not addresses then
		result, errMsg = nil, ErrorObject.new(ErrorCodes.INVALID_REQUEST)
	else
	    local data, errMsg = ADL.ReadParamsNonCons(unitID, addresses)
		if data then
			return ba.json.encode(data), nil
		else
			return nil, errMsg
		end
	end
	return result, errMsg
end

function ADLRESTHandler.GetParamsDescription(jsonObject)
	local result, errMsg = nil, nil
	local unitID = jsonObject.unitID
	local addresses = jsonObject.addresses

	if not unitID or not addresses then
		result, errMsg = nil,  ErrorObject.new(ErrorCodes.INVALID_REQUEST)
	else
		addresses = ADLRESTHandler.CheckAddressIsNumber(addresses)
	    local data, errMsg = ADL.GetParamsDescription(unitID, addresses)
		if data and errMsg == nil then
			for k,v in pairs(data) do
				if v['mnemonic'] then
		    		v['id'] = v['mnemonic']
		    	end
		    	if (v['type'] == 0 or v['type'] == 4) then
		    		v['options'], v['listdef'] = ADLRESTHandler.getOptions( v['mnemonic'], v['possibleValues'])
		    		v['possibleValues'] = nil
				end
		    	v['safety'] = ADLRESTHandler.getSafetyMessage(v['mnemonic'])
		    end
			return ba.json.encode(data), nil
		else
			return nil, errMsg
		end
	end
	return result, errMsg
end

function ADLRESTHandler.getSafetyMessage(id)
	if (ParametersTable ~= nil and ParametersTable.safety ~= nil) then
		local safety = ParametersTable.safety[id]
		return safety
	else
		return nil
	end
end

function ADLRESTHandler.getOptions(list, possibleValues)
    if ParametersTable ~= nil and ParametersTable.parameterlist ~= nil and ParametersTable.listparam ~= nil and ParametersTable.listdef ~= nil then
        local listId = ParametersTable.listparam[list]
        if listId ~= nil then
        	return gf.filterOptionsList(ParametersTable.listdef[listId], possibleValues), listId
        end
    end
    return nil
end

function ADLRESTHandler.WriteParamsNonCons(jsonObject)
	local result, data, errMsg = nil, nil, nil
	local unitID = jsonObject.unitID
	local address = jsonObject.address
	local value = jsonObject.value
	local mnemonicType = jsonObject.type

	if not type(unitID) == 'number' or not type(address) == 'number' or not type(mnemonicType) == 'number' or not type(value) == 'number' then
		result, errMsg = nil, ErrorObject.new(ErrorCodes.INVALID_REQUEST)
	else
	    data, errMsg = ADL.WriteParamsNonCons(unitID, address, mnemonicType, value)
		if data then
			result, errMsg = ba.json.encode(data)
		elseif (errMsg == nil) then
			result, errMsg =  nil, ErrorObject.new(ErrorCodes.INVALID_RESPONSE_FROM_SERVER)
		end
	end

	return result, errMsg
end

function ADLRESTHandler.CheckAddressIsNumber(addresses)
	if addresses and #addresses > 0 and type(addresses[1]) ~= 'number' then
		local addressesNumber = {}
		if (ParametersTable and ParametersTable.parameterlist) then
			for i=1, #addresses do
				table.insert(addressesNumber, tonumber(ParametersTable.parameterlist[addresses[i]]))
			end
		end
		return addressesNumber
	else
		return addresses
	end
end
return ADLRESTHandler