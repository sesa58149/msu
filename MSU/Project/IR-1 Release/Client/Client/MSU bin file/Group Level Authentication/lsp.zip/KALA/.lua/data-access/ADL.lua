local io = ba.openio(_G.diskIOName)
ReadParamsNonCons = io:dofile('platform/.lua/parsers/adl/ReadParamsNonCons.lua')
WriteParamsNonCons = io:dofile('platform/.lua/parsers/adl/WriteParamsNonCons.lua')
GetParamsDescription = io:dofile('platform/.lua/parsers/adl/GetParamsDescription.lua')
OpenSession = io:dofile('platform/.lua/parsers/adl/OpenSession.lua')
CloseSession = io:dofile('platform/.lua/parsers/adl/CloseSession.lua')
AcquireCommandLock = io:dofile('platform/.lua/parsers/adl/AcquireCommandLock.lua')
Heartbeat = io:dofile('platform/.lua/parsers/adl/Heartbeat.lua')
ReleaseCommandLock = io:dofile('platform/.lua/parsers/adl/ReleaseCommandLock.lua')
GetDriveState = io:dofile('platform/.lua/parsers/adl/GetDriveState.lua')
WriteCmdAndTarget = io:dofile('platform/.lua/parsers/adl/WriteCmdAndTarget.lua')
LockUnlockDrive = io:dofile('platform/.lua/parsers/adl/LockUnlockDrive.lua')
DeviceLocalization = io:dofile('platform/.lua/parsers/adl/DeviceLocalization.lua')

if not LuaADL then
	trace('The LuaADL Wrapper is not present in the device.')
end

if _G.forceSimulation then
	trace('ADL Simulation is forced')
end

local ADL = {}
function ADL.DeviceLocalization()
    return DeviceLocalization.fetch()
end
function ADL.GetParamsDescription(unitID, addresses)
	return GetParamsDescription.fetch(unitID, addresses)
end

function ADL.ReadParamsNonCons(unitID, addresses)
	return ReadParamsNonCons.fetch(unitID, addresses)
end

function ADL.WriteParamsNonCons(unitID, address, type, value)
	return WriteParamsNonCons.fetch(unitID, address, type, value)
end

function ADL.OpenSession(inputObj)
    return OpenSession.getData(inputObj)
end

function ADL.CloseSession(inputObj)
    return CloseSession.getData(inputObj)
end

function ADL.AcquireCommandLock(inputObj)
    return AcquireCommandLock.getData(inputObj)
end

function ADL.Heartbeat(inputObj)
    return Heartbeat.getData(inputObj)
end

function ADL.ReleaseCommandLock(inputObj)
    return ReleaseCommandLock.getData(inputObj)
end

function ADL.GetDriveState(inputObj)
    return GetDriveState.getData(inputObj)
end

function ADL.WriteCmdAndTarget(inputObj)
    return WriteCmdAndTarget.getData(inputObj)
end

function ADL.LockUnlockDrive(inputObj)
    return LockUnlockDrive.getData(inputObj)
end

return ADL