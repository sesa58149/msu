local Theme = {}

Theme.totalThemes = 0

function Theme.confirmData(theme)
	if not theme.description        then theme.description        = "N/A"                    end
	if not theme.logo               then theme.logo               = "1"                      end
	if not theme.title              then theme.title              = "FactoryCast&trade; Web" end
	if not theme.cTitle             then theme.cTitle             = "#FFFFFF"                end
	if not theme.cHeaderBg          then theme.cHeaderBg          = "#FFFFFF"                end
	if not theme.cHeaderTxt         then theme.cHeaderTxt         = "#FFFFFF"                end
	if not theme.cBMenu             then theme.cBMenu             = "#FFFFFF"                end
	if not theme.cBMenuTab          then theme.cBMenuTab          = "#FFFFFF"                end
	if not theme.cBMenuTabHl        then theme.cBMenuTabHl        = "#FFFFFF"                end
	if not theme.cBMenuTabTitle     then theme.cBMenuTabTitle     = "#FFFFFF"                end
	if not theme.cBMenuTabTitleHl   then theme.cBMenuTabTitleHl   = "#FFFFFF"                end
	if not theme.cBMenuTabSelTxt    then theme.cBMenuTabSelTxt    = "#FFFFFF"                end
	if not theme.cSMenuTab          then theme.cSMenuTab          = "#FFFFFF"                end
	if not theme.cSMenuTabHl        then theme.cSMenuTabHl        = "#FFFFFF"                end
	if not theme.cSMenuTabSelTop    then theme.cSMenuTabSelTop    = "#FFFFFF"                end
	if not theme.cSMenuTabSelBottom then theme.cSMenuTabSelBottom = "#FFFFFF"                end
	if not theme.cSMenuTabTxt       then theme.cSMenuTabTxt       = "#FFFFFF"                end
	if not theme.cSMenuTabTxtHl     then theme.cSMenuTabTxtHl     = "#FFFFFF"                end
	if not theme.cSMenuTabSelTxt    then theme.cSMenuTabSelTxt    = "#FFFFFF"                end
	if not theme.cPageLinks         then theme.cPageLinks         = "#FFFFFF"                end
	if not theme.cPageTitle         then theme.cPageTitle         = "#FFFFFF"                end
	if not theme.cTblHdTxt          then theme.cTblHdTxt          = "#FFFFFF"                end
	return theme
end

function Theme.addFromFile(io, fileStats, fileData)
	local success, errorMsg = false, nil
	-- Open file and get file contents
	if fileData then
		-- Create table from file contents
		local theme = ba.json.decode(fileData)
		if theme and theme.id then
			-- Make sure all data is available!!!
			theme = Theme.confirmData(theme)
			-- Call Theme.create with the table
			success, errorMsg = Theme.create(theme)
			-- Close file and delete file
			--file:close()
			if success then
				success, errorMsg = io:remove(fileStats["name"])
			end
		else
			-- If something goes wrong, get rid of the file
			-- file:close()
			if not io:remove(fileStats["name"]) then
				--Not much we can do about this...
				trace("Failed to delete file from disk")
			end
			errorMsg = ErrorCodes.INVALID_FILE_FORMAT --"Invalid file content format"
		end
	else
		-- If something goes wrong, get rid of the file
		-- file:close()
		if not io:remove(fileStats["name"]) then
			--Not much we can do about this...
			trace("Failed to delete file from disk")
		end
		errorMsg = ErrorCodes.UNABLE_TO_READ_FILE --"Unable to read file contents"
	end
	-- return success or failure with error
	return success, errorMsg
end

function Theme.create(themeData)
	if Theme.totalThemes == 10 then
		return nil, ErrorCodes.MAX_NUM_THEMES_REACHED
	end

	local result = false
	local errorMsg = nil

	-- Grab a reference to SQLite environment
	local env = luasql.sqlite()

	-- Connect to the database with write permissions
	local connection = env:connect(Constants.DB_PATH)

	-- Establish how long to wait for the write lock on the database and acquire the lock.
	local isLockAcquired = connection:setautocommit('IMMEDIATE', 1000)

	-- Delete the page if the lock has been acquired
	if isLockAcquired then
		local validTheme = false
		--Avoid XSS
        themeData.id = gf.htmlspecialchars(themeData.id)
		themeData.description = gf.htmlspecialchars(themeData.description)
		themeData.title = gf.htmlspecialchars(themeData.title)
		themeData.logo = gf.htmlspecialchars(themeData.logo)

		validTheme, errorMsg = Theme.validateTheme(connection, themeData, false)
		if validTheme then
			-- Prepare the query
			local cursor = connection:prepare(
			[[INSERT INTO themes
			VALUES(( ? ),( ? ),( ? ),( ? ),( ? ),( ? ),( ? ),( ? ),( ? ),( ? ),
				( ? ),( ? ),( ? ),( ? ),( ? ),( ? ),( ? ),( ? ),( ? ),( ? ),( ? ),
				( ? ),( ? ),( ? ))]])
			cursor:bind{
				{'TEXT', themeData.id},
				{'TEXT', themeData.description},
				{'INTEGER', themeData.logo},
				{'TEXT', themeData.title},
				{'TEXT', themeData.cTitle},
				{'TEXT', themeData.cHeaderBg},
				{'TEXT', themeData.cHeaderTxt},
				{'TEXT', themeData.cBMenu},
				{'TEXT', themeData.cBMenuTab},
				{'TEXT', themeData.cBMenuTabHl},
				{'TEXT', themeData.cBMenuTabTitle},
				{'TEXT', themeData.cBMenuTabTitleHl},
				{'TEXT', themeData.cBMenuTabSelTxt},
				{'TEXT', themeData.cSMenuTab},
				{'TEXT', themeData.cSMenuTabHl},
				{'TEXT', themeData.cSMenuTabSelTop},
				{'TEXT', themeData.cSMenuTabSelBottom},
				{'TEXT', themeData.cSMenuTabTxt},
				{'TEXT', themeData.cSMenuTabTxtHl},
				{'TEXT', themeData.cSMenuTabSelTxt},
				{'TEXT', themeData.cPageLinks},
				{'TEXT', themeData.cPageTitle},
				{'TEXT', themeData.cTblHdTxt},
				{'INTEGER', 0}
			}
			-- Execute query
			local exec = cursor:execute()
			if not exec then
				errorMsg = ErrorCodes.CREATE_THEME_FAILED
			else
				-- Commit the transaction
				if connection:commit() then
					result = true
					Theme.totalThemes = Theme.totalThemes + 1
				else
					errorMsg = ErrorCodes.COMMIT_FAIL
				end
			end
			-- Close cursor connection to database
			if not cursor:close() then
				trace('FAILED TO CLOSE CURSOR')
			end
		end
	else
		errorMsg = ErrorCodes.LOCK_FAIL
	end

	-- Close connection to database
	if not connection:close() then
		trace('FAILED TO CLOSE SQLITE CONNECTION')
	end
	-- Close connection to SQLite
	if not env:close() then
		trace('FAILED TO CLOSE SQLITE ENVIRONMENT')
	end

    return result, errorMsg
end
function Theme.update(themeData)
	local result = false
	local errorMsg = nil
	-- Grab a reference to SQLite environment
	local env = luasql.sqlite()

	-- Connect to the database with write permissions
	local connection = env:connect(Constants.DB_PATH)

	-- Establish how long to wait for the write lock on the database and acquire the lock.
	local isLockAcquired = connection:setautocommit('IMMEDIATE', 1000)

	-- Delete the page if the lock has been acquired
	if isLockAcquired then
		local validTheme = false
		--Avoid XSS
        themeData.id = gf.htmlspecialchars(themeData.id)
		themeData.description = gf.htmlspecialchars(themeData.description)
		themeData.title = gf.htmlspecialchars(themeData.title)
		themeData.logo = gf.htmlspecialchars(themeData.logo)

		validTheme, errorMsg = Theme.validateTheme(connection, themeData, true)
		if validTheme then
			-- Prepare the query
			local cursor = connection:prepare(
				[[UPDATE themes SET
					theme_desc = ( ? ),
					theme_logo = ( ? ),
					site_title = ( ? ),
					main_title_color = ( ? ),
					header_background_color = ( ? ),
					header_text_color = ( ? ),
					bottom_menu_color = ( ? ),
					bottom_menu_tab_color = ( ? ),
					bottom_menu_tab_highlight_color = ( ? ),
					bottom_menu_tab_title_text_color = ( ? ),
					bottom_menu_tab_title_text_highlight_color = ( ? ),
					bottom_menu_tab_selected_text_color = ( ? ),
					side_menu_tab_color = ( ? ),
					side_menu_tab_highlight_color = ( ? ),
					side_menu_tab_selected_top_color = ( ? ),
					side_menu_tab_selected_bottom_color = ( ? ),
					side_menu_tab_text_color = ( ? ),
					side_menu_tab_text_highlight_color = ( ? ),
					side_menu_tab_selected_text_color = ( ? ),
					page_links_color = ( ? ),
					page_title_color = ( ? ),
					table_header_text_color = ( ? ),
					is_current_theme = ( ? )
				WHERE theme_name NOT NULL and theme_name == ( ? )]])
				cursor:bind{
					{'TEXT', themeData.description},
					{'INTEGER', themeData.logo},
					{'TEXT', themeData.title},
					{'TEXT', themeData.cTitle},
					{'TEXT', themeData.cHeaderBg},
					{'TEXT', themeData.cHeaderTxt},
					{'TEXT', themeData.cBMenu},
					{'TEXT', themeData.cBMenuTab},
					{'TEXT', themeData.cBMenuTabHl},
					{'TEXT', themeData.cBMenuTabTitle},
					{'TEXT', themeData.cBMenuTabTitleHl},
					{'TEXT', themeData.cBMenuTabSelTxt},
					{'TEXT', themeData.cSMenuTab},
					{'TEXT', themeData.cSMenuTabHl},
					{'TEXT', themeData.cSMenuTabSelTop},
					{'TEXT', themeData.cSMenuTabSelBottom},
					{'TEXT', themeData.cSMenuTabTxt},
					{'TEXT', themeData.cSMenuTabTxtHl},
					{'TEXT', themeData.cSMenuTabSelTxt},
					{'TEXT', themeData.cPageLinks},
					{'TEXT', themeData.cPageTitle},
					{'TEXT', themeData.cTblHdTxt},
					{'INTEGER', tonumber(themeData.current)},
					{'TEXT', themeData.id}
				}
			-- Execute query
			local exec = cursor:execute()
			if not exec then
				errorMsg = ErrorCodes.UPDATE_THEME_FAILED
			else
				if tonumber(themeData.current) == 1 then
					cursor = connection:prepare(
						[[UPDATE themes SET
							is_current_theme = 0
							WHERE theme_name <> ( ? )]]
					)
					cursor:bind{
						{'TEXT', themeData.id}
					}
					exec = cursor:execute()
					if not exec then
						errorMsg = ErrorCodes.UPDATE_THEME_FAILED
					else
						-- Commit the transaction
						if connection:commit() then
							result = true
						else
							errorMsg = ErrorCodes.COMMIT_FAIL
						end
					end
				else
					-- Commit the transaction
					if connection:commit() then
						result = true
						--Theme.savePublicTheme(themeData.cBMenu, themeData.logo)
					else
						errorMsg = ErrorCodes.COMMIT_FAIL
					end
				end
			end
			-- Close cursor connection to database
			if not cursor:close() then
				trace('FAILED TO CLOSE CURSOR')
			end
		end
	else
		errorMsg = ErrorCodes.LOCK_FAIL
	end

	-- Close connection to database
	if not connection:close() then
		trace('FAILED TO CLOSE SQLITE CONNECTION')
	end
	-- Close connection to SQLite
	if not env:close() then
		trace('FAILED TO CLOSE SQLITE ENVIRONMENT')
	end

    return result, errorMsg
end
function Theme.get(themeName)
	local env = luasql.sqlite()
	local connection = env:connect(Constants.DB_PATH, 'READONLY')
	local cursor, errorMsg = nil
	local result = {}
	local theme = {}

	if themeName ~= nil then
		-- Build prepared statement
		cursor = connection:prepare(
			[[SELECT * FROM themes, logos WHERE themes.theme_name = ( ? ) AND themes.theme_logo = logos.logo_id]])
		cursor:bind{{'TEXT', themeName}}
	else
		cursor = connection:prepare([[SELECT * FROM themes, logos WHERE themes.theme_logo = logos.logo_id]])
	end

	local exec = cursor:execute()
	if exec then
		-- Store results in a table (array)
		cursor:fetch(theme, 'a')
		-- While user is not nil and is not an empty table
		while(theme and next(theme)) do
			local tObj = {
				id = theme.theme_name,
				description = theme.theme_desc,
				logo = theme.theme_logo,
				title = theme.site_title,
				cTitle = theme.main_title_color,
				cHeaderBg = theme.header_background_color,
				cHeaderTxt = theme.header_text_color,
				cBMenu = theme.bottom_menu_color,
				cBMenuTab = theme.bottom_menu_tab_color,
				cBMenuTabHl = theme.bottom_menu_tab_highlight_color,
				cBMenuTabTitle = theme.bottom_menu_tab_title_text_color,
				cBMenuTabTitleHl = theme.bottom_menu_tab_title_text_highlight_color,
				cBMenuTabSelTxt = theme.bottom_menu_tab_selected_text_color,
				cSMenuTab = theme.side_menu_tab_color,
				cSMenuTabHl = theme.side_menu_tab_highlight_color,
				cSMenuTabSelTop = theme.side_menu_tab_selected_top_color,
				cSMenuTabSelBottom = theme.side_menu_tab_selected_bottom_color,
				cSMenuTabTxt = theme.side_menu_tab_text_color,
				cSMenuTabTxtHl = theme.side_menu_tab_text_highlight_color,
				cSMenuTabSelTxt = theme.side_menu_tab_selected_text_color,
				cPageLinks = theme.page_links_color,
				cPageTitle = theme.page_title_color,
				cTblHdTxt = theme.table_header_text_color,
				current = theme.is_current_theme,
				logo_name = theme.logo_name
			}
			table.insert(result, tObj)
			-- Get results in a table
			theme = cursor:fetch(theme, 'a')
		end

		-- Since the user needs to go to the theme page to create a theme, we can
		-- keep a running total of all the themes so we don't need to count them
		-- with a database query
		if #result > 1 then Theme.totalThemes = #result end
	else
		result = false
		errorMsg = ErrorCodes.GET_THEMES_FAILED
	end

	-- Clean up
	if not cursor:close() then
		trace('FAILED TO CLOSE CURSOR')
	end

	if not connection:close() then
		trace('FAILED TO CLOSE SQLITE CONNECTION')
	end

	if not env:close() then
		trace('FAILED TO CLOSE SQLITE ENVIRONMENT')
	end

    return result, errorMsg
end
function Theme.exists(connection, themeName)
	local result = false
	local errorMsg = nil
	-- Prepare database call
	local cursor = connection:prepare(
		[[SELECT count(*) FROM themes WHERE themes.theme_name = ( ? )]])
	if cursor then
		-- Bind theme name to previous query statement
		cursor:bind{{'TEXT', themeName}}
		-- Execute the query
		local exec = cursor:execute()
		if exec then
			local queryResult = {}
			cursor:fetch(queryResult)

			local numberOfThemesWithSameName = queryResult[1]
			result = tonumber(numberOfThemesWithSameName) > 0
		else
			errorMsg = ErrorCodes.DATABASE_ERROR
		end
		-- Clean up
		if not cursor:close() then
			trace('FAILED TO CLOSE CURSOR')
		end
	else
		errorMsg = ErrorCodes.INVALID_SQL_SYNTAX
	end

	return result, errorMsg
end
function Theme.delete(themeName)
	local result = false
	local errorMsg = nil
	if themeName ~= "Schneider" then
		-- Reference SQLite environment
		local env = luasql.sqlite()
		--Create DB connection
		local connection = env:connect(Constants.DB_PATH)
		-- Establish a lock to prevent conflicting db calls
		local hasLock = connection:setautocommit('IMMEDIATE', 1000)
		if hasLock then
			local doesThemeExist = false
			local currentTheme = true
			doesThemeExist, errorMsg = Theme.exists(connection, themeName)
			currentTheme, errorMsg = Theme.isCurrentTheme(connection, themeName)
			-- If the theme exists, delete it
			if doesThemeExist and not currentTheme then
				-- Prepare database call
				local cursor = connection:prepare(
					[[DELETE FROM themes WHERE themes.theme_name = ( ? )]])
				-- Bind theme name to previous query statement
				cursor:bind{{'TEXT', themeName}}
				-- Execute the query
				local exec = cursor:execute()

				if not exec then
					errorMsg = ErrorCodes.DELETE_THEME_FAILED
				else
					-- Commit the transaction
					if connection:commit() then
						result = true
						if Theme.totalThemes > 0 then
							Theme.totalThemes = Theme.totalThemes - 1
						end
					else
						errorMsg = ErrorCodes.COMMIT_FAIL
					end
				end
				-- Close cursor connection
				if not cursor:close() then
					trace('FAILED TO CLOSE CURSOR')
				end
			elseif not doesThemeExist and not errorMsg then
				errorMsg = ErrorCodes.THEME_DOES_NOT_EXIST
			end
		else
			errorMsg = ErrorCodes.LOCK_FAIL
		end

		-- Close db connection
		if not connection:close() then
			trace('FAILED TO CLOSE DB CONNECTION')
		end
		if not env:close() then
			trace('FAILED TO CLOSE DB ENVIRONMENT')
		end
	else
		errorMsg = ErrorCodes.CANNOT_DELETE_DEFAULT
	end
	--Return results
	return result, errorMsg
end

function Theme.validateTheme(connection, themeData, isUpdate)
	local errorMsg = ''
	local result = nil

	if not themeData.id or themeData.id == "" then
		errorMsg = ErrorCodes.THEME_NAME_REQUIRED
		return false, errorMsg
	end
	if not gf.checkLength(themeData.id, Constants.MIN_THEME_NAME_LENGTH, Constants.MAX_THEME_NAME_LENGTH) then
		errorMsg = ErrorObject.new(ErrorCodes.FIELD_LENGTH_BETWEEN_RANGE, nil, { field = "tName", parameterMsg = { Constants.MIN_THEME_NAME_LENGTH, Constants.MAX_THEME_NAME_LENGTH } })
		return false, errorMsg
	end
	result, errorMsg = Theme.exists(connection, themeData.id)
	if result and not isUpdate then
		errorMsg = ErrorObject.new(ErrorCodes.THEME_EXISTS, nil, { field = "tName" })
		return false, errorMsg
	elseif errorMsg then
		return false, errorMsg
	end
	if not gf.checkLength(themeData.description, Constants.MIN_THEME_DESC_LENGTH, Constants.MAX_THEME_DESC_LENGTH) then
		errorMsg = ErrorObject.new(ErrorCodes.FIELD_LENGTH_BETWEEN_RANGE, nil, { field = "tDesc", parameterMsg = { Constants.MIN_THEME_DESC_LENGTH, Constants.MAX_THEME_DESC_LENGTH } })
		return false, errorMsg
	end
	if not gf.checkLength(themeData.title, Constants.MIN_SITE_TITLE_LENGTH, Constants.MAX_SITE_TITLE_LENGTH) then
		errorMsg = ErrorObject.new(ErrorCodes.FIELD_LENGTH_BETWEEN_RANGE, nil, { field = "tSiteTitle", parameterMsg = { Constants.MIN_SITE_TITLE_LENGTH, Constants.MAX_SITE_TITLE_LENGTH } })
		return false, errorMsg
	end

	return true, nil
end

function Theme.isCurrentTheme(connection, themeName)
	local result = false
	local errorMsg = nil
	-- Prepare database call
	local cursor = connection:prepare(
		[[SELECT is_current_theme FROM themes WHERE themes.theme_name = ( ? )]])
	if cursor then
		-- Bind theme name to previous query statement
		cursor:bind{{'TEXT', themeName}}
		-- Execute the query
		local exec = cursor:execute()
		if exec then
			local queryResult = {}
			cursor:fetch(queryResult, 'a')

			local currentThemeField = queryResult.is_current_theme
			result = tonumber(currentThemeField) > 0
		else
			errorMsg = ErrorCodes.DATABASE_ERROR
		end
		-- Clean up
		if not cursor:close() then
			trace('FAILED TO CLOSE CURSOR')
		end
	else
		errorMsg = ErrorCodes.INVALID_SQL_SYNTAX
	end

	return result, errorMsg
end

return Theme