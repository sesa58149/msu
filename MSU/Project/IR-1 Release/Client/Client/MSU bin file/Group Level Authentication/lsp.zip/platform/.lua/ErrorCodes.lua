local ErrorCodes = {}

ErrorCodes.NO_SQL = 'NO_SQL_AVAILABLE'
ErrorCodes.UNKNOWN_ERROR = 'UNKNOWN_ERROR'
ErrorCodes.NOT_IMPLEMENTED = 'NOT_IMPLEMENTED'
ErrorCodes.INVALID_REQUEST = 'INVALID_REQUEST'      --Invalid HTTP Request
ErrorCodes.INVALID_SERVER_RESPONSE = 'INVALID_SERVER_RESPONSE'
ErrorCodes.PAYLOAD_LENGTH = 'PAYLOAD_LENGTH'            --Payload length too long
ErrorCodes.DECODE_ERROR = 'DECODE_ERROR'            --Error decoding JSON
ErrorCodes.INVALID_DATATYPE = 'INVALID_DATATYPE'
ErrorCodes.INVALID_VALUE = 'INVALID_VALUE'

ErrorCodes.UNSPECIFIED_DIAG = 'UNSPECIFIED_DIAG'        --Unspecified diagnostic service requested
ErrorCodes.DIAG_DOES_NOT_EXIST = 'DIAG_DOES_NOT_EXIST'  --Diagnostic function does not exist
ErrorCodes.INT32_CONVERSION_ERR = 'INT32_CONVERSION_ERR'    --An error occurred converting byte array to int32 array
ErrorCodes.MODBUS_READ_FAILED = 'MODBUS_READ_FAILED'    --An error occurred getting the result from Modbus
ErrorCodes.PORT_STATS_RESET_FAILED = 'PORT_STATS_RESET_FAILED'  --Could not reset the port statistics counters
ErrorCodes.ADL_READ_FAILED			= 'ADL_READ_FAILED'
ErrorCodes.ADL_WRITE_FAILED			= 'ADL_WRITE_FAILED'

ErrorCodes.LOCK_FAIL = 'LOCK_FAIL'              --Failed to acquire lock in database
ErrorCodes.COMMIT_FAIL = 'COMMIT_FAIL'          --Commit failed
ErrorCodes.DATABASE_ERROR = 'DATABASE_ERROR'            --An unexpected error occurred while accessing the database
ErrorCodes.INVALID_SQL_SYNTAX = 'INVALID_SQL_SYNTAX'        --SQL Syntax Error
ErrorCodes.NO_MENU_ITEMS = 'NO_MENU_ITEMS'          --No menu items returned

ErrorCodes.GET_DASHBOARD_FAILED = 'GET_DASHBOARD_FAILED'        --Unable to retrieve dashboard

ErrorCodes.GET_PW_POLICY_FAILED = 'GET_PW_POLICY_FAILED'
ErrorCodes.SET_PW_POLICY_FAILED = 'SET_PW_POLICY_FAILED'

ErrorCodes.NO_FILE_PROVIDED    = 'NO_FILE_PROVIDED'
ErrorCodes.CANNOT_ACCESS_DISK  = 'CANNOT_ACCESS_DISK'
ErrorCodes.INVALID_FILE_FORMAT = 'INVALID_FILE_FORMAT'
ErrorCodes.UNABLE_TO_READ_FILE = 'UNABLE_TO_READ_FILE'
ErrorCodes.FILE_DOES_NOT_EXIST = 'FILE_DOES_NOT_EXIST'

-- GENERAL Validation error
ErrorCodes.FIELD_REQUIRED		= 'FIELD_REQUIRED'  -- Field required
ErrorCodes.FIELD_NIL			= 'FIELD_NIL' 	    -- Field can be empty but not nil
ErrorCodes.FIELD_INVALID		= 'FIELD_INVALID'	-- Don't respect the pattern
ErrorCodes.FIELD_ALREADY_EXIST  = 'FIELD_ALREADY_EXIST'
ErrorCodes.INVALID_FIELD_LENGTH = 'INVALID_FIELD_LENGTH'
ErrorCodes.INVALID_FIELD_RANGE  = 'INVALID_FIELD_RANGE'
ErrorCodes.FIELD_LENGTH_BETWEEN_RANGE = 'FIELD_LENGTH_BETWEEN_RANGE'
ErrorCodes.FIELD_VALUE_BETWEEN_RANGE  = 'FIELD_VALUE_BETWEEN_RANGE'

ErrorCodes.LANGUAGE_ERROR = 'LANGUAGE_ERROR'        --Unable to change language
ErrorCodes.USERNAME_MUST_BE_PROVIDED = 'USERNAME_MUST_BE_PROVIDED'
ErrorCodes.USER_DOES_NOT_EXIST = 'USER_DOES_NOT_EXIST'  --User does not exist
ErrorCodes.PASSWORD_MISMATCH = 'PASSWORD_MISMATCH'  --Current password does not match supplied password
ErrorCodes.INCORRECT_PASSWORD = 'INCORRECT_PASSWORD'
ErrorCodes.CREATE_USER_FAILED = 'CREATE_USER_FAILED'    --Creation of user data failed
ErrorCodes.USER_UPDATE_FAILED = 'USER_UPDATE_FAILED'    --Update of user data failed
ErrorCodes.PASSWORD_CHANGE_FAILED = 'PASSWORD_CHANGE_FAILED'    --Failed to change the user's password
ErrorCodes.DELETE_USER_FAILED = 'DELETE_USER_FAILED'    --Unable to delete user
ErrorCodes.CANNOT_DELETE_ADMIN = 'CANNOT_DELETE_ADMIN' --Admin user cannot be deleted

ErrorCodes.CANNOT_USE_LAST_3_PASSWORDS    = 'CANNOT_USE_LAST_3_PASSWORDS'
ErrorCodes.CANNOT_USE_LAST_5_PASSWORDS    = 'CANNOT_USE_LAST_5_PASSWORDS'
ErrorCodes.LESS_THAN_MINIMUM_LENGTH       = 'LESS_THAN_MINIMUM_LENGTH'
ErrorCodes.PASSWORD_REQUIRES_ALPHA_CHAR   = 'PASSWORD_REQUIRES_ALPHA_CHAR'
ErrorCodes.PASSWORD_REQUIRES_NUM_CHAR     = 'PASSWORD_REQUIRES_NUM_CHAR'
ErrorCodes.PASSWORD_REQUIRES_SPECIAL_CHAR = 'PASSWORD_REQUIRES_SPECIAL_CHAR'
ErrorCodes.HISTORY_UPDATE_FAILED          = 'HISTORY_UPDATE_FAILED'

ErrorCodes.GET_TABLE_NAMES_ERROR = 'GET_TABLE_NAMES_ERROR'  --Unable to get list of data tables
ErrorCodes.CREATE_TABLE_FAILED = 'CREATE_TABLE_FAILED'  --Unable to create data table
ErrorCodes.UPDATE_DT_FAILED = 'UPDATE_DT_FAILED'        --An error occurred updating the data table
ErrorCodes.UPDATE_DT_VARS_FAILED = 'UPDATE_DT_VARS_FAILED'  --An error occurred while updating data table variables
ErrorCodes.DELETE_TABLE_FAILED = 'DELETE_TABLE_FAILED'  --An error occurred while deleting the data table
ErrorCodes.TABLE_DOES_NOT_EXIST = 'TABLE_DOES_NOT_EXIST'    --Table does not exist
ErrorCodes.VARIABLE_UPDATE_FAILED = 'VARIABLE_UPDATE_FAILED' -- There was an error updating the variables
ErrorCodes.MAX_NUM_DATATABLES_REACHED = 'MAX_NUM_DATATABLES_REACHED' -- The maximum number of datatables allowed has already been reached
ErrorCodes.NUM_DATATABLE_VARS_OUT_OF_RANGE = 'NUM_DATATABLE_VARS_OUT_OF_RANGE' -- Either too many or too few variables added to datatable

ErrorCodes.VARS_DO_NOT_EXIST = 'VARS_DO_NOT_EXIST'  --1 or more variables do not exist
ErrorCodes.DELETE_VARS_FAILED = 'DELETE_VARS_FAILED'    --Unable to delete variables from the data table

ErrorCodes.CHART_NAME_REQUIRED = 'CHART_NAME_REQUIRED'  --A chart name must be provided
ErrorCodes.GET_CHART_FAILED = 'GET_CHART_FAILED'        --Failed to get chart data
ErrorCodes.CREATE_CHART_FAILED = 'CREATE_CHART_FAILED'  --Failed to create chart with given values
ErrorCodes.UPDATE_CHART_FAILED = 'UPDATE_CHART_FAILED'  --Failed to update chart with given values
ErrorCodes.DELETE_CHART_FAILED = 'DELETE_CHART_FAILED'  --Failed to delete specified chart
ErrorCodes.CHART_DOES_NOT_EXIST = 'CHART_DOES_NOT_EXIST'    --Chart does not exist
ErrorCodes.YMIN_GT_YMAX = 'YMIN_GT_YMAX'            --Y Min cannot be greater than Y Max
ErrorCodes.NOT_ENOUGH_VARIABLES = 'NOT_ENOUGH_VARIABLES'    --Charts require at least 1 variable to be added
ErrorCodes.INVALID_CHART_NAME_LENGTH = 'INVALID_CHART_NAME_LENGTH'  --Invalid chart name length
ErrorCodes.LESS_THAN_500_MS = 'LESS_THAN_500_MS'        --Cannot set frequency less than 500ms

ErrorCodes.UPDATE_CHART_VARS_FAILED = 'UPDATE_CHART_VARS_FAILED'    --Unable to update variables for current chart
ErrorCodes.GET_CHART_NAMES_ERROR = 'GET_CHART_NAMES_ERROR' --Unable to retrieve chart names
ErrorCodes.MAX_NUM_CHARTS_REACHED = 'MAX_NUM_CHARTS_REACHED'
ErrorCodes.NUM_CHART_VARS_OUT_OF_RANGE = 'NUM_CHART_VARS_OUT_OF_RANGE' -- Either too many or too few variables added to chart


ErrorCodes.THEME_DOES_NOT_EXIST = 'THEME_DOES_NOT_EXIST'    --Theme does not exist
ErrorCodes.CREATE_THEME_FAILED = 'CREATE_THEME_FAILED'  --Theme creation failed
ErrorCodes.UPDATE_THEME_FAILED = 'UPDATE_THEME_FAILED'  --Update of theme failed
ErrorCodes.DELETE_THEME_FAILED = 'DELETE_THEME_FAILED'  --Theme failed to delete
ErrorCodes.GET_THEMES_FAILED = 'GET_THEMES_FAILED'  --Unable to get themes
ErrorCodes.GET_LOGOS_FAILED = 'GET_LOGOS_FAILED'  --Unable to get themes
ErrorCodes.DELETE_LOGO_FAILED = 'DELETE_LOGO_FAILED' --Unable to delete the logo
ErrorCodes.CANNOT_DELETE_DEFAULT = 'CANNOT_DELETE_DEFAULT'  --Cannot delete the default theme
ErrorCodes.MAX_NUM_THEMES_REACHED = 'MAX_NUM_THEMES_REACHED'

-- M580 - Replace those error codes by FIELD_INVALID
ErrorCodes.INVALID_TABLE_NAME = 'INVALID_TABLE_NAME'    --Table name must only contain alphanumerics, underscores, and dashes
ErrorCodes.INVALID_TABLE_NAME_LENGTH = 'INVALID_TABLE_NAME_LENGTH'  --Table name length is < 1 or > 20

ErrorCodes.READBOL_FAILED = 'READBOL_FAILED'
ErrorCodes.IOEXCHANGE_FAILED = 'IOEXCHANGE_FAILED'

-- Ip Validation
ErrorCodes.INVALID_IP   	= 'IP address is invalid'
ErrorCodes.INVALID_SUBNET	= 'Subnet mask is invalid'
ErrorCodes.INVALID_CLASS_SUBNET  = 'Subnet mask need to correpond with the IP class'
ErrorCodes.INVALID_GATEWAY  = 'Gateway must in the same range as the ip'
ErrorCodes.IP_NO_BROADCAST  = 'IP can not be a broadcast IP'
ErrorCodes.IP_NO_GATEWAY = 'Gateway cannot be the same as the IP'
ErrorCodes.IP_GATEWAY_SAME_NETWORK = 'Gateway needs to be on the same network'
ErrorCodes.GATEWAY_NO_BROADCAST = 'Gateway cannot be a broadcast IP'
ErrorCodes.GATEWAY_NO_NETWORK = 'Gateway cannot be a network IP'

ErrorCodes.DICTIONARY_UNAVAILABLE = 'DICTIONARY_UNAVAILABLE'    --UMAS data dictionary unavailable
ErrorCodes.USERNAME_REQUIRED = 'USERNAME_REQUIRED'  --Username is required
ErrorCodes.PASSWORD_REQUIRED = 'PASSWORD_REQUIRED'  --A password must be provided
ErrorCodes.USER_EXISTS = 'USER_EXISTS'          --User already exists. Please choose a different name.
ErrorCodes.INVALID_PASSWORD = 'INVALID_PASSWORD'        --Password provided was invalid
ErrorCodes.LANGUAGE_REQUIRED = 'LANGUAGE_REQUIRED'  --A language is required
ErrorCodes.INVALID_FREQUENCY_UM = 'INVALID_FREQUENCY_UM'    --Invalid frequency unit of measurement
ErrorCodes.THEME_NAME_REQUIRED = 'THEME_NAME_REQUIRED'        --Theme name cannot be null
ErrorCodes.THEME_EXISTS = 'THEME_EXISTS'            --Theme already exists
ErrorCodes.TABLE_EXISTS = 'TABLE_EXISTS'            --Table already exists
ErrorCodes.MAX_NUM_USERS_REACHED = 'MAX_NUM_USERS_REACHED'

ErrorCodes.SIGNATURE_ERROR = 'SIGNATURE_ERROR'

ErrorCodes.SERVICE_READY = 'SERVICE_READY'
ErrorCodes.SERVICE_ASYNC_PROGRESS = 'SERVICE_ASYNC_PROGRESS'
ErrorCodes.SERVICE_ASYNC_BUSY = 'SERVICE_ASYNC_BUSY'
ErrorCodes.SERVICE_UNKNOWN_STATUS = 'SERVICE_UNKNOWN_STATUS'
ErrorCodes.DEVICE_LOCAL_FAILED = 'DEVICE_LOCAL_FAILED'

--NEVER USED
--ErrorCodes.INVALID_INPUT_TYPE = 'INVALID_INPUT_TYPE'
--ErrorCodes.CHANGE_LOCK_ERROR = 'CHANGE_LOCK_ERROR'  --Unable to change lock on user account
--ErrorCodes.CHANGE_WRITE_ERROR = 'CHANGE_WRITE_ERROR'    --Unable to change user's write permission
--ErrorCodes.CHANGE_CREATE_ERROR = 'CHANGE_CREATE_ERROR'  --Unable to change user's create permission
--ErrorCodes.DELETE_DT_VARS_FAILED = 'DELETE_DT_VARS_FAILED'  --An error occurred while deleting variables from the data table
--ErrorCodes.DEL_CHART_VARS_ERROR = 'DEL_CHART_VARS_ERROR'    --Failed to delete variables from chart
--ErrorCodes.NO_THEME_DATA = 'NO_THEME_DATA'      --No theme data available
--ErrorCodes.NO_THEMES_EXIST = 'NO_THEMES_EXIST'      --No themes exist in the database
--ErrorCodes.UMAS_UNAVAILABLE = 'UMAS_UNAVAILABLE'                --UMAS protocol unavailable
--ErrorCodes.NUMBER_OF_PORTS_UNKNOWN = 'NUMBER_OF_PORTS_UNKNOWN'  --Could not get the number of ports
--ErrorCodes.INT16_CONVERSION_ERR = 'INT16_CONVERSION_ERR' --An error occurred converting byte array to int16 array
--ErrorCodes.INVALID_USER_DATA = 'INVALID_USER_DATA'  --User data is invalid
--ErrorCodes.PLOT_FREQ_NIL = 'PLOT_FREQ_NIL'      --Plot frequency cannot be a nil value
--ErrorCodes.PLOT_FREQ_UNIT_NIL = 'PLOT_FREQ_UNIT_NIL'    --Plot frequency unit cannot be a nil value
--ErrorCodes.AUTO_SCALE_NIL = 'AUTO_SCALE_NIL'        --Auto scale cannot be a nil value
--ErrorCodes.Y_MIN_NIL = 'Y_MIN_NIL'          --Y Min value cannot be nil
--ErrorCodes.Y_MAX_NIL = 'Y_MAX_NIL'          --Y Max value cannot be nil
--ErrorCodes.PLOT_POINTS_NIL = 'PLOT_POINTS_NIL'      --Plot points cannot be nil value
--ErrorCodes.CHART_EXISTS = 'CHART_EXISTS'            --Chart already exists
--ErrorCodes.CHART_NAME_NIL = 'CHART_NAME_NIL'        --Chart name cannot be a nil value
--ErrorCodes.TABLE_NAME_NIL = 'TABLE_NAME_NIL'        --Table name cannot be a nil value
--ErrorCodes.TABLE_DESC_NIL = 'TABLE_DESC_NIL'        --Table description cannot be a nil value
--ErrorCodes.INVALID_DESC_LENGTH = 'INVALID_DESC_LENGTH'  --Table name length is < 1 or > 20

return ErrorCodes