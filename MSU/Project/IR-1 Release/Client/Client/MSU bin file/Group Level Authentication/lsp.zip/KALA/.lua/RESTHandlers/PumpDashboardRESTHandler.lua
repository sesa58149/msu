local PumpDashboardRESTHandler = {}

function PumpDashboardRESTHandler.getHandler(_ENV,path)
	local method = request:method()
	if (method == 'GET') then
		if (path) and (string.lower(path) == '' ) then
			HTTPMethods.get(_ENV, PumpDashboardRESTHandler.getData)
		elseif (path) and (string.lower(path) == 'curvemonitoring' ) then
			HTTPMethods.get(_ENV, PumpDashboardRESTHandler.getCurveData, HTTPStatusCode.InternalServerError)
		elseif (path) and (string.lower(path) == 'workingpoint' ) then
			HTTPMethods.get(_ENV, PumpDashboardRESTHandler.getWorkingPoint, HTTPStatusCode.InternalServerError)
		end
	end
end

function PumpDashboardRESTHandler.getData()
	local io = "webram"
	if _G.isWindows then
		io = "disk"
	end
	local fileContent, errMsg = gf.readFile('.EnergyReport.json', io)
	if fileContent then
		return ba.json.encode(ba.json.decode(fileContent)), nil
	else
		return nil, ErrorObject.new(ErrorCodes.FILE_EMPTY)
	end
end

function PumpDashboardRESTHandler.getCurveData()
	local buffer, errorObj = nil, nil 
	if _G.isWindows then
		buffer, errorObj = PumpDashboardRESTHandler.getFileData(Constants.CURVEMONIT)
	else
		buffer, errorObj = PumpDashboardRESTHandler.getFileData(Constants.CURVEMONITDRIVE)
	end
	return buffer, errorObj
end

function PumpDashboardRESTHandler.getWorkingPoint()
	local buffer, errorObj = nil, nil 
	if _G.isWindows then
		 buffer, errorObj = PumpDashboardRESTHandler.getFileData(Constants.CURVEUPDATE)
	else
		buffer, errorObj = PumpDashboardRESTHandler.getFileData(Constants.CURVEUPDATEDRIVE)
	end
	return buffer, errorObj
end

function PumpDashboardRESTHandler.getFileData(file)
	local fileContent, errorMsg = nil, nil
	if _G.isWindows then
		fileContent, errorMsg = gf.readFile(file, "disk")
	else
		fileContent, errorMsg = gf.readCompleteFileDrive(file)
	end
	if fileContent ~= nil and errorMsg == nil then
        return ba.json.encode(ba.json.decode(fileContent)), nil
    else
        return nil, errorMsg 
    end
end


function PumpDashboardRESTHandler.getWorkingPointSimulateData()
	local resultMock = {}
	resultMock["Chart1"] = {math.random(350),math.random(500)}
	resultMock["Chart2"] = {math.random(350),math.random(500)}
	resultMock["Chart3"] = {math.random(800),math.random(300)}
	resultMock["Chart4"] = {math.random(800),math.random(300)}	
	return resultMock
end

return PumpDashboardRESTHandler