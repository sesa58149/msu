local FC8220x03 = {}

-- Send the modbus request and parse the result
function FC8220x03.fetch()
    local data = nil
    --if LuaModBus then
    --    data = LuaModBus.DiagnosticsData(22, 1, {3, 0, 0}) -- checked NOT WORKING state
    --end

    if not data then
        data = {
            22,0,0,0,       -- Diag header (MODBUS TCP/Port 502 Diag Validity?)
            1,0,	        -- Port 502 Status
            0,1,            -- Num Open Connections
            1,3,5,1,        -- Num MB Msgs Sent
            1,3,0,4,        -- Num MB Msgs Received
            1,22,           -- Num Open Client Connections
            22,1,           -- Num Open Server Connections
            0,5,            -- Max Num Connections
            1,6,            -- Max Num Client Connections
            0,17,           -- Max Num Server Connections
            9,7,8,6,        -- Num MB Error Msgs Sent
            8,8,            -- Num Open Priority Connections
            8,9,            -- Max Num Priority Connections
            6,7             -- Num Attempts to Open Authorized TCP Connection Table
		}
    end

    return FC8220x03.parse(data)
end

-- Parse the result
function FC8220x03.parse(data)
    local result = {}
    local c = 1
    local field = 0

    result["diagnostic_header"] = Utils.convertBytesToInt32(
        data[c],
        data[c+1],
        data[c+2],
        data[c+3]
    );
    c = c + 4

    field = Utils.convertBytesToInt16(data[c], data[c+1]);
    result["port_502_status"] = (field == 1) and "IDLE" or "OPERATIONAL";
    c = c + 2

    result["num_open_connections"] = Utils.convertBytesToInt16(
        data[c],
        data[c+1]
    );
    c = c + 2

    result["num_mb_msgs_sent"] = Utils.convertBytesToInt32(
        data[c],
        data[c+1],
        data[c+2],
        data[c+3]
    );
    c = c + 4

    result["num_mb_msgs_received"] = Utils.convertBytesToInt32(
        data[c],
        data[c+1],
        data[c+2],
        data[c+3]
    );
    c = c + 4

	result["num_open_client_connections"] = Utils.convertBytesToInt16(
        data[c],
        data[c+1]
    );
    c = c + 2

    result["num_open_server_connections"] = Utils.convertBytesToInt16(
        data[c],
        data[c+1]
    );
    c = c + 2

    result["max_num_connections"] = Utils.convertBytesToInt16(
        data[c],
        data[c+1]
    );
    c = c + 2

    result["max_num_client_connections"] = Utils.convertBytesToInt16(
        data[c],
        data[c+1]
    );
    c = c + 2

    result["max_num_server_connections"] = Utils.convertBytesToInt16(
        data[c],
        data[c+1]
    );
    c = c + 2

    result["num_mb_error_msgs_sent"] = Utils.convertBytesToInt32(
        data[c],
        data[c+1],
        data[c+2],
        data[c+3]
    );
    c = c + 4

    result["num_open_priority_connections"] = Utils.convertBytesToInt16(
        data[c],
        data[c+1]
    );
    c = c + 2

    result["max_num_priority_connections"] = Utils.convertBytesToInt16(
        data[c],
        data[c+1]
    );
    c = c + 2

    result["num_attempts_to_open_unauthorized_tcp_connection_table"] = Utils.convertBytesToInt16(
        data[c],
        data[c+1]
    );
    c = c + 2

    return result
end
return FC8220x03
