local ReadParamsNonCons = {}

-- Send the modbus request and parse the result
function ReadParamsNonCons.fetch(unitID, addresses)
    if type(unitID) ~= 'number' then
        return nil, ErrorObject.new(ErrorCodes.INVALID_DATATYPE,'"unitID" is not the correct type in ReadParamsNonCons.fetch. Number expected.')
    end
    if type(addresses) ~= 'table' then
        return nil, ErrorObject.new(ErrorCodes.INVALID_DATATYPE,'"addresses" is not the correct type in ReadParamsNonCons.fetch. Table expected.')
    end

    -- TODO: Need to check the types of all the data in the table.
    --       If strings make it to the LuaWrapper things break.

    local data, errMsg = {}, nil

    if LuaADL and not _G.forceSimulation then
        local mT = {}
        local x = 0
        for i, v in pairs(addresses) do
            if x < 9 then
                table.insert(mT, v)
                x = x + 1
            else
                table.insert(mT, v)
                mData, errMsg = LuaADL.ReadParamsNonCons(unitID, #mT, mT)
                collectgarbage("collect")
                if mData then
                    for j, w in pairs(mData) do
                        table.insert(data, w)
                    end
                else
                    -- COM error
                    return nil, ErrorObject.new(ErrorCodes.ADL_READ_FAILED, errMsg, nil, HTTPStatusCode.InternalServerError) --errMsg
                end
                mT = nil
                mT = {}
                x = 0
            end
        end
        if #mT > 0 then
            mData, errMsg = LuaADL.ReadParamsNonCons(unitID, #mT, mT)
            collectgarbage("collect")
            if mData then
                for j, w in pairs(mData) do
                    table.insert(data, w)
                end
            else
                -- COM error
                return nil, ErrorObject.new(ErrorCodes.ADL_READ_FAILED,  errMsg, nil, HTTPStatusCode.InternalServerError) --errMsg
            end
            mT = nil
            mT = {}
            x = 0
        end

    else
        data, errMsg = ReadParamsNonCons.generateSimulationData(addresses), ErrorObject.new(ErrorCodes.UNKNOWN_TYPE, 'Simulation Failure')
    end

    if #data == 0 then
        return nil, errMsg
    end

    return ReadParamsNonCons.parse(addresses, data)
end

-- Parse the result
function ReadParamsNonCons.parse(addresses, data)
    if type(addresses) ~= 'table' then
        return nil, ErrorObject.new(ErrorCodes.INVALID_DATATYPE, '"addresses" is not the correct type in ReadParamsNonCons.parse. Table expected.')
    end
    if type(data) ~= 'table' then
        return nil, ErrorObject.new(ErrorCodes.INVALID_DATATYPE,'"data" invalid type in ReadParamsNonCons.parse. Expected Table')
    end

    local result, errMsg = {}, nil

    for i=1, #data do

        result[i] = {
            address = addresses[i],
            status = data[i][1],
        }

        if result[i].status == 0 and #data[i] >= 3 then
            result[i].type = data[i][2]
            if (result[i].type == 4) then
                result[i].value = {}
                for j = 1, data[i][3][1] do
                    table.insert(result[i].value, data[i][3+j])
                end
                --TODO - Moke to test
                --if (#result[i].value == 0) then
                --    result[i].value = {0,146}
                --end
            else
                result[i].value = data[i][3]
            end
        end
    end

    return result, errMsg
end

function ReadParamsNonCons.generateSimulationData(addresses)
    --trace('Simulation used for ReadParamsNonCons')
    local result, errMsg = {}, nil

    if ParametersTable ~= nil then
        local listParam = ParametersTable.listparam
        local listDef = ParametersTable.listdef
        for i=1, #addresses do
            local name = GetParamsDescription.GetKeyByValue(ParametersTable['parameterlist'],  addresses[i])
            local options = listDef[listParam[name]]
            local typeM = 1
            if type(options) == "table" then
                typeM = 0
            end
            result[i] = {
                0,
                typeM,
                math.random(10)
            }
        end
    end
    return result, errMsg
end

return ReadParamsNonCons