local ErrorObject = {} -- the table representing the class, which will double as the metatable for the instances
ErrorObject.__index = ErrorObject -- failed table lookups on the instances should fallback to the class table, to get methods
ErrorObject.__type = 'ErrorObject'

-- syntax equivalent to "ErrorObject.new = function..."
function ErrorObject.new(errorCode, msgTechnical, detailsField, statusCode)
  local self = setmetatable({}, ErrorObject)
  self.errCode = errorCode
  self.msg = msgTechnical
  self.details = detailsField
  self.statusCode = statusCode
  return self
end

function ErrorObject:get_JSON() 
	local result = ba.json.encode({errCode = self.errCode, msg = self.msg, details = self.details})
	if (result == nil) then
		return ba.json.encode({errCode = ErrorCodes.UNKNOWN_ERROR}, 'Fail encode error object')
	else
		return result
	end
end

return ErrorObject