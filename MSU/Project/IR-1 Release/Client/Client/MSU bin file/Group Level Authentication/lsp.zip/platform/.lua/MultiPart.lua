local MultiPart = {}
MultiPart.errorMsg = nil
MultiPart.file = nil
MultiPart.pathLocal = nil

local cbFunctions = {}

function cbFunctions.formdata(name, value)
end

function cbFunctions.beginfile(name, filename, contenttype, transferencoding)
    -- Clear previous error messages if there was one
    MultiPart.errorMsg = nil
    --Create File with the filename
    if MultiPart.pathLocal then
        local io = ba.openio(_G.diskIOName)

        if io then
            MultiPart.file = io:open(MultiPart.pathLocal, 'w+b')
            if not MultiPart.file then
                MultiPart.errorMsg = ErrorCodes.FAILED_TO_CREATE_FILE_DURING_UPLOAD
                return false
            end
        else
            MultiPart.errorMsg = ErrorCodes.FAILED_TO_CREATE_FILE_DURING_UPLOAD
            return false
        end
    else
        MultiPart.errorMsg = ErrorCodes.FILENAME_AND_LOCAL_PATH_REQUIRED
        return false
    end
end

function cbFunctions.filedata(data)
    -- Write data into the file
    if (MultiPart.file ~=nil) then
        if (data) then
            (MultiPart.file):write(data)
        end
    else
        return false
    end
end

function cbFunctions.endmp()
    -- Close the file
    if (MultiPart.file ~=nil) then
        (MultiPart.file):close()
    else
        return false
    end
end

function cbFunctions.error(emsg)
    if emsg then
        MultiPart.errorMsg = emsg
    end
    return false
end

-- Only function visible to the outside world
function MultiPart.start(_ENV, paths, bufferSize, keepAlive)
    MultiPart.pathLocal = paths.pathLocal
    if type(bufferSize) == "number" then
        request:multipart(cbFunctions, bufferSize, keepAlive)
    else
        keepAlive = bufferSize
        request:multipart(cbFunctions, keepAlive)
    end
end

return MultiPart