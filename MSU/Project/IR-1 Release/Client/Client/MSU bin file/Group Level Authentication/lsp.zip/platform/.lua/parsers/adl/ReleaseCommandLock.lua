-- UMAS : Read Multiple BOL

local ReleaseCommandLock = {}

function ReleaseCommandLock.isValidInput(input)
    if type(input) ~= 'table' then
        return false
    end

    if type(input.sessionID) ~= 'number' then
       return false
    end

    -- Valid variables
    return true
end

function ReleaseCommandLock.getData(input)
    local result, data, errorMsg = nil, nil, nil

    -- Check input validity
    if ReleaseCommandLock.isValidInput(input) then
        if LuaADL and not _G.forceSimulation then
            -- Perform Request
            data, errorMsg = LuaADL.Unlock(Constants.DRIVE_UNIT_ID, input.sessionID)
        else
            data, errorMsg = ReleaseCommandLock.getSimulationData()
        end

        if ReleaseCommandLock.isValidResponse(data) then
            result = ReleaseCommandLock.generateServiceResponse(data, variables)
        end
    else
        errorMsg = ErrorCodes.INVALID_REQUEST
    end

    --Return variable data with values
    return result, errorMsg
end

function ReleaseCommandLock.isValidResponse(data)
    return type(data) == 'boolean'
end

function ReleaseCommandLock.generateServiceResponse(resp)
    return {success = resp}
end

function ReleaseCommandLock.getSimulationData(obj)
    return true
end

return ReleaseCommandLock