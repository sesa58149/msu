-- Close sessions
function closeSessions()
	-- Close all active sessions
	local sessions = ba.sessions()
	local err = nil
	
	for i=1, #sessions do 
		ba.session(sessions[i]):terminate()
	end
	return true
end


-- Close all sessions and disallow future sessions
function closeAndDisallowSessions()
	-- Update Security to on
	SecurityDA.setMode(1)

	--Disallow session
	_G.allowSession = false

	return closeSessions()
end

-- Allow Session
function allowSessions()
	_G.allowSession = true 
	return true
end