local io = ba.openio(_G.diskIOName)
local GlobalFunctions = io:dofile('platform/.lua/GlobalFunctions.lua')

function GlobalFunctions.readFileFromDrive(destinationFile, sourceFile)
	if (LuaFileApi) then
		local result = LuaFileApi.ReadFileFromDrive(destinationFile, sourceFile)
		return result
	else
		return false
	end
end

function GlobalFunctions.writeFileToDrive(sourceFile, destinationFile)
	if (LuaFileApi) then
		local result = LuaFileApi.WriteFileToDrive("\\fw\\lsp\\"..sourceFile, destinationFile)
		if (result) then
			GlobalFunctions.RemoveTempFile(sourceFile)
		end
		return result
	else
		return false
	end
end

function GlobalFunctions.openFileDrive(fileName, mode)
	if fileName then
		-- Next here we'll call the LuaFileApi to read directly the file from the drive
		if LuaFileApi then
			local handler = LuaFileApi.FileOpen(fileName, mode)
			if handler ~= nil then
				return handler, nil
			else
				return nil, ErrorObject.new(ErrorCodes.FAILED_TO_OPEN_FILE)
			end
		else
			return nil, ErrorObject.new(ErrorCodes.FAILED_TO_OPEN_FILE)
		end
	else
		return false, ErrorObject.new(ErrorCodes.FILENAME_AND_LOCAL_PATH_REQUIRED)
	end
end

function GlobalFunctions.writeFileDrive(handlerFile, data)
	if (handlerFile ~=nil) and (LuaFileApi) then
		if (data) then
			local buffer = {}
			if (type(data) == 'string') then
				buffer = GlobalFunctions.stringToDataBuffer(data)
			else
				buffer = data
			end
			if (#buffer > 0) then
				local result = LuaFileApi.FileWrite(handlerFile, buffer, #buffer)
				
				if (result == 0) then
					local errorCode, errorObj = GlobalFunctions.isErrorFile(handlerFile)
					if (errorCode == 1) then
						trace('After write ' .. result)
						return false, errorObj
					end
				end
				
				if (result ~= #buffer) then
					return false
				end
			end
		end
	else
		return false
	end
end

function GlobalFunctions.readFileDrive(handlerFile)
	if (handlerFile ~= nil) and (LuaFileApi) then
		local fileContent, buffer, errorMsg = '', {}, nil

		while (buffer ~= nil) do
            buffer, errorMsg = gf.readFileDriveByBlock(handlerFile, true)

            if (errorMsg ~= nil) then
                return nil, errorMsg
            end
            if (buffer ~= nil) then
            	fileContent = fileContent .. buffer
            end
        end
		return fileContent, nil
	else
		return nil, ErrorObject.new(ErrorCodes.FILE_NOT_AVAILABLE)
	end
end

function GlobalFunctions.readFileDriveByBlock(handlerFile, isConvert)
	if (handlerFile ~= nil) and (LuaFileApi) then
		local errorCode, errorObj = 4001, {}
		local block = {}
		--While drive is busy continue to ask a block
		while errorCode == 4001 do
			block = LuaFileApi.FileRead(handlerFile)
			if (block ~= nil and #block == 0) then
				errorCode, errorObj = GlobalFunctions.isErrorFile(handlerFile)
				if (errorCode == 1) then
					return nil, errorObj
				end
			end
			if isConvert then
				return GlobalFunctions.dataBufferToString(block)
			else
				return GlobalFunctions.dataBufferToOctet(block)
				--return block
			end
		end
	else
		return nil
	end
end

function GlobalFunctions.readCompleteFileDrive(path)
	local handler,errMsg = gf.openFileDrive(path, 0)

    if (handler ~= nil) then
        fileContent, errMsg = gf.readFileDrive(handler)
        local isClose, errorMsg = gf.closeFileDrive(handler)
        if (not isClose and errorMsg ~= nil) then
            return nil, errorMsg           
        end
        if fileContent ~= nil then
            return fileContent, nil
        end
    else
	    if (errMsg ~= nil) then
	        return nil, errMsg  
	    else
	        return nil, ErrorObject.new(ErrorCodes.FILE_NOT_AVAILABLE)
	    end
	end
end

function GlobalFunctions.dataBufferToString(dataBuffer)
	if dataBuffer ~= nil then
		local str = ''
		for i=1, #dataBuffer do
			if (dataBuffer[i] > 0) then
				str = str .. string.char(dataBuffer[i])
			end
		end
		return str
	else
		return nil
	end
end

function GlobalFunctions.dataBufferToOctet(dataBuffer)
	if dataBuffer ~= nil then
		local str = ''
		for i=1, #dataBuffer do
			str = str .. string.char(dataBuffer[i]%256)
		end
		return str
	else
		return nil
	end
end

function GlobalFunctions.stringToDataBuffer(string)
	local dataBuffer = {}
	for i=1, #string do
    	dataBuffer[#dataBuffer+1] = string.byte(string, i, i)
	end
	return dataBuffer
end

function GlobalFunctions.closeFileDrive(handlerFile)
	if (handlerFile ~=nil) and (LuaFileApi) then
		local result = 4001
		while result == 4001 do
			result = LuaFileApi.FileClose(handlerFile)
			if result > 0 and result ~= 4001 then
				trace('Error close ' .. result)
				return false, ErrorObject.new(GlobalFunctions.MapErrorCode(result))
			else
				return true
			end
		end
	else
		return false
	end
end

function GlobalFunctions.RemoveTempFile(path, typeIO)
	if path then
		local io
		if _G.isWindows then
			io = ba.openio("home")
		elseif typeIO then
			io = ba.openio(typeIO)
		else
			io = ba.openio(_G.diskIOName)
		end
		if io then
			io:remove(path)
			return true, nil
		else
			return false, ErrorObject.new(ErrorCodes.FAILED_TO_CREATE_FILE_DURING_UPLOAD)
		end
	else
		return false, ErrorObject.new(ErrorCodes.FILENAME_AND_LOCAL_PATH_REQUIRED)
	end
end

function GlobalFunctions.fileExistsOnDrive(filePath)
	if LuaFileApi then
		local handler = LuaFileApi.FileOpen(filePath, 0)
		if handler ~= nil then
			LuaFileApi.FileClose(handler)
			return true
		else
			return false
		end
	else
		return false
	end
end

function GlobalFunctions.filterOptionsList(listOption, possibleValues)
	local optionsFilter = {}
	local step = 0
	if listOption and possibleValues then
		for i=1, #possibleValues do
			for j=0, 7 do
				local index = bit32.extract(possibleValues[i], j, 1)
				if (index > 0) then
					local value = listOption[tostring(step + j)]
					if (value) then
						optionsFilter[tostring(step + j)] = value
					end
				end
			end
			step = step + 8
		end
	end
	return optionsFilter
end

function GlobalFunctions.isErrorFile(handlerFile)
	if (handlerFile ~= nil) and (LuaFileApi) then
		local returnCode = LuaFileApi.FileError(handlerFile)
		if returnCode == 0 then
			return returnCode, nil
		elseif returnCode == 4000 or returnCode == 4001 then
			return 4001, nil --Loop - mean drive busy working to create the file
		else
			trace('Error read/write :' .. returnCode)
			return 1, ErrorObject.new(GlobalFunctions.MapErrorCode(returnCode))
		end
	end
end

function GlobalFunctions.returnError(_ENV, errorMsg)
    if (errorMsg ~= nil) then
        trace('Return error')
        local split = gf.split(request:uri(), '/')
        local url = request:domain()
        if (request:issecure()) then
            url = 'https://' .. url
        else
            url = 'http://' .. url
        end
        if (split[#split] == 'driveconfigreport') then
            url = url .. '/#setup/drive/configuration/' .. errorMsg.errCode
        else
            url = url .. '/#setup/drive/importexport/' .. errorMsg.errCode
        end
        response:setstatus(302)
        response:setheader('Location', url)
        response:write('')
        return false
    end
end

function GlobalFunctions.MapErrorCode(errorCode)
	return errorCode
end

return GlobalFunctions