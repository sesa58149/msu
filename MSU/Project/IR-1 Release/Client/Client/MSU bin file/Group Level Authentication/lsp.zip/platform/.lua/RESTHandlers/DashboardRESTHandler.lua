local DashboardRESTHandler = {}

function DashboardRESTHandler.getDashboard(user_name)
	local result, errorMsg = Dashboard.get(user_name)
	if not errorMsg then
		return ba.json.encode(result), nil
	else
		return nil, errorMsg
	end
end

function DashboardRESTHandler.getHandler(_ENV, path)
	local result, errorMsg, dashboardData = nil
	local method = request:method()
	local userRef = request:user()
	local user_name = nil
	if _G.securityMode == '0' then
		userRef = 'admin'
	end
	if userRef then
		user_name = userRef:match('[%w_]+')
		response:setheader('content-type', 'application/json; charset=UTF-8')
		if(path == '') then
			if(method == 'GET') then
				HTTPMethods.get(_ENV, DashboardRESTHandler.getDashboard, nil, user_name)
			elseif(method == 'POST') then
				HTTPMethods.post(_ENV, DashboardRESTHandler.saveDashboard, {}, user_name)
			else
				gf.sendError(_ENV)
			end
		end
	else
		gf.sendError(_ENV, HTTPStatusCode.InternalServerError, ErrorCodes.INVALID_REQUEST)
	end
end

function DashboardRESTHandler.saveDashboard(data, user_name)
	local result, errorMsg = Dashboard.save(data, user_name)
	if result then
		return ba.json.encode({success = result})
	else
		return nil, errorMsg
	end
end

return DashboardRESTHandler