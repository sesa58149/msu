local fd = ba.openio(_G.diskIOName)
local FileSystem = fd:dofile('platform/.lua/data-access/FileSystem.lua')

-- Override platform FileSystem.getIO()
function FileSystem.getIO(fromDrive)
    if _G.isWindows then
        return "home"
    else
        if fromDrive then
            --return ba.openio("disk")
            return nil -- FileLuaAPI
        else
            --trace('ram')
            return "ram" -- Otherwise read on the b:
        end
    end
end

function FileSystem.downloadFile(_ENV, drivePath, localPath)
    if drivePath then
        FileSystem.getFileFromDrive(_ENV, drivePath, false)
    elseif localPath then
        FileSystem.getFileFromLocal(_ENV, localPath)
    end
end

function FileSystem.getFileFromDrive(_ENV, path, isString)
    local splitPath = gf.split(path, "/")
    local fileName = splitPath[#splitPath]
    local fileData, buffer, errorMsg = {}, {}, nil
    local hfile = gf.openFileDrive(path, 0)
    if hfile then
        while (fileData ~= nil) do
            fileData, errorMsg = gf.readFileDriveByBlock(hfile, isString)
            if (errorMsg ~= nil) then
                return gf.returnError(_ENV, errorMsg)
            end
            table.insert(buffer, fileData)
        end
        local isClose, errMsg = gf.closeFileDrive(hfile)

        if (not isClose and errMsg ~= nil) then
            return gf.returnError(_ENV, errMsg)
        end

        if (#buffer > 0) then
            local size = 0
            for i=1, #buffer do
               size = size + #buffer[i]
            end

            if (not isString) then
                response:setheader('Content-Type', 'application/octet-stream');
            end
            response:setheader('Content-Disposition', 'attachment;filename="'..fileName..'"')
            response:setcontentlength(size) -- Set in bytes
            for i=1, #buffer do
                response:send(buffer[i])
            end
            return true
        else
            response:abort()
        end
    else
       return gf.returnError(_ENV, ErrorObject.new(10000))
    end
end

function FileSystem.getReportAvailable()
    if ParametersTable ~= nil then
        local table, temp = {}, {}
        if (ParametersTable["upload"] ~= nil) then
            for k, v in pairs(ParametersTable["upload"]) do
                table[#table+1] = {id = k, isDownloadable = true }
            end
        end
        if (ParametersTable["download"] ~= nil) then
            local findElem = false
            for k, v in pairs(ParametersTable["download"]) do
                for i = 1, #table do
                    if (table[i]["id"] == k) then
                        table[i]['isUploadable'] = true
                        findElem = true
                        break
                    end
                end
                if not findElem then
                    table[#table+1] = {id = k, isUploadable = true }
                else
                    findElem = false
                end
            end
        end
        return ba.json.encode(table)
    end
end

function FileSystem.getFileExists(name)
    local fileExists = false
    if (Constants.DOWNLOADPATH[name] ~= nil ) then
        fileExists = gf.fileExistsOnDrive(Constants.DOWNLOADPATH[name])
    elseif ParametersTable ~= nil and ParametersTable["upload"] ~= nil and ParametersTable["upload"][name] ~= nil then
        fileExists = gf.fileExistsOnDrive(ParametersTable["upload"][name])
    end
    return fileExists
end

return FileSystem