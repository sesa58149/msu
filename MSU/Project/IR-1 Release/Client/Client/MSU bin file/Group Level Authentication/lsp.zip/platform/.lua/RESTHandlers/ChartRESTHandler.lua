local ChartRESTHandler = {}

function ChartRESTHandler.getCharts(chartName)
    local result, errorMsg = Chart.getCharts(chartName)
    if not errorMsg then
        return ba.json.encode(result), nil
    else
        return nil, errorMsg
    end
end

function ChartRESTHandler.getHandler(_ENV,path)
    local result, chartData, errorMsg = nil
    local method = request:method()
    -- Ensure that the response is has a content type of JSON
    response:setheader('content-type', 'application/json; charset=UTF-8')
    -- http://domain/rest/chart
    if(path == '') then
        -- GET http://localhost/rest/chart :: Get list of charts
        if (method == 'GET') then
            HTTPMethods.get(_ENV, ChartRESTHandler.getCharts)
        -- PUT http://localhost/rest/chart :: Add new chart
        elseif (method == 'POST') then
            HTTPMethods.post(_ENV, ChartRESTHandler.crudChart, {}, false)
        -- Unimplemented method
        else
            gf.sendError(_ENV)
        end
    -- http://domain/rest/chart/[chart]
    else
        -- Chart name must be all alphanumeric characters
        if not path:match("^[%w_]+$") and not path:match("^[%w_]+/.*$") then
            gf.sendError(_ENV, HTTPStatusCode.BadRequest, ErrorCodes.INVALID_REQUEST)
        elseif path:match("^[%w_]+/variables") then
            local chartName = path:match('^[%w_]+')
            -- Get a set of variables (no values) in a particular chart
            if (method == 'GET') then
                HTTPMethods.get(_ENV, ChartRESTHandler.getChartVariables, HTTPStatusCode.NotFound, chartName)
            -- Add variables to a chart
            elseif (method == 'POST') then
                HTTPMethods.post(_ENV, ChartRESTHandler.addVariablesToChart, {}, chartName)
            -- Delete variables from a chart
            elseif (method == 'DELETE') then
                HTTPMethods.delete(_ENV, ChartRESTHandler.deleteVariables, true, {}, chartName)
            -- Unknown HTTP Request?
            else
                gf.sendError(_ENV)
            end
        else
            local chartName = path:match('^[%w_]+')
            --GET http://localhost/rest/chart/chartid :: Get all chart data
            if (method == 'GET') then
                HTTPMethods.get(_ENV, ChartRESTHandler.getCharts, HTTPStatusCode.NotFound, chartName)
            --PUT http://localhost/rest/chart/chartid :: Update chart
            elseif (method == 'PUT') then
                HTTPMethods.put(_ENV, ChartRESTHandler.crudChart, {HTTPStatusCode.NotFound}, true)
            -- DELETE http://localhost/rest/chart/chartName :: Delete a specific chart
            elseif (method == 'DELETE') then
                HTTPMethods.delete(_ENV, ChartRESTHandler.deleteChart, false, {HTTPStatusCode.InternalServerError}, chartName)
            else
                gf.sendError(_ENV)
            end
        end
    end
end
function ChartRESTHandler.crudChart(chartData, isUpdate)
    local result = false
    local errorMsg = nil
    if chartData then
        if not isUpdate then

            --test number of tables
            local numCharts = Chart.getChartCount()

            if numCharts < Constants.MAX_NUM_CHARTS then
               result, errorMsg = Chart.create(chartData)
            else
                -- Send message saying max number tables reached...
                trace( ErrorCodes.MAX_NUM_CHARTS_REACHED )
                return nil, ErrorObject.new(ErrorCodes.MAX_NUM_CHARTS_REACHED, '', nil, HTTPStatusCode.BadRequest)
           end
        else
            result, errorMsg = Chart.update(chartData)
        end

        if result then
            return '{"success":true}', nil
        else
            return nil, errorMsg
        end
    else
        return nil, ErrorCodes.INVALID_REQUEST
    end
end
function ChartRESTHandler.deleteChart(chartName)
    local success, errorMsg = Chart.delete(chartName)
    if success then
        return '{"success":true}', nil
    else
        return nil, errorMsg
    end
end
function ChartRESTHandler.getChartVariables(chartName)
    local chartData = Chart.getChartVariables(chartName)
    if chartData then
        --If not empty, respond with chart data in JSON format
        return ba.json.encode(chartData), nil
    else
        -- Respond not found if chart doesn't exist
        return nil, ErrorCodes.CHART_DOES_NOT_EXIST
    end
end

function ChartRESTHandler.addVariablesToChart(variables, chartName)
    local success, errorMsg = Chart.addVariablesToChart(variables, chartName)
    if success then
        return '{"success":true}', nil
    else
        return nil, errorMsg
    end
end

function ChartRESTHandler.deleteVariables(variables, chartName)
    local success, errorMsg = Chart.deleteVariables(variables, chartName)
    if success then
        return '{"success":true}', nil
    else
        return nil, errorMsg
    end
end

return ChartRESTHandler