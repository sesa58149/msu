-- UMAS : Read Multiple BOL

local LockUnlockDrive = {}

function LockUnlockDrive.isValidInput(input)
    if type(input) ~= 'table' then
        return false
    end
    if type(input.sessionID) ~= 'number' or type(input.password) ~= 'string' then
        return false
    end
    -- Valid variables
    return true
end

function LockUnlockDrive.getData(input)
    local result, data, errorMsg = nil, nil, nil

    -- Check input validity
    if LockUnlockDrive.isValidInput(input) then

        if LuaADL and not _G.forceSimulation then
            -- Perform Request
            data, errorMsg = LuaADL.ExecuteService(Constants.DRIVE_UNIT_ID, input.sessionID, 0x16, 0x02, 6, mPass)
        else
            data, errorMsg = LockUnlockDrive.getSimulationData()
        end

        if LockUnlockDrive.isValidResponse(data) then
            result = LockUnlockDrive.generateServiceResponse(data, variables)
        end
    else
        errorMsg = ErrorCodes.INVALID_REQUEST
    end

    --Return variable data with values
    return result, errorMsg
end

function LockUnlockDrive.isValidResponse(data)
    if type(data) ~= 'table' or #data ~= 4 then
        return false
    end

    if type(data[4]) ~= 'table' or #data[4] ~= 7 then
        return false
    end

    for i=1,7 do
        if type(data[4][i]) ~= 'number' then
            return false
        end
    end

    return true
end

function LockUnlockDrive.generateServiceResponse(resp)
    local respData = resp[4]

    local result = {}

    status = Utils.convertBytesToInt32(respData[1], respData[2], respData[3], respData[4])

    result.isMemorizationInProgress = bit32.extract(status, 0, 1) == 1
    result.isHighPowerSupplyOn = bit32.extract(status, 1, 1) == 1
    result.isDriveRunning = bit32.extract(status, 2, 1) == 1
    result.isInDCInjection = bit32.extract(status, 3, 1) == 1
    result.isGoingForward = bit32.extract(status, 4, 1) == 1
    result.faultState = bit32.extract(status, 5, 2)
    result.isControlledByCommTool = bit32.extract(status, 7, 1) == 1
    result.isControlledByMyCommTool = bit32.extract(status, 8, 1) == 1
    result.isInForcedLocalMode = bit32.extract(status, 9, 1) == 1
    result.isDriveReadyToRun = bit32.extract(status, 10, 1) == 0
    result.isBlockedByDisableVoltage = bit32.extract(status, 11, 1) == 1
    result.isBlockedByDCStopOrder = bit32.extract(status, 12, 1) == 1
    result.isBlockedByFastStopOrder = bit32.extract(status, 13, 1) == 1
    result.isBlockedBySTOOrder = bit32.extract(status, 14, 1) == 1
    result.isDriveLocked = bit32.extract(status, 15, 1) == 1

    return result
end

function LockUnlockDrive.getSimulationData(obj)
    return {1,0,7,{0,0,1,130,0,0,0}}
end

return LockUnlockDrive