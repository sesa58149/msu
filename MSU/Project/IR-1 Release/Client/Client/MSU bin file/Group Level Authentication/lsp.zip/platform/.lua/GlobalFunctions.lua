local GlobalFunctions = {}
-- Method taken from http://lua-users.org/wiki/CopyTable
function GlobalFunctions.deepCopy(object)
    local lookup_table = {}
    local function _copy(object)
        if type(object) ~= 'table' then
            return object
        elseif lookup_table[object] then
            return lookup_table[object]
        end
        local new_table = {}
        lookup_table[object] = new_table
        for index, value in pairs(object) do
            new_table[_copy(index)] = _copy(value)
        end
        return setmetatable(new_table, getmetatable(object))
    end
    return _copy(object)
end
function GlobalFunctions.contains(arr, el)
  for e = 1, #arr do
    if arr[e] == el then
      return true
    end
  end
  return false
end
function GlobalFunctions.isPositiveInteger(n)
  return type(n) == "number" and n > 0 and math.floor(n) == n
end
function GlobalFunctions.isArrayOfStrings(input)
  local result = true
  if GlobalFunctions.isArray(input) then
    for i,v in ipairs(input) do
      if type(v) ~= "string" then
        result = false
        break
      end
    end
  else
    result = false
  end
  return result
end

function GlobalFunctions.merge(t1, t2)
    for k, v in pairs(t2) do
            table.insert(t1, v)
    end
    return t1
end

function GlobalFunctions.mergeObject(obj1, obj2)
  for k, v in pairs(obj2) do
    obj1[k] = v
  end
  return obj1
end

function GlobalFunctions.htmlspecialchars(str)
  if (str) then
    str = string.gsub(str, "&", "&amp;")
    str = string.gsub(str, "<", "&lt;")
    str = string.gsub(str, ">", "&gt;")
  end
  return str
end

function GlobalFunctions.isArray(array)
  local max, n = 0, 0
  for k, _ in pairs(array) do
    if not GlobalFunctions.isPositiveInteger(k) then return false end
    max = math.max(max, k)
    n = n + 1
  end
  return n == max
end
-- Checks if data falls between its threshold values
function GlobalFunctions.checkLength(data, minLen, maxLen)
  if data:len() < minLen or data:len() > maxLen then
    return false
  end
  return true
end

-- Checks if data falls between its threshold values
function GlobalFunctions.checkValue(data, minVal, maxVal)
  if tonumber(data) < tonumber(minVal) or tonumber(data) > tonumber(maxVal) then
    return false
  end
  return true
end

function GlobalFunctions.getDecodedJSONPayload(_ENV)
    local result = ''
    local errorMsg = nil
    local requestMethod = request:method()

    if requestMethod == 'PUT' or requestMethod == 'POST' or requestMethod == 'DELETE' then
    for data in request:rawrdr() do
         result = result .. data
         -- Ensure that the size of userJSONData doesn't go outside of the max length
         if result:len() > Constants.MAX_RAW_DATA_LENGTH then
              -- Prevent Overflow attack
              result = nil
              errorMsg = ErrorCodes.PAYLOAD_LENGTH
              return result, errorMsg
         end
    end

    if result:len() > 0 then
      -- Attempt to decode the JSON.
      result = ba.json.decode(result)
      if not result then
        errorMsg = ErrorCodes.DECODE_ERROR
        result = nil
      end
    else
      -- No Data Provided
      result = nil
      errorMsg = nil
    end
    else
        errorMsg = ErrorCodes.INVALID_REQUEST
    end

    return result, errorMsg
end
function GlobalFunctions.isSilverlight(_ENV)
  local referer = request:header("Referer")
  if type(referer) == 'string' then
    local result = referer:find(".xap")
    if type(result) == 'number' then
      return true
    end
  end
  return false
end
function GlobalFunctions.getStatusCode(isSilverlight, status, errorObj)
    -- Silverlight must always get success
    if isSilverlight then
        return 200
    end

    -- Default
    local httpStatus = HTTPStatusCode.InternalServerError

    if type(status) == 'number' then
        httpStatus = status
    end

    if ((type(errors) == 'table') and (getmetatable(errors).__type == "ErrorObject")) then
        -- errorObj status code takes precedance
        if type(errorObj.statusCode) == 'number'  then
            httpStatus = errorObj.statusCode
        -- If a status was not provided try to guess inteligently based on if details are provided
        elseif type(status) ~= number and errorObj.details and errorObj.details ~= nil then
            httpStatus = HTTPStatusCode.BadRequest --Validation Error
        end
    end

    return httpStatus
end

function GlobalFunctions.sendError(_ENV, httpStatus, errors)
    --if not errors then errors = ErrorCodes.INVALID_REQUEST end
    local errorObj = nil
    -- Error object
    if ((type(errors) == 'table') and (getmetatable(errors).__type == "ErrorObject")) then
      errorObj = errors
    -- retrocompatibility
    elseif (type(errors) == 'string') then
      errorObj = ErrorObject.new(errors, null, null, httpStatus)
    else
      errorObj = ErrorObject.new(ErrorCodes.UNKNOWN_ERROR, 'Untracked Error')
    end

    -- Generate the JSON
    local errorJSON = errorObj:get_JSON()
    local isSilverlight = GlobalFunctions.isSilverlight(_ENV)

    -- Build the response
    response:setdefaultheaders()
    response:setstatus(GlobalFunctions.getStatusCode(isSilverlight, httpStatus, errors))
    -- Send error using content length
    response:setcontentlength(errorJSON:len())
    response:send(errorJSON)
    response:flush()
    -- Lua execution will end here.
    response:abort()
end

function GlobalFunctions.trim(s)
  return (string.gsub(s, "^%s*(.-)%s*$", "%1"))
end

function GlobalFunctions.RESTResponse(_ENV, result)
    if result then
      response:write(result)
    else
      GlobalFunctions.RESTError(_ENV, HTTPStatusCode.BadRequest, errorMsg)
    end
end
function GlobalFunctions.RESTError(_ENV, httpStatus, errorCode)
    response:setstatus(httpStatus)
    response:write(errorCode)
end

function GlobalFunctions.query(query, bind)
    local sql    = luasql.sqlite();
    local conn   = sql:connect(Constants.DB_PATH, 'READONLY');
    local cursor = conn:prepare(query);
    local result = {};
    local ret    = {};

    if not cursor then
        return nil, ErrorCodes.INVALID_SQL_SYNTAX;
    end

    if bind then
      cursor:bind(bind);
    end

    local exec = cursor:execute();
    if exec then
      cursor:fetch(result, 'a');

      while (result and next(result)) do
        -- Add to the table
        table.insert(ret, GlobalFunctions.deepCopy(result));
        -- Get the next one
        result = cursor:fetch(result, 'a');
      end
    end

    -- Close database connection as soon as it is no longer needed
    if not cursor:close() then
        trace('FAILED TO CLOSE CURSOR')
    end

    if not conn:close() then
        trace('FAILED TO CLOSE SQLITE CONNECTION')
    end

    if not sql:close() then
        trace('FAILED TO CLOSE SQLITE ENVIRONMENT')
    end

    -- return the result
    return ret, nil;
end

function GlobalFunctions.sha1(inputString)
  -- Ensure that a string is provided. Even if it is an empty string a hash can be generated
  if type(inputString) ~= "string" then
    return nil, "Invalid input"
  end

  local alphabet = {'0','1','2','3','4','5','6','7','8','9','a','b','c','d','e','f'}

  -- Grab a reference to the hash function
  local hashFunction = ba.crypto.sha1()
  -- Append the input into the hashFunction
  hashFunction(inputString)
  -- Execute the hash function
  local hresult = hashFunction()
  local result = GlobalFunctions.newStack()

  -- Convert 20 bytes into 40 ascii characters
  for i = 1, 20 do
    local hashByte = string.byte(hresult,i)
    if hashByte > 0 then
      -- Lua starts arrays at 1 instead of 0
      GlobalFunctions.addString(result, alphabet[math.floor(hashByte / 16) + 1])

      -- Lua starts arrays at 1 instead of 0
      GlobalFunctions.addString(result, alphabet[math.fmod(hashByte, 16) + 1])
    else
      -- A hash byte of zero translates into two zero ascii characters
      GlobalFunctions.addString(result, '00')
    end
  end

  -- return the 40 character hash
  return table.concat(result)
end

function GlobalFunctions.newStack ()
      return {""}   -- starts with an empty string
end

function GlobalFunctions.EncodeModel(model)
  if (not model.attributes) then
    local ret = {};
    for i=1,# model do
      table.insert(ret, model[i].attributes);
    end
    return ba.json.encode(ret);
  end

  return ba.json.encode(model.attributes);
end

function GlobalFunctions.addString (stack, s)
  table.insert(stack, s)    -- push 's' into the the stack
  for i=#stack-1, 1, -1 do
    if string.len(stack[i]) > string.len(stack[i+1]) then
      break
    end
    stack[i] = stack[i] .. table.remove(stack)
  end
end

function GlobalFunctions.directoryExists(dirPath, iopath)
  local io = nil
  if _G.isWindows then
    io = ba.openio("home")
  else
    if iopath then
      io = iopath
    else
      io = ba.openio(_G.diskIOName)
    end
  end
  local result = io:stat(dirPath)
  if result then
    if result.type == "directory" then
      return true
    else
      return false
    end
  else
    return false
  end
end

function GlobalFunctions.fileExists(filePath, ioType)
  local io = nil
  if _G.isWindows then
    io = ba.openio("home")
  elseif ioType ~= nil then
    io = ba.openio("ram")
  else
    io = ba.openio(_G.diskIOName)
  end

  local f=io:open(filePath,"r")


  if f~=nil then
    f:close()
    return true
  else
    return false
  end
end

-- Lua 5.1+ base64 v3.0 (c) 2009 by Alex Kloss <alexthkloss@web.de>
-- licensed under the terms of the LGPL2

-- character table string
local b='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'

-- encoding
function GlobalFunctions.encBase64(data)
    return ((data:gsub('.', function(x)
        local r,b='',x:byte()
        for i=8,1,-1 do r=r..(b%2^i-b%2^(i-1)>0 and '1' or '0') end
        return r;
    end)..'0000'):gsub('%d%d%d?%d?%d?%d?', function(x)
        if (#x < 6) then return '' end
        local c=0
        for i=1,6 do c=c+(x:sub(i,i)=='1' and 2^(6-i) or 0) end
        return b:sub(c+1,c+1)
    end)..({ '', '==', '=' })[#data%3+1])
end

-- decoding
function GlobalFunctions.decBase64(data)
    data = string.gsub(data, '[^'..b..'=]', '')
    return (data:gsub('.', function(x)
        if (x == '=') then return '' end
        local r,f='',(b:find(x)-1)
        for i=6,1,-1 do r=r..(f%2^i-f%2^(i-1)>0 and '1' or '0') end
        return r;
    end):gsub('%d%d%d?%d?%d?%d?%d?%d?', function(x)
        if (#x ~= 8) then return '' end
        local c=0
        for i=1,8 do c=c+(x:sub(i,i)=='1' and 2^(8-i) or 0) end
        return string.char(c)
    end))
end

-- Thanks http://lua-users.org/wiki/SplitJoin
function GlobalFunctions.split(str, pat)
   local t = {}  -- NOTE: use {n = 0} in Lua-5.0
   local fpat = "(.-)" .. pat
   local last_end = 1
   local s, e, cap = str:find(fpat, 1)
   while s do
      if s ~= 1 or cap ~= "" then
   table.insert(t,cap)
      end
      last_end = e+1
      s, e, cap = str:find(fpat, last_end)
   end
   if last_end <= #str then
      cap = str:sub(last_end)
      table.insert(t, cap)
   end
   return t
end

-- GlobalFunctions.removeElements(Table data, int bytes)
-- Removes a number of bytes from the beginning of data - generally used for header data
function GlobalFunctions.removeElements(data, bytes)
  for el = 1, bytes do
    table.remove(data, 1)
  end
  return data
end

function GlobalFunctions.readFile(localPath, target)
  local data, errMsg = nil, nil

  if localPath then
    -- Get the file name from the path coming from Constants.lua
    local splitPath = gf.split(localPath, "\\")
    local fileName = splitPath[#splitPath]
    --if (gf.fileExists(localPath)) then
      local io
      -- Get IO interface specific to the environment
      if _G.isWindows then
        io = ba.openio("home")
      else
        if target then
          io = ba.openio(target)--ram
        else
          io = ba.openio(_G.diskIOName)--ram
        end
      end

      if io then
        local fileStats = io:stat(localPath)
        if fileStats and fileStats.type == 'regular' then
          local fileSizeBytes = fileStats.size

          -- Open the file READONLY
          file = io:open(localPath, 'r')
          if file then
            -- Read the entire file
            data = file:read("*all")
            -- Close the file
            file:close()
          else
            return nil,  ErrorObject.new(ErrorCodes.FAILED_TO_OPEN_FILE, 'File : ' .. fileName)
          end
        else
          return nil, ErrorObject.new(ErrorCodes.FAILED_TO_OPEN_FILE, 'File : ' .. fileName)
        end
      else
        return nil, ErrorObject.new(ErrorCodes.IO_UNAVAILABLE)
      end
    --else
    --  return nil,ErrorCodes.FILE_NOT_AVAILABLE
    --end
  else
    return nil, ErrorObject.new(ErrorCodes.FILE_PATH_UNKNOWN)
  end
  return data, errMsg
end

function GlobalFunctions.addRESTDirectory(restDirectory, url, folder, classHandlerName)
    local io = ba.openio(_G.diskIOName)
    local directory = ba.create.dir(url)
    local ClassHandler = io:dofile(folder .. '/.lua/RESTHandlers/' .. classHandlerName .. '.lua')

    directory:setfunc(ClassHandler.getHandler)
    restDirectory:insert(directory, true)
end

function GlobalFunctions.validateIP(ip)

    local R = {ERROR = 0, IPV4 = 1, IPV6 = 2, STRING = 3}
    if type(ip) ~= "string" then
      return false
    end
--- from stackoverflow - http://stackoverflow.com/questions/10975935/lua-function-check-if-ipv4-or-ipv6-or-string
      -- check for format 1.11.111.111 for ipv4
  --The first octet of the IP address MUST be greater than 0
  --The first octet of the IP address MUST be less than 224
  --Class D and E are not allowed address: 224.0.0.0 to 254.255.255.254
  --IP adress can not be 0 coverd by the following checking
  --check to see if the IP address is belong to loopback
  -- the first byte of the IP address can not be 127
  local chunks = {ip:match("(%d+)%.(%d+)%.(%d+)%.(%d+)")}
  if #chunks == 4 then
    for _,v in pairs(chunks) do
      if (_ == 1 and (tonumber(v) < 1 or tonumber(v)  > 223 or tonumber(v) == 127)) then
        return false
      elseif (_ > 1 and tonumber(v) > 255) then
         return false
      end
    end
    return true
  end

  -- check for ipv6 format, should be 8 'chunks' of numbers/letters
  local chunks = {ip:match(("([a-fA-F0-9]*):"):rep(8):gsub(":$",""))}
  if #chunks == 8 then
    for _,v in pairs(chunks) do
      if #v > 0 and tonumber(v, 16) > 65535 then
        return false
      end
    end
    return true
  end
end


function GlobalFunctions.networkAddress(ip, subnet)
  -- receive string in decimal form - first convert to binary then compare bit by bit
  local binarySubnet, binaryIP = "", ""
  for id in subnet:gmatch("(%d+)") do
        binarySubnet = binarySubnet .. GlobalFunctions.tobits(tonumber(id))
  end
  for id in ip:gmatch("(%d+)") do
        binaryIP = binaryIP .. GlobalFunctions.tobits(tonumber(id))
  end
  local count,networkAddress = 0, ""
  for count = 1,#binaryIP do
    local IPbit = binaryIP:sub(count,count)
    local subnetbit = binarySubnet:sub(count, count)
    if(IPbit == subnetbit) then
      networkAddress = networkAddress .. IPbit
    else
      networkAddress = networkAddress .. "0"
    end
  end
  return GlobalFunctions.binaryIPtoString(networkAddress)
end


function GlobalFunctions.broadcastAddress(ip, subnet)
  -- receive string in decimal form - first convert to binary then compare bit by bit
  local binarySubnet, binaryIP = "", ""
   --get inverse of subnet
  for id in subnet:gmatch("(%d+)") do
        binarySubnet = binarySubnet .. GlobalFunctions.tobits(255-tonumber(id))
  end
  for id in ip:gmatch("(%d+)") do
        binaryIP = binaryIP .. GlobalFunctions.tobits(tonumber(id))
  end
  local count
  local broadcastAddress = ""
  for count = 1,#binaryIP do
    local IPbit = binaryIP:sub(count,count)
    local subnetbit = binarySubnet:sub(count, count)
    if(IPbit == "1" or subnetbit == "1") then
      broadcastAddress = broadcastAddress .. "1"
    else
      broadcastAddress = broadcastAddress .. "0"
    end

  end
  return GlobalFunctions.binaryIPtoString(broadcastAddress)
end

function GlobalFunctions.isSameNetwork(ip, subnet, gateway)
  local ipNetworkAddress = GlobalFunctions.networkAddress(ip,subnet)
  local gatewayNetworkAddress = GlobalFunctions.networkAddress(gateway,subnet)
  return (ipNetworkAddress == gatewayNetworkAddress)
end

function GlobalFunctions.isSubnetContinuous(subnet)
  local binarySubnet = ""
  local bitTested = 1
  for id in subnet:gmatch("(%d+)") do
      binarySubnet = binarySubnet .. GlobalFunctions.tobits(tonumber(id))
  end

  while(#binarySubnet < 32) do
    binarySubnet = binarySubnet .. "0";
  end
  local last = true;
  while (bitTested <= 32 and last) do
      if (binarySubnet:sub(bitTested,bitTested) == '1' and last) then
          bitTested = bitTested + 1
      else
          last = false
      end
  end

  if ( bitTested <= 8 ) then
      return false;
  else
      local lastdigit = binarySubnet:sub(bitTested - 1,bitTested - 1)
      while ( bitTested <= 30 )do
          if (binarySubnet:sub(bitTested,bitTested) ~= lastdigit and binarySubnet:sub(bitTested + 1,bitTested + 1) ~= binarySubnet:sub(bitTested,bitTested)) then
              return false
          end
          bitTested = bitTested + 1
      end
  end
  return true
end



function GlobalFunctions.isIPMatchingGateway(ip, gateway)
  if (GlobalFunctions.validateIP(ip) and GlobalFunctions.validateIP(gateway)) then
    if (GlobalFunctions.isIPV4(ip) and GlobalFunctions.isIPV4(gateway)) then
        if(ip == gateway) then
          return false
        end
        local ipMatch, gatewayMatch = {ip:match("(%d+)%.(%d+)%.(%d+)%.(%d+)")}, {gateway:match("(%d+)%.(%d+)%.(%d+)%.(%d+)")}
        return (ipMatch[1] == gatewayMatch[1])
    else
      return true
    end
  end
end

function GlobalFunctions.isIPV4(ip)
  local chunks = {ip:match("(%d+)%.(%d+)%.(%d+)%.(%d+)")}
  return (#chunks == 4)
end

function GlobalFunctions.tobits(num)
    local t={}
    while num>0 do
        rest=num%2
        t[#t+1]=rest
        num=(num-rest)/2
    end
    --make byte
    while #t<8 do
      t[#t+1] = 0
    end

    t = GlobalFunctions.reverse(t)
    return table.concat(t)
end

function GlobalFunctions.reverse(t)
  local nt = {} -- new table
  local size = #t + 1
  for k,v in ipairs(t) do
    nt[size - k] = v
  end
  return nt
end

function GlobalFunctions.getLastValidAddress(ip, subnet)
  local endVal = GlobalFunctions.broadcastAddress(ip,subnet)
    endVal = GlobalFunctions.tobits(endVal)


end

function GlobalFunctions.binaryIPtoString(ip)
  local ipString = ''
  local buffer = ''
  for i = 1,ip:len() do
    if((i-1)%8 == 0 and not (buffer == '')) then
      if( not (ipString == '')) then
        ipString = ipString .. '.'
      end
      ipString = ipString .. tostring(tonumber(buffer,2) )
      buffer = ''
    end
      buffer = buffer .. ip:sub(i, i)
  end
  --add last byte to ipString
  if(not (buffer== '')) then
    ipString = ipString .. '.' .. tostring(tonumber(buffer,2) )
  end
  return ipString
end


function GlobalFunctions.validateIPGatewaySubnet(data)
  local i = 0
  local v = 0
  if data then
    local ipNum, subnetNum, gatewayNum = GlobalFunctions.validateIP(data.ip), GlobalFunctions.validateIP(data.subnet), GlobalFunctions.validateIP(data.gateway)
    if (ipNum == subnetNum and ipNum == gatewayNum) then
      i = ipNum + subnetNum + gatewayNum;
    end
    if(i ==3) then
      if string.find(data.subnet, '255') == 1 then
        if string.find(data.subnet, '255',4) == 5 then
          if string.find(data.subnet, '255',8) == 9 then
            if(tonumber(string.match(data.ip, '%d+')) >= 192) and (tonumber(string.match(data.ip, '%d+'))< 224) then--class C
              return true
            else
              return false
            end
          else
            if(tonumber(string.match(data.ip, '%d+')) >= 128) and (tonumber(string.match(data.ip, '%d+'))< 192) then--class B
              return true
            else
              return false
            end
          end
        else
          if(tonumber(string.match(data.ip, '%d+'))<128) then-- class A
              return true
          else
              return false
          end
        end
      else
        return false;
      end
    elseif (i == 6) then
      --implement better check
      return true
    else
      return false
    end
  else
    return false;
  end
end

function GlobalFunctions.isURL(url)
 -- local pattern = new RegExp('^(https?:\\/\\/)?'+ -- protocol
  --    '((([a-z\\d]([a-z\\d-]*[a-z\\d])*)\\.)+[a-z]{2,}|'+ -- domain name
  --    '((\\d{1,3}\\.){3}\\d{1,3}))'+ -- OR ip (v4) address
  --    '(\\:\\d+)?(\\/[-a-z\\d%_.~+]*)*'+ -- port and path
  --    '(\\?[;&a-z\\d%_.~+=-]*)?'+ --query string
  --    '(\\#[-a-z\\d_]*)?$','i'); --fragment locator
  local ind, iend, first, path = string.find(str , "^(https?://)(.*)" )
  print(string.find(path, "(%d+)%.(%d+)%.(%d+)%.(%d+)"))
  print(string.find(path , "(%a%a%a).(%w%w%w*).(%a%a+)(:%d+)(/[%w_.~+]*)"))
end
return GlobalFunctions
