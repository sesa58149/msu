local MessageBoard= {}

function MessageBoard.save(message, user_name)
    local result = false
	local errorMsg = nil
    -- Grab a reference to SQLite environment
	local env = luasql.sqlite()

	-- Connect to the database with write permissions
	local connection = env:connect(Constants.DB_PATH)

	-- Establish how long to wait for the write lock on the database and acquire the lock.
	local isLockAcquired = connection:setautocommit('IMMEDIATE', 1000)

	-- Process update if the lock has been acquired
	if isLockAcquired then

		local time = os.time()

		-- Prepare the query
		local cursor =
			connection:prepare(
				[[INSERT INTO message_board(
					id,
					from_user,
					time_stamp,
					message
				)
				VALUES(
					NULL,
					( ? ),
					( ? ),
					( ? )
				)]])
		-- Bind username to the prepared statement
		if( cursor ~= nil ) then
			cursor:bind{
				{'TEXT', user_name},
				{'TEXT', time},
				{'TEXT', message.message}
			}
			-- Execute query
			local exec = cursor:execute()
			if not exec then
				errorMsg = 'MESSAGEBOARD INSERT FAILED'
			else
				-- Commit the transaction
				if connection:commit() then
					result = true
				else
					errorMsg = ErrorCodes.COMMIT_FAIL
				end
			end
			-- Close cursor connection to database
			if not cursor:close() then
				trace('FAILED TO CLOSE CURSOR')
			end
		else
			errorMsg = 'CURSOR FAILED'
		end
	else
		errorMsg = ErrorCodes.LOCK_FAIL
	end

	-- Close connection to database
	if not connection:close() then
		trace('FAILED TO CLOSE SQLITE CONNECTION')
	end
	-- Close connection to SQLite
	if not env:close() then
		trace('FAILED TO CLOSE SQLITE ENVIRONMENT')
	end

    return result, errorMsg
end

function MessageBoard.get()
	local message = {}
	local result = {}
	local env = luasql.sqlite()
	local connection = env:connect(Constants.DB_PATH, 'READONLY')
	local cursor, errorMsg = nil

	if env ~= nil then
		-- Build Prepared Statement
		if connection ~= nil then
			cursor = connection:prepare([[
				SELECT *
				FROM message_board
			]])
			if cursor ~= nil then
				local exec = cursor:execute()
				if exec then

					cursor:fetch(message, 'a')

					while (message and next(message)) do
						local obj = {
							from_user = gf.htmlspecialchars(message.from_user),
							time_stamp = gf.htmlspecialchars(MessageBoard.getTime(message.time_stamp)),
							message = gf.htmlspecialchars(message.message)
						}
						table.insert(result,obj)
						-- Grab results in a table
						message = cursor:fetch(message, 'a')
					end

				else
					result = false
					errorMsg = ErrorCodes.GET_DASHBOARD_FAILED
				end
				-- Clean up
				if not cursor:close() then
					trace('FAILED TO CLOSE CURSOR')
				end
			end
			if not connection:close() then
				trace('FAILED TO CLOSE SQLITE CONNECTION')
			end
		end
		if not env:close() then
			trace('FAILED TO CLOSE SQLITE ENVIRONMENT')
		end
	end

    return result, errorMsg
end

function MessageBoard.getTime(epoch)
	local result, errorMsg = nil;
	if tonumber( epoch ) ~= nil then
		temp = os.date("*t", epoch)
		mSec = temp.sec
		if mSec == 0 then
			mSec = '00'
		elseif mSec > 0 and mSec < 10 then
			mSec = '0' .. tostring(mSec)
		end
		result = temp.month .. '/' .. temp.day .. '/' .. temp.year .. ' ' .. temp.hour .. ':' .. temp.min .. ':' .. mSec
	else
		errorMsg = 'NUMBER_EXPECTED'
	end
	return result, errorMsg
end

return MessageBoard