local fd = ba.openio(_G.diskIOName)
local FileRESTHandler = fd:dofile('platform/.lua/RESTHandlers/FileRESTHandler.lua')

-- Override the platform FileRESTHandler.getHandler(_ENV, path)
function FileRESTHandler.getHandler(_ENV, path)
    local method = request:method()
    -- Ensure that the response is has a content type of JSON
	if (method == 'GET') then
		if (path) then
			local newPath = gf.split(path, '/');
			-- local localPath, drivePath = nil, nil
			if newPath[1] == 'fixed' then
				FileRESTHandler.getFixedDL(_ENV, Constants.DOWNLOADPATH[newPath[2]], Constants.UPLOADTYPEDRIVE[newPath[2]])
			elseif newPath[1] == 'download' then
				FileRESTHandler.getThemeDL(_ENV, newPath[2])
			elseif newPath[1]:lower() == 'reports' then
				FileRESTHandler.getReportsDL(_ENV, newPath[2])
			elseif (newPath[1]:lower() == 'reportavailable') then
				response:setcontenttype('application/json; charset=UTF-8')
				HTTPMethods.get(_ENV, FileSystem.getReportAvailable)
			elseif (newPath[1]:lower() == 'fileexist') then
				local result = FileSystem.getFileExists(newPath[2])
				response:setcontenttype('application/json; charset=UTF-8')
				response:write(ba.json.encode({success = result}))
			end
		end
	elseif (method == 'POST') then
		local userAgent = request:header('User-Agent');
		if FileSystem.UserAgentIsIE(userAgent) then
			response:setcontenttype('text/html; charset=UTF-8')
		else
			response:setcontenttype('application/json; charset=UTF-8')
		end
		if (path) then
			local newPath = gf.split(path, '/');
			if newPath[1] == 'fixed' then
				-- Config : Ethernet/Drive to the drive
				-- Import/Export : PC to drive / Drive - PC
				-- pathLocal = Constants.UPLOADTYPE[newPath[2]]
				-- pathDrive = Constants.UPLOADTYPEDRIVE[newPath[2]]
				trace(Constants.UPLOADTYPE[newPath[2]])
				trace(Constants.UPLOADTYPEDRIVE[newPath[2]])
				FileRESTHandler.fixedUL(_ENV, Constants.UPLOADTYPE[newPath[2]], Constants.UPLOADTYPEDRIVE[newPath[2]])
			elseif newPath[1]:lower() == 'reports' then
				FileRESTHandler.reportsUL(_ENV, newPath[2])
			elseif newPath[1] == 'logos' then
				MultiPart.useWebRoot = true
				FileSystem.handleUpload(_ENV, Constants.TEMP_UPLOAD_PATH, newPath[2], {logo = true})
			elseif newPath[1] == 'themes' then
				MultiPart.useWebRoot = true
				FileSystem.handleUpload(_ENV, Constants.TEMP_UPLOAD_PATH, newPath[2], {theme = true})
			end
		end
	end
end

-- [[ DOWNLOAD ]] --
function FileRESTHandler.getFixedDL(_ENV, localPath, drivePath)
	if drivePath or localPath then
		FileSystem.downloadFile(_ENV, drivePath, false)
	else
		response:setcontenttype('application/json; charset=UTF-8')
		response:write(ba.json.encode({success = false, errorMsg = ErrorCodes.FILE_PATH_UNKNOWN}))
	end
end

-- PLATFORM CODE ---------------------------------------
-- function FileRESTHandler.getThemeDL(_ENV, themeName)
-- 	local data, errorMsg = Theme.get(themeName)
-- 	if not errorMsg then
-- 		local d = ba.json.encode(data[1])
-- 		response:setheader('Content-Disposition', 'attachment; filename="' .. themeName .. '.wtc"')
-- 		response:setcontentlength(string.len(d))
-- 		response:send(d)
-- 	else
-- 		gf.sendError(_ENV, HTTPStatusCode.BadRequest, ErrorCodes.INVALID_REQUEST)
-- 	end
-- end
-- -----------------------------------------------------

function FileRESTHandler.getReportsDL(_ENV, reportName)
	if (reportName and ParametersTable ~= nil) then
		local pathDrive = ParametersTable["upload"][reportName]
		if pathDrive then
			local splitPath = gf.split(pathDrive, "/")
			local tempFileName = splitPath[#splitPath]
			FileSystem.getFileFromDrive(_ENV, pathDrive, false)
		else
			response:setcontenttype('application/json; charset=UTF-8')
			response:write(ba.json.encode({success = false, errorMsg = ErrorCodes.FILE_PATH_UNKNOWN}))
		end
	else
		response:setcontenttype('application/json; charset=UTF-8')
		response:write(ba.json.encode({success = false, errorMsg = ErrorCodes.FILE_PATH_UNKNOWN}))
	end
end

-- [[ UPLOAD ]] --
function FileRESTHandler.fixedUL(_ENV, pathLocal, pathDrive)
	if pathLocal or pathDrive then
		--local folderStructExists, errorMsg = FileSystem.createFolderStructure(pathLocal)
		--if folderStructExists then
			MultiPart.start(_ENV, {pathLocal = pathLocal, pathDrive = pathDrive}, false)
			-- request:multipart(callBackMultiPart, false)
			if not MultiPart.errorMsg then
				response:write(ba.json.encode({success = true}))
			else
				trace('Send Error')
				response:setstatus(HTTPStatusCode.InternalServerError)
				response:write(ba.json.encode({success = false, errorMsg = MultiPart.errorMsg}))
			end
		--else
		--	response:write(ba.json.encode({success = false, errorMsg = errorMsg}))
		--end
	else
		response:setstatus(HTTPStatusCode.InternalServerError)
		response:write(ba.json.encode({success = false, errorMsg = ErrorCodes.INVALID_UPLOAD_PATH}))
	end
end

function FileRESTHandler.reportsUL(_ENV, reportName)
	if (reportName and ParametersTable ~= nil) then
		local pathDrive = ParametersTable["download"][reportName]
		if pathDrive then
			--local splitPath = gf.split(pathDrive, "/")
			--local tempFileName = splitPath[#splitPath]
			--pathLocal = tempFileName
			MultiPart.start(_ENV, {pathDrive = pathDrive}, 8000, true)
			-- request:multipart(callBackMultiPart, 8000, true)
			if not MultiPart.errorMsg then
				response:write(ba.json.encode({success = true}))
			else
				response:setstatus(HTTPStatusCode.InternalServerError)
				response:write(ba.json.encode({success = false, errorMsg = MultiPart.errorMsg}))
			end
		end
	else
		response:setstatus(HTTPStatusCode.InternalServerError)
		response:write(ba.json.encode({success = false, errorMsg = ErrorCodes.INVALID_UPLOAD_PATH}))
	end
end

return FileRESTHandler