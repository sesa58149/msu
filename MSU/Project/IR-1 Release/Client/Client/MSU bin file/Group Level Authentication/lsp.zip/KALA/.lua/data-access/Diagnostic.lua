local Diagnostic = {}

function Diagnostic.getModbusTcpIpData()
	local result = {}
	result = { ["FC0x01"] = FC8220x01.fetch(), ["FC0x02"] = FC8220x02.fetch(), ["FC0x03"] = FC8220x03.fetch() }
	return result, nil
end

function Diagnostic.getEthernetPortData()
	local result = FC8220x02.fetch();
	return result, nil
end

function Diagnostic.getModbusTcpPort502data()
	local result = FC8220x03.fetch();
	return result, nil
end

function Diagnostic.getModbusTcpPort502ConnectionTabledata()
	local result = FC8220x04.fetch();
	return result, nil
end

function Diagnostic.getEthernetIpData()
	local errorMsg = nil
	local result = {}

	-- Make some fake data for now...

	result = { ["product_name"] = "Altivar NERA", ["product_type"] = 0, ["product_code"] = 0, ["major_revision"] = "Major Revision", ["minor_revision"] = "Minor Revision", ["vendor_id"] = "Vendor ID", ["serial_number"] = "Serial Number", ["assembly_count"] = "Assembly Count", ["fallback_mode"] = "Hold" }

	return result, nil
end

function Diagnostic.getDeviceIdData()
	local errorMsg = nil
	local result = {}

	-- Make some fake data for now...

	result = { ["reference"] = "ATV71H037M3", ["hardware_type"] = "1 / IP 20 drive", ["supply_voltage"] = "200 / 240 V Three Phase", ["nominal_power"] = "0.37 kW / 0.5 Hp", ["software_release"] = "1.4.7.0", ["card"] = "Device", ["reference"] = "ATV71H037M3", ["serial_number"] = "00000001", ["version"] = "V1.6IEXX" }

	return result, nil
end

function Diagnostic.getMaintenanceData()
	local errorMsg = nill
	local result = {}

	-- Grab a reference to SQLite environment
	local env = luasql.sqlite()
	-- Connect to the database with write permissions
	local connection = env:connect(Constants.DB_PATH)
	local isLockAcquired = connection:setautocommit('IMMEDIATE', 1000)

	-- Delete the page if the lock has been acquired
	if isLockAcquired then
		local queryResult = {}
		local cursor = connection:prepare([[SELECT attr_value FROM config_attributes WHERE (attr_key = 'maintenance')]])
		local exec = cursor:execute()
		if  exec then
			cursor:fetch(result, 'a')
		else
			-- Commit the transaction
			-- if not connection:commit() then
				errorMsg = ErrorCodes.COMMIT_FAIL
			--end
		end
		-- Close cursor connection to database
		if not cursor:close() then
			trace('FAILED TO CLOSE CURSOR')
		end
	else
		errorMsg = ErrorCodes.LOCK_FAIL
	end

	-- Close connection to database
	if not connection:close() then
		trace('FAILED TO CLOSE SQLITE CONNECTION')
	end
	-- Close connection to SQLite
	if not env:close() then
		trace('FAILED TO CLOSE SQLITE ENVIRONMENT')
	end
	-- doesn't work because queryResult is null
	result = { ["message"] = result.attr_value}
	return result, nil;
end

function Diagnostic.updateMaintenanceData(newMessage)
	local result = false
	local errorMsg = false
	--if newMessage == nil or string.len(newMessage) == 0 then
	local env = luasql.sqlite()

	--Connect to the database with write permissions
	local connection = env:connect(Constants.DB_PATH)
	-- Establish how long to wait for the write lock on the database and acquire the lock.
	local isLockAcquired = connection:setautocommit('IMMEDIATE',1000)

	if isLockAcquired then

		local cursor =
				connection:prepare(
					[[UPDATE config_attributes
					SET attr_value = ( ? )
					WHERE attr_key = 'maintenance']])
			cursor:bind{{'TEXT', newMessage}}
			-- Execute query
			local exec = cursor:execute()
			if not exec then
				errorMsg = ErrorCodes.PASSWORD_CHANGE_FAILED

				--if not connection:rollback() then
				--	trace('ROLLBACK FAILED')
				--end
			else
				-- Commit the transaction
				if connection:commit() then
					result = true
				else
					errorMsg = ErrorCodes.COMMIT_FAIL
				end
			end
			-- Close cursor connection to database
			if not cursor:close() then
				trace('FAILED TO CLOSE CURSOR')
			end
	else
		errorMsg = ErrorCodes.LOCK_FAIL
	end

	-- Close connection to database
	if not connection:close() then
		trace('FAILED TO CLOSE SQLITE CONNECTION')
	end
	-- Close connection to SQLite
	if not env:close() then
		trace('FAILED TO CLOSE SQLITE ENVIRONMENT')
	end

    return result, errorMsg


end

function Diagnostic.resetMessagingData()
	
	MbC.FC8(22,2, {4,0, 0 }, "Reset Messaging Failed", Diagnostic.genFunction)
	return ba.json.encode({success = true})
end

function Diagnostic.resetEthernetData()
	
	MbC.FC8(22,2, {2,1, 0 }, " Ethernet1 FAILED", Diagnostic.genFunction)	
	MbC.FC8(22,2, {3,0, 0 }, "Ethernet2 FAILED", Diagnostic.genFunction)
	return ba.json.encode({success = true})
end

function Diagnostic.genFunction()

	return 'nocomm'

end
return Diagnostic
