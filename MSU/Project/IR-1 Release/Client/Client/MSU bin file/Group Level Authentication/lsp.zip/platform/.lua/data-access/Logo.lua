local Logo = {}

Logo.list = {}

function Logo.get()
	local env = luasql.sqlite()
	local connection, cursor, errorMsg = nil
	local result = {}
	local logo = {}

	if env then
		connection = env:connect(Constants.DB_PATH, 'READONLY')
		if connection then
			cursor = connection:prepare([[
				SELECT logos.*,
				       Group_Concat( themes.theme_name ) AS logo_deps
				  FROM logos
				       LEFT JOIN themes
				               ON logos.logo_id = themes.theme_logo
				 GROUP BY logos.logo_id
			]])
			if cursor then
				local exec = cursor:execute()
				if exec then
					cursor:fetch(logo, 'a')
					while(logo and next(logo)) do
						local tObj  = {
							id      = logo.logo_id,
							name    = logo.logo_name,
							size    = logo.logo_size,
							deps    = logo.logo_deps,
							sysImg  = logo.system_img,
							imgCode = logo.img_code
						}
						table.insert(result, tObj)
						logo = cursor:fetch(logo, 'a')
					end
				else
					result = false
					errorMsg = ErrorCodes.GET_LOGOS_FAILED
				end
				if not cursor:close() then
					trace('FAILED TO CLOSE CURSOR')
				end
			end
			if not connection:close() then
				trace('FAILED TO CLOSE SQLITE CONNECTION')
			end
		end
		if not env:close() then
			trace('FAILED TO CLOSE SQLITE ENVIRONMENT')
		end
	end

	if result then Logo.list = result end
    return result, errorMsg
end

function Logo.add(io, fileStats, binData)
	local result, errorMsg = false, nil
	if fileStats and binData then
		local env = luasql.sqlite()
		local connection = env:connect(Constants.DB_PATH)
		local isLockAcquired = connection:setautocommit("IMMEDIATE", 1000)
		if isLockAcquired then
			local cursor = connection:prepare([[
				INSERT INTO logos VALUES (
					NULL,
					( ? ),
					( ? ),
					0,
					( ? )
				)
			]])
			local fileNameTbl = {}
			if _G.isWindows then
				fileNameTbl = gf.split(fileStats["name"], "\\")
			else
				fileNameTbl = gf.split(fileStats["name"], "/")
			end
			cursor:bind{
				{'TEXT', fileNameTbl[#fileNameTbl]},
				{'INTEGER', fileStats["size"]},
				{'TEXT', Logo.buildImgCode(fileNameTbl[#fileNameTbl], ba.b64encode(binData))}
			}
			local exec = cursor:execute()
			if exec then
				if connection:commit() then
					result, errorMsg = io:remove(fileStats["name"])
				else
					errorMsg = ErrorCodes.COMMIT_FAIL
				end
			else
				errorMsg = ErrorCodes.LOCK_FAIL
			end

			if not cursor:close() then
				trace('UNABLE TO CLOSE CURSOR')
			end
		else
			errorMsg = ErrorCodes.LOCK_FAIL
		end
		-- Close connection to database
		if not connection:close() then
			trace('FAILED TO CLOSE SQLITE CONNECTION')
		end
		-- Close connection to SQLite
		if not env:close() then
			trace('FAILED TO CLOSE SQLITE ENVIRONMENT')
		end
	else
		errorMsg = ErrorCodes.NO_FILE_PROVIDED
	end
	return result, errorMsg
end

function Logo.buildImgCode(name, data)
	local nameTbl = gf.split(name, '%.')
	return "data:image/" .. nameTbl[2] .. ";base64," .. data
end

function Logo.delete(logo_id)
    local result = false
	local errorMsg = nil
	if logo_id then

		local env = luasql.sqlite()
		local connection = env:connect(Constants.DB_PATH)

		local isLockAcquired = connection:setautocommit('IMMEDIATE', 1000)
		if isLockAcquired then

			local cursor = connection:prepare([[
				UPDATE themes
				SET theme_logo = 1
				WHERE theme_logo == ( ? )
			]])

			cursor:bind{
				{'TEXT', logo_id}
			}
			-- Execute query
			local exec = cursor:execute()

			if exec then
				local cursor = connection:prepare([[
					DELETE FROM logos
					WHERE logos.logo_id = ( ? )
				]])
				cursor:bind{{'INTEGER', logo_id}}

				local exec = cursor:execute()

				if not exec then
					errorMsg = ErrorCodes.DELETE_LOGO_FAILED
				else
					if connection:commit() then
						result = true
					else
						errorMsg = ErrorCodes.COMMIT_FAIL
					end
				end
			else
				errorMsg = ErrorCodes.LOCK_FAIL
			end

			-- Close cursor connection to database
			if not cursor:close() then
				trace('FAILED TO CLOSE CURSOR')
			end

		end
		-- Close connection to database
		if not connection:close() then
			trace('FAILED TO CLOSE SQLITE CONNECTION')
		end
		-- Close connection to SQLite
		if not env:close() then
			trace('FAILED TO CLOSE SQLITE ENVIRONMENT')
		end
	else
		errorMsg = ErrorCodes.DELETE_LOGO_FAILED
	end

    return result, errorMsg
end

function Logo._getLogoFromId(logo_id)
	for i = 1, #Logo.list do
		if logo_id == Logo.list[i].id then
			return Logo.list[i].name
		end
	end
end

return Logo