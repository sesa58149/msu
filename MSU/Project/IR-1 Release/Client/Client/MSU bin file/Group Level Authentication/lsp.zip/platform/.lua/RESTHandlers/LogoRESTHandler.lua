local LogoRESTHandler = {}

function LogoRESTHandler.getHandler(_ENV, path)
	local method = request:method()
	response:setheader('content-type', 'application/json; charset=UTF-8')

	if path == '' then
    	-- GET
    	if method == 'GET' then
	 		HTTPMethods.get(_ENV, LogoRESTHandler.getLogoList)
		end
	else
		local logoId = path:match('^[%w_]+')

    	if method == 'DELETE' then
			HTTPMethods.delete(_ENV, LogoRESTHandler.deleteLogo, false,
				{HTTPStatusCode.InternalServerError}, logoId)
		else
			gf.sendError(_ENV)
		end
	end
end

function LogoRESTHandler.getLogoList()
	local result, errorMsg = Logo.get()
	if result then
		return ba.json.encode(result), nil
	else
		return nil, errorMsg
	end
end
function LogoRESTHandler.deleteLogo(logoId)
	local result, errorMsg = Logo.delete(logoId)
	if result then
		return ba.json.encode({result}), nil
	else
		return nil, errorMsg
	end
end

return LogoRESTHandler