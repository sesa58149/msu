local HTTPMethods = {}

-- HTTPMethods.post(_ENV, callback, [, {statusCodes}[, {extraParams}]])
function HTTPMethods.post(_ENV, callback, statusCodes, extraParams, allowNil)
	if not statusCodes then statusCodes = {} end
	if not statusCodes[1] then statusCodes[1] = HTTPStatusCode.InternalServerError end
	if not statusCodes[2] then statusCodes[2] = HTTPStatusCode.BadRequest end
	local data, result, errorMsg = nil, nil, nil
	data, errorMsg = gf.getDecodedJSONPayload(_ENV)
	if data or allowNil then
		result, errorMsg = callback(data, extraParams)
		if type(result) ~= 'nil' then
			response:write(result)
		else
			gf.sendError(_ENV, statusCodes[1], errorMsg)
		end
	else
		gf.sendError(_ENV, statusCodes[2], errorMsg)
	end
end

-- HTTPMethods.get(_ENV, callback[, statusCode[, {extraParams}[, forceJsonEncode]]])
function HTTPMethods.get(_ENV, callback, statusCode, extraParams, forceJsonEncode)
	if not statusCode then statusCode = HTTPStatusCode.BadRequest end
	local result, errorMsg = callback(extraParams)
	if result then
		if forceJsonEncode then result = ba.json.encode(result) end
		response:write(result)
	else
		gf.sendError(_ENV, statusCode, errorMsg)
	end
end

-- HTTPMethods.put(_ENV, callback, [, {statusCodes}[, {extraParams}]])
function HTTPMethods.put(_ENV, callback, statusCodes, extraParams)
	HTTPMethods.post(_ENV, callback, statusCodes, extraParams)
end

-- HTTPMethods.delete(_ENV, callback[, hasPayload[, {statusCodes}[, {extraParams}]]])
function HTTPMethods.delete(_ENV, callback, hasPayload, statusCodes, extraParams)
	if not statusCodes then statusCodes = {} end
	if hasPayload then
		HTTPMethods.post(_ENV, callback, statusCodes, extraParams)
	else
		if not statusCodes[1] then statusCodes[1] = HTTPStatusCode.BadRequest end
		HTTPMethods.get(_ENV, callback, statusCodes[1], extraParams)
	end
end

return HTTPMethods