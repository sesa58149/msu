local VariableRESTHandler = {}

function VariableRESTHandler.getVariables()
    local result, errorMsg = Variable.get(true)
    if not result then
        return result, errorMsg
    end
    result, errorMsg = ba.json.encode(result)
    if not result then
        return result, errorMsg
    end
    return result
end

return VariableRESTHandler