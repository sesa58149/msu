local NonAdminRESTHandler = {}

function NonAdminRESTHandler.getHandler(_ENV, path)
	local method = request:method()
    -- Ensure that the response is has a content type of JSON
    response:setheader('content-type', 'application/json; charset=UTF-8')
    -- http://domain/rest/nonadmin
    local userName = (request:user()):match('^%w+')
    if(path == '') then
		if(method == 'PUT') then
			HTTPMethods.put(_ENV, NonAdminRESTHandler.changePassword, {HTTPStatusCode.Conflict}, {user=userName, request=request})
		elseif(method == 'GET') then
            HTTPMethods.get(_ENV, NonAdminRESTHandler.getUserInfo, {}, userName)
        else
			-- Not Implemented
			gf.sendError(_ENV)
		end
	elseif path:lower() == 'lang' or path:lower() == 'lang/' then
        if (method == 'POST') then
            HTTPMethods.put(_ENV, NonAdminRESTHandler.changeLanguage, {}, userName)
        else
            -- Not Implemented
            gf.sendError(_ENV)
        end
    else
		-- Not Implemented
		gf.sendError(_ENV)
	end
	response:flush()
end

function NonAdminRESTHandler.changeLanguage(userData, userName)
	if not userName or userName == "" then
        return	nil, ErrorCodes.USER_DOES_NOT_EXIST
    end
    local result, errorMsg = User.changeLanguage(userName, userData.language)
	if result then
		return ba.json.encode({success = true}), nil
	else
		return nil, errorMsg
	end
end

function NonAdminRESTHandler.changePassword(userData, options)
	local result, errorMsg = nil, nil
	local oldPassword, errorMsg = Security.getPassword(options.user, _ENV)
	if oldPassword == userData.oldPassword then
		result, errorMsg = User.changePassword(options.user, userData, 0)
	else
		errorMsg = ErrorObject.new(ErrorCodes.INCORRECT_PASSWORD, nil, { field = "password" })
	end
	if result then
        options.request:logout(true)
        options.request = nil
		return ba.json.encode({success = true}), nil
	else
		return nil, errorMsg
	end
end

function NonAdminRESTHandler.getUserInfo(userName)
    local result, errorMsg = User.get(userName)
    if not result then
        return nil, errorMsg
    end
    local pwPolicy, errorMsg = SecurityDA.getPwPolicy()
    if not pwPolicy then
        return nil, errorMsg
    end

    -- Add the password policy information
    result[1].is_enabled = pwPolicy.is_enabled
    result[1].req_special = pwPolicy.req_special
    result[1].req_num = pwPolicy.req_num
    result[1].history = pwPolicy.history
    result[1].req_alpha = pwPolicy.req_alpha
    result[1].min_length = pwPolicy.min_length

    return ba.json.encode(result)
end

return NonAdminRESTHandler