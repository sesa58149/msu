-- UMAS : Read Multiple BOL

local WriteCmdAndTarget = {}

function WriteCmdAndTarget.isValidInput(input)
    if type(input) ~= 'table' then
        return false
    end

    if type(input.sessionID) ~= 'number' or type(input.speed) ~= 'number' or type(input.startRun) ~= 'boolean' or type(input.resetFault) ~= 'boolean' or type(input.direction) ~= 'boolean' then
        return false
    end

    -- Valid variables
    return true
end

function WriteCmdAndTarget.getData(input)
    local result, data, errorMsg = nil, nil, nil

    -- Check input validity
    if WriteCmdAndTarget.isValidInput(input) then

        if LuaADL and not _G.forceSimulation then
            local commandWord = WriteCmdAndTarget.generateCommandWord(input.startRun, input.resetFault, input.direction)
            data, errorMsg = LuaADL.ExecuteService(Constants.DRIVE_UNIT_ID, input.sessionID, 0x01, 0x02, 0x4, {bit32.extract(input.speed, 8,8), bit32.extract(input.speed, 0,8), 0, 0})
            -- Perform Request
            data, errorMsg = LuaADL.ExecuteService(Constants.DRIVE_UNIT_ID, input.sessionID, 0x01, 0x02, 0x4, {bit32.extract(input.speed, 8,8), bit32.extract(input.speed, 0,8), bit32.extract(commandWord, 8,8), bit32.extract(commandWord, 0,8)})
        else
            data, errorMsg = WriteCmdAndTarget.getSimulationData()
        end

        if WriteCmdAndTarget.isValidResponse(data) then
            result = WriteCmdAndTarget.generateServiceResponse(data, variables)
        end

    else
        errorMsg = ErrorCodes.INVALID_REQUEST
    end

    if result == nil and type(errorMsg) ~= 'string' then
        errorMsg = ErrorCodes.UNKNOWN_ERROR
    end

    --Return variable data with values
    return result, errorMsg
end

function WriteCmdAndTarget.generateCommandWord(startRun, resetFault, direction)
    if resetFault then
        return 2
    end

    local commandWord = 0

    if startRun then
        commandWord = bit32.bor(commandWord, 1)
    end

    if resetFault then
        commandWord = bit32.bor(commandWord, 2)
    end

    if not direction then
        commandWord = bit32.bor(commandWord, 4)
    end

    return commandWord
end

function WriteCmdAndTarget.isValidResponse(data)
    if type(data) ~= 'table' or #data ~= 4 then
        return false
    end

    if type(data[4]) ~= 'table' or #data[4] ~= 7 then
        return false
    end

    for i=1,7 do
        if type(data[4][i]) ~= 'number' then
            return false
        end
    end

    return true
end

function WriteCmdAndTarget.generateServiceResponse(resp)
    local respData = resp[4]

    local result = {}

    status = Utils.convertBytesToInt32(respData[1], respData[2], respData[3], respData[4])

    result.isMemorizationInProgress = bit32.extract(status, 0, 1) == 1
    result.isHighPowerSupplyOn = bit32.extract(status, 1, 1) == 1
    result.isDriveRunning = bit32.extract(status, 2, 1) == 1
    result.isInDCInjection = bit32.extract(status, 3, 1) == 1
    result.isGoingForward = bit32.extract(status, 4, 1) == 0
    result.faultState = bit32.extract(status, 5, 2)
    result.isControlledByCommTool = bit32.extract(status, 7, 1) == 1
    result.isControlledByMyCommTool = bit32.extract(status, 8, 1) == 1
    result.isInForcedLocalMode = bit32.extract(status, 9, 1) == 1
    result.isDriveReadyToRun = bit32.extract(status, 10, 1) == 0
    result.isBlockedByDisableVoltage = bit32.extract(status, 11, 1) == 1
    result.isBlockedByDCStopOrder = bit32.extract(status, 12, 1) == 1
    result.isBlockedByFastStopOrder = bit32.extract(status, 13, 1) == 1
    result.isBlockedBySTOOrder = bit32.extract(status, 14, 1) == 1
    result.isDriveLocked = bit32.extract(status, 15, 1) == 1

    return result
end

function WriteCmdAndTarget.getSimulationData(obj)
    return {1,0,7,{0,0,1,130,0,0,0}}
end

return WriteCmdAndTarget