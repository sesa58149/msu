-- UMAS : Read Multiple BOL

local CloseSession = {}

function CloseSession.isValidInput(input)
    if type(input) ~= 'table' then
        return false
    end

    if type(input.sessionID) ~= 'number' then
       return false
    end

    -- Valid variables
    return true
end

function CloseSession.getData(input)
    local result, data, errorMsg = nil, nil, nil

    -- Check input validity
    if CloseSession.isValidInput(input) then

        if LuaADL and not _G.forceSimulation then
            -- Perform Request
            data, errorMsg = LuaADL.CloseSession(Constants.DRIVE_UNIT_ID, input.sessionID)
        else
            data, errorMsg = CloseSession.getSimulationData()
        end

        if CloseSession.isValidResponse(data) then
            result = CloseSession.generateServiceResponse(data, variables)
        end
    else
        errorMsg = ErrorCodes.INVALID_REQUEST
    end

    --Return variable data with values
    return result, errorMsg
end

function CloseSession.isValidResponse(data)
    return type(data) == 'boolean'
end

function CloseSession.generateServiceResponse(resp)
    return {success = resp}
end

function CloseSession.getSimulationData(obj)
    return true
end

return CloseSession