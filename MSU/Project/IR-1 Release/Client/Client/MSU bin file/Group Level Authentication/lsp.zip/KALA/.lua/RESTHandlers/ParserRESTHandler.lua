local ParserRESTHandler = {}

function ParserRESTHandler.restructurJSON(data)
	local mT = {}
	local table = ba.json.decode(data)
	local obj = {}
	for k,v in pairs(table['ID_CHARAC']) do
		obj[k] =  table['ID_CHARAC'][k]
	end

	mT[#mT+1]= obj;
	for i=1, #table['ID_STRUCT'] do
		local obj =  {}
		
		for k,v in pairs(table['ID_STRUCT'][i]) do
			obj['ID_DNAME'] = k
			for key,value in pairs(table['ID_STRUCT'][i][k]) do
				obj[key] =  table['ID_STRUCT'][i][k][key]
			end
			mT[#mT+1]= obj;
		end
	end
	return ba.json.encode(mT)
end

function ParserRESTHandler.getHandler(_ENV,path)
    local method = request:method()
    -- Ensure that the response is has a content type of JSON
     response:setheader('content-type', 'application/json; charset=UTF-8')
	if (method == 'GET') then
		if (path) and (string.lower(path) == 'identification' ) then	
			HTTPMethods.get(_ENV, ParserRESTHandler.getIdentification)	
		elseif (path) and (string.lower(path) == 'devicename' ) then
			HTTPMethods.get(_ENV, ParserRESTHandler.getDeviceName)
		else
			gf.sendError(_ENV, {},ErrorObject.new(ErrorCodes.INVALID_REQUEST, '', nil, HTTPStatusCode.NotImplemented))
		end
	end
end

function ParserRESTHandler.getIdentification()
	if _G.isWindows then
		return ParserRESTHandler.readIdentificationFile()
	else
		return ParserRESTHandler.readIdentificationFile("ram") --read file on the RAM
	end
end

function ParserRESTHandler.readIdentificationFile(ioType)
	local fileContent, errMsg = gf.readFile(Constants.IDENTITY, ioType)
	if fileContent then
		return ParserRESTHandler.restructurJSON(fileContent), nil
	else
		return nil, errorMsg
	end
end

function ParserRESTHandler.getDeviceName()
	local result,errorMsg = Network.getDeviceName()
	if (result) then
		return ba.json.encode({deviceName = result}), nil
	else
		return nil, errorMsg
	end
end

return ParserRESTHandler