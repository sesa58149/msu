-- UMAS : Read Multiple BOL

local Heartbeat = {}

function Heartbeat.isValidInput(input)
    if type(input) ~= 'table' then
        return false
    end

    if type(input.sessionID) ~= 'number' then
       return false
    end

    -- Valid variables
    return true
end

function Heartbeat.getData(input)
    local result, data, errorMsg = nil, nil, nil

    -- Check input validity
    if Heartbeat.isValidInput(input) then
        if LuaADL and not _G.forceSimulation then
            -- Perform Request
            data, errorMsg = LuaADL.HeartBeat(Constants.DRIVE_UNIT_ID, input.sessionID)
        else
            data, errorMsg = Heartbeat.getSimulationData()
        end

        if Heartbeat.isValidResponse(data) then
            result = Heartbeat.generateServiceResponse(data, variables)
        end
    else
        errorMsg = ErrorCodes.INVALID_REQUEST
    end

    --Return variable data with values
    return result, errorMsg
end

function Heartbeat.isValidResponse(data)
    return type(data) == 'boolean'
end

function Heartbeat.generateServiceResponse(resp)
    return {success = resp}
end

function Heartbeat.getSimulationData(obj)
    return true
end

return Heartbeat