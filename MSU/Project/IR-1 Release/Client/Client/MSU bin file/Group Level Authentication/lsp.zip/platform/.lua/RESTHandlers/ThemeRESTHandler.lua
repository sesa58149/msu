local ThemeRESTHandler = {}

function ThemeRESTHandler.getHandler(_ENV,path)
	local result, errorMsg, themeData = nil
    local method = request:method()
	response:setheader('content-type', 'application/json; charset=UTF-8')

    if(path == '') then
		-- GET http://localhost/rest/theme :: List Theme List
        if (method == 'GET') then
			HTTPMethods.get(_ENV, ThemeRESTHandler.getThemeList)
		-- POST http://localhost/rest/theme :: Add New Theme
        elseif (method == 'POST') then
			HTTPMethods.post(_ENV, ThemeRESTHandler.crudTheme, {HTTPStatusCode.Conflict}, false)
		-- Unknown method
		else
            gf.sendError(_ENV)
        end
    else
        if not path:match('^[%w_]+$') and not path:match("^[%w_]+/.*$") then
			gf.sendError(_ENV, HTTPStatusCode.BadRequest, ErrorCodes.INVALID_REQUEST)
		else
			local themeName = path:match('^[%w_]+')
            -- GET http://localhost/rest/theme/themeid :: Retrieve specific theme
			if(method == 'GET') then
				HTTPMethods.get(_ENV, ThemeRESTHandler.getTheme, HTTPStatusCode.NotFound, themeName)
			-- PUT http://localhost/rest/theme/themeid :: Update a specific theme
			elseif(method == 'PUT') then
				HTTPMethods.put(_ENV, ThemeRESTHandler.crudTheme, {HTTPStatusCode.NotFound}, true)
			-- DELETE http://localhost/rest/theme/themeName :: Delete a specific theme
			elseif (method == 'DELETE') then
				HTTPMethods.delete(_ENV, ThemeRESTHandler.deleteTheme, false,
					{HTTPStatusCode.InternalServerError}, themeName)
			-- Unknown method
			else
				gf.sendError(_ENV)
			end
		end
    end
end
function ThemeRESTHandler.getThemeList()
	local result, errorMsg = Theme.get()
	if not errorMsg then
		return ba.json.encode(result), nil
	else
		return nil, errorMsg
	end
end
function ThemeRESTHandler.getTheme(themeName)
	local themeData = Theme.get(themeName)
	if next(themeData) ~= nil then
		--If not empty, respond with theme data in JSON format
		return ba.json.encode(themeData[1]), nil
	else
		-- Respond not found if theme doesn't exist
		return nil, ErrorCodes.THEME_DOES_NOT_EXIST
	end
end
function ThemeRESTHandler.crudTheme(themeData, isUpdate)
	local result = false
	local errorMsg = nil
	if themeData then
		if not isUpdate then
			result, errorMsg = Theme.create(themeData)
		else
			result, errorMsg = Theme.update(themeData)
		end

		if result then
			return tostring(result), nil
		else
			return nil, errorMsg
		end
	else
		return nil, ErrorCodes.INVALID_REQUEST
	end
end
function ThemeRESTHandler.deleteTheme(themeName)
	local result, errorMsg = Theme.delete(themeName)
	if result then
		return tostring(result), nil
	else
		return nil, errorMsg
	end
end

return ThemeRESTHandler