local TrendViewerRESTHandler = {}

function TrendViewerRESTHandler.getHandler(_ENV,path)
	local method = request:method()
	if (method == 'GET') then
		if (path) and (string.lower(path) == '' ) then
			response:setcontenttype('application/json; charset=UTF-8')
			TrendViewerRESTHandler.getData(_ENV)
		end
	end
end

function TrendViewerRESTHandler.getData(_ENV)
	local fileContent, errMsg = {}, nil
	if _G.isWindows then
		fileContent, errMsg = gf.readFile(Constants.TRENDVIEWER, "disk")
		response:write(fileContent)
		return ba.json.encode(ba.json.decode(fileContent)), nil
	else
		local handler = gf.openFileDrive(Constants.TRENDVIEWER, 0);
		if (handler) then
			while fileContent ~= nil do
				fileContent, errMsg =  gf.readFileDriveByBlock(handler, true);
				if (fileContent ~= nil) then
					response:write(fileContent)
				end
			end
			gf.closeFileDrive(handler);
		end
	end
end

return TrendViewerRESTHandler