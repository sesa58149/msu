local NetworkRESTHandler = {}
local fdrPending, typefdr = false, -1

function NetworkRESTHandler.getHandler(_ENV,path)
    local method = request:method()
    -- Ensure that the response has a content type of JSON
    response:setheader('content-type', 'application/json; charset=UTF-8')
    -- http://domain/rest/user
    if path:len() < 1 then
        gf.sendError(_ENV, HTTPStatusCode.BadRequest, ErrorCodes.UNSPECIFIED_DIAG)
	elseif path:lower() == 'ioscan/' or path:lower() == 'ioscan' then
		if method == 'GET' then
			HTTPMethods.get(_ENV, NetworkRESTHandler.getIOScan)
		elseif method == 'POST' then
			HTTPMethods.post(_ENV, NetworkRESTHandler.setIOScan)
        else
            gf.sendError(_ENV)
        end
    elseif path:lower() == 'masterip/' or path:lower() == 'masterip' then
		if method == 'GET' then
			trace(get)
			HTTPMethods.get(_ENV, NetworkRESTHandler.getMasterIP)
		elseif method == 'POST' then
			HTTPMethods.post(_ENV, NetworkRESTHandler.setMasterIP)
		else
            gf.sendError(_ENV)
        end    
	elseif path:lower() == 'tcpip/' or path:lower() == 'tcpip' then
		if method == 'GET' then
			HTTPMethods.get(_ENV, NetworkRESTHandler.getTCPIP)
		elseif method == 'POST' then
			HTTPMethods.post(_ENV, NetworkRESTHandler.setTCPIP)
		else
            gf.sendError(_ENV)
        end
    elseif path:lower() == 'fdr/' or path:lower() == 'fdr' then
		if method == 'GET' then
			HTTPMethods.get(_ENV, NetworkRESTHandler.getFDR)
		elseif method == 'POST' then
			HTTPMethods.post(_ENV, NetworkRESTHandler.setFDR)
		else
            gf.sendError(_ENV)
        end
    elseif path:lower() == 'trigger/' or path:lower() == 'trigger' then
		if method == 'POST' then
			HTTPMethods.post(_ENV, NetworkRESTHandler.setTrigger)
		else
            gf.sendError(_ENV)
        end
	elseif path:lower() == 'rstp/' or path:lower() == 'rstp' then
		if method == 'GET' then
			HTTPMethods.get(_ENV, NetworkRESTHandler.getRSTP)
		elseif method == 'POST' then
			HTTPMethods.post(_ENV, NetworkRESTHandler.setRSTP)
		else
            gf.sendError(_ENV)
        end
	elseif path:lower() == 'snmp/' or path:lower() == 'snmp' then
		if method == 'GET' then
			HTTPMethods.get(_ENV, NetworkRESTHandler.getSNMP)
		elseif method == 'POST' then
			HTTPMethods.post(_ENV, NetworkRESTHandler.setSNMP)
		else
            gf.sendError(_ENV)
        end
	elseif path:lower() == 'dns/' or path:lower() == 'dns' then
		if method == 'GET' then
			HTTPMethods.get(_ENV, NetworkRESTHandler.getDNS)
		elseif method == 'POST' then
			HTTPMethods.post(_ENV, NetworkRESTHandler.setDNS)
		else
            gf.sendError(_ENV)
        end
	elseif path:lower() == 'sntp/' or path:lower() == 'sntp' then
		if method == 'GET' then
			HTTPMethods.get(_ENV, NetworkRESTHandler.getSNTP)
		elseif method == 'POST' then
			HTTPMethods.post(_ENV, NetworkRESTHandler.setSNTP)
		else
            gf.sendError(_ENV)
        end
    elseif path:lower() == 'getfdrstatus/' or path:lower() == 'getfdrstatus' then
		if method == 'GET' then
			HTTPMethods.get(_ENV, NetworkRESTHandler.getFDRStatus)
		elseif method == 'POST' then
			HTTPMethods.get(_ENV, NetworkRESTHandler.removePendingFDR)
		else
            gf.sendError(_ENV)
        end
	else
        gf.sendError(_ENV, HTTPStatusCode.BadRequest, ErrorCodes.DIAG_DOES_NOT_EXIST)
    end
end

-- I/O Scanning --
function NetworkRESTHandler.getIOScan()
	local result, errorMsg = Network.getIOScan()
	return result, errorMsg
end

function NetworkRESTHandler.setIOScan(data)
	local result, errorMsg = Network.setIOScan(data)
	return result, errorMsg
end

-- TCP/IP (Device IP and Configuration) --
function NetworkRESTHandler.getTCPIP()
	local result, errorMsg = Network.getTCPIP()
	local speed, errMsg = Network.getRateDuplex()
	if( result ~= nil ) then
		local obj = {
			subnet                 = result[1],
			--subnet2                = result[2],	--UNUSED
			gateway                = result[3],
			--gateway2               = result[4],   --UNUSED
			ip                     = result[5],
			deviceName             = result[6],
			ipAddrAssign           = result[7],
			port1			   	   = speed[1],
		}
		if (#speed > 1) then
			obj["port2"] = 	 speed[2];
		end
		return ba.json.encode(obj), errorMsg
	else
		return nil, errorMsg
	end
end

function NetworkRESTHandler.getFDR()
	local result, errorMsg = Network.getFDR()
	if( result ~= nil ) then
		local obj = {
			configControl          = tonumber(result[1]),
			syncMode               = tonumber(result[2]),
			autoSyncCheckCycleTime = tonumber(result[3]),
			faultBrickDown         = tonumber(result[4]),
			FDRStatus         	   = tonumber(result[5])
		}
		return ba.json.encode(obj), errorMsg 
	else
		return nil, errorMsg
	end
end

function NetworkRESTHandler.setFDR(data)
	local result, errorMsg = Network.setFDR(data)
	return tostring(result), errorMsg
end

function NetworkRESTHandler.getMasterIP()
	local result, errorMsg = Network.getMasterIP()
	if( result ~= nil ) then
		local obj = {
			masterIP1              = result[1],
			masterIP2              = result[2],
			masterIP3              = result[3],
			reservationTime        = tonumber(result[4]),  
			holdupTime             = tonumber(result[5]),
			linkFailureMode       = tonumber(result[6]),
		}
		return ba.json.encode(obj), errorMsg
	else
		return nil, errorMsg
	end
end

function NetworkRESTHandler.setMasterIP(data)
	local result, errorMsg = Network.setMasterIP(data)
	return tostring(result), errorMsg
end

function NetworkRESTHandler.setTCPIP(data)
	--server1IP, subnet, gateway, ip
	if (data.ipAddrAssign == 1) then
		if data.ip == "" then
			return nil, ErrorObject.new(ErrorCodes.FIELD_REQUIRED, '', {field = 'ip'})
		elseif not gf.validateIP(data.ip) then
			return nil, ErrorObject.new(ErrorCodes.INVALID_IP, '', {field = 'ip'})
		elseif data.subnet == "" then
			return nil, ErrorObject.new(ErrorCodes.FIELD_REQUIRED, '', {field = 'subnet'})
		elseif not gf.isSubnetContinuous(data.subnet) then
			return nil, ErrorObject.new(ErrorCodes.INVALID_SUBNET, '', {field = 'subnet'})	
		elseif not gf.validateIP(data.gateway) and data.gateway ~= "" then
			return nil, ErrorObject.new(ErrorCodes.INVALID_IP, '', {field = 'gateway'})
		elseif (data.ip == gf.broadcastAddress(data.ip, data.subnet)) then
			return nil, ErrorObject.new(ErrorCodes.IP_NO_BROADCAST, '', {field = 'ip'})
		elseif (data.ip == data.gateway) then
			return nil, ErrorObject.new(ErrorCodes.IP_NO_GATEWAY, '', {field = 'gateway'})
		elseif not gf.isIPMatchingGateway(data.ip, data.gateway) and data.gateway ~= "" then
			return nil, ErrorObject.new(ErrorCodes.INVALID_GATEWAY , '', {field = 'gateway'})
		elseif (not gf.isSameNetwork(data.ip, data.subnet, data.gateway) and data.gateway ~= "") then
			return nil, ErrorObject.new(ErrorCodes.IP_GATEWAY_SAME_NETWORK, '', {field = 'gateway'})
		elseif (data.gateway == gf.broadcastAddress(data.ip,data.subnet) and data.gateway ~= '') then
			return nil, ErrorObject.new(ErrorCodes.GATEWAY_NO_BROADCAST, '', {field = 'gateway'})
		elseif (data.gateway == gf.networkAddress(data.ip,data.subnet) and data.gateway ~= '') then
			return nil, ErrorObject.new(ErrorCodes.GATEWAY_NO_NETWORK, '', {field = 'gateway'})
		end

	end
	if (#data.deviceName > Constants.MAX_DEVICENAME_LENGTH) then
		return nil, ErrorObject.new(ErrorCodes.FIELD_LENGTH_BETWEEN_RANGE, '', {field = 'deviceName', parameterMsg = {0, Constants.MAX_DEVICENAME_LENGTH}})
	end
	local result, errorMsg = Network.setTCPIP(data)
	return tostring(result), errorMsg
end

function NetworkRESTHandler.setTrigger(data)
	if (fdrPending) then
		if (typefdr == 0) then
			return nil, ErrorObject.new(ErrorCodes.FDR_PENDING_1) --Restore
		else
			return nil, ErrorObject.new(ErrorCodes.FDR_PENDING_2) --Push
		end
	end 
	local result, errorMsg = nil, nil
	if (data) then
		result, errorMsg = Network.setTrigger(data)
		typefdr = data.direction
	else
		result, errorMsg = nil, ErrorObject.new(ErrorCodes.UNSPECIFIED_DIAG)	
	end
	return ba.json.encode(data), errorMsg
end
-- RSTP - Does this even exist? It doesn't look like it's in the menu...--
function NetworkRESTHandler.getRSTP()
	local result, errorMsg = Network.getRSTP()
	return result, errorMsg
end

function NetworkRESTHandler.setRSTP(data)
	local result, errorMsg = Network.setRSTP(data)
	return result, errorMsg
end

-- SNMP --
function NetworkRESTHandler.getSNMP()
	local result, errorMsg = Network.getSNMP()
	if errorMsg == nil and result ~= nil then
		local obj = {
			manager1IP     = result[1],
			manager2IP     = result[2],
			systemName     = result[3],
			systemLocation = result[4],
			systemContact  = result[5],
			communityGet   = result[6],
			communitySet   = result[7],
			communityTrap  = result[8],
			enabledTraps   = tonumber(result[9])
		}
		return ba.json.encode(obj)
	else
		return nil, errorMsg
	end
end

function NetworkRESTHandler.setSNMP(data)
	if (data.manager1IP == nil or data.manager1IP == "") then
		return nil, ErrorObject.new(ErrorCodes.INVALID_IP, '', {field = 'manager1IP'})
	end
	if (#data.systemName > Constants.MAX_DEVICENAME_LENGTH) then
		return nil, ErrorObject.new(ErrorCodes.FIELD_LENGTH_BETWEEN_RANGE, '', {field = 'systemName', parameterMsg = {0, Constants.MAX_DEVICENAME_LENGTH}})
	end
	if (#data.systemLocation > Constants.MAX_LOCATION_LENGTH) then
		return nil, ErrorObject.new(ErrorCodes.FIELD_LENGTH_BETWEEN_RANGE, '', {field = 'systemLocation', parameterMsg = {0, Constants.MAX_LOCATION_LENGTH}})
	end
	if (#data.systemContact > Constants.MAX_CONTACT_LENGTH) then
		return nil, ErrorObject.new(ErrorCodes.FIELD_LENGTH_BETWEEN_RANGE, '', {field = 'systemContact', parameterMsg = {0, Constants.MAX_CONTACT_LENGTH}})
	end
	if (#data.communityGet > Constants.MAX_GET_LENGTH) then
		return nil, ErrorObject.new(ErrorCodes.FIELD_LENGTH_BETWEEN_RANGE, '', {field = 'communityGet', parameterMsg = {0, Constants.MAX_GET_LENGTH}})
	end
	if (#data.communitySet > Constants.MAX_SET_LENGTH) then
		return nil, ErrorObject.new(ErrorCodes.FIELD_LENGTH_BETWEEN_RANGE, '', {field = 'communitySet', parameterMsg = {0, Constants.MAX_SET_LENGTH}})
	end
	if (#data.communityTrap > Constants.MAX_TRAP_LENGTH) then
		return nil, ErrorObject.new(ErrorCodes.FIELD_LENGTH_BETWEEN_RANGE, '', {field = 'communityTrap', parameterMsg = {0, Constants.MAX_TRAP_LENGTH}})
	end

	local result, errorMsg = Network.setSNMP(data)
	return tostring(result), errorMsg
end

-- DNS --
function NetworkRESTHandler.getDNS()
	local result, errorMsg = Network.getDNS()
	if errorMsg == nil and result ~= nil then
		local obj = {
			isDHCPEnabled   = tonumber(result[1]),
			preferredServer = result[2],
			alternateServer = result[3]
		}
		return ba.json.encode(obj), errorMsg
	else
		return nil, errorMsg
	end
end

function NetworkRESTHandler.setDNS(data)
	local result, errorMsg = Network.setDNS(data)
	return tostring(result), errorMsg
end

-- Date and Time --
function NetworkRESTHandler.getSNTP()
	local result, errorMsg = Network.getSNTP()
	if errorMsg == nil and result ~= nil then
		local obj = {
			ntpEnable       = tonumber(result[1]),
			server1IP       = result[2],
			server2IP       = result[3],
			pollingInterval = tonumber(result[4]),
			timeZone        = tonumber(result[5]),
			dstEnable       = tonumber(result[6]),
			startDate       = NetworkRESTHandler.getDateObj(result[7]),
			endDate         = NetworkRESTHandler.getDateObj(result[8]),
			currentDate     = result[9],
			currentTime     = result[10]
		}
		return ba.json.encode(obj), errorMsg
	else
		return nil, errorMsg
	end
end

function NetworkRESTHandler.getDateObj(obj)
	return {time = obj[1], dayOfWeek = obj[2], weekOfMonth = obj[3], month = obj[4]}
end

function NetworkRESTHandler.setSNTP(data)
	if (data.ntpEnable == 1) then
		if data.server1IP == "" then
			return nil, ErrorObject.new(ErrorCodes.FIELD_REQUIRED, '', {field = 'server1IP'})
		end

		if (tonumber(data.pollingInterval) < Constants.MIN_POLL_INTERVAL or tonumber(data.pollingInterval) > Constants.MAX_POLL_INTERVAL ) then
			return nil, ErrorObject.new(ErrorCodes.FIELD_VALUE_BETWEEN_RANGE, '', {field = 'pollingInterval', parameterMsg = {Constants.MIN_POLL_INTERVAL, Constants.MAX_POLL_INTERVAL}})
		end	
	end
	local result, errorMsg = Network.setSNTP(data)
	return tostring(result), errorMsg
end

function NetworkRESTHandler.getFDRStatus()
	local status = Network.readFDRStatus()
	local resultObj = nil
	if (status == 1) then
		Network.eraseFDRStatus()
		fdrPending = false
		typefdr = -1
		resultObj = NetworkRESTHandler.getFDRResult()
	elseif (not fdrPending) then
		fdrPending = true
	end
	return ba.json.encode({status = tonumber(status), result = resultObj}), nil
end

function  NetworkRESTHandler.removePendingFDR()
	if (fdrPending) then
		fdrPending = false
	end
	return tostring(false), nil
end

function NetworkRESTHandler.getFDRResult()
	local result = Network.readFDRResult()
	local objResult = {}
	for i=1, #result do
		for j=0, 16 do
			table.insert(objResult, NetworkRESTHandler.ParseFDRResult(i, j, bit32.extract(result[i], j, 1)))
		end
	end
	return objResult, nil
end

function NetworkRESTHandler.ParseFDRResult(register, index, bit)
	if (register == 1) then
		if (index == 1 and bit == 1) then
			return 'NO_RESPONSE_FDRSERVER'
		elseif (index == 2 and bit == 1) then
			return 'NO_FILE_FDRSERVER'
		elseif (index == 3 and bit == 1) then
			return 'CORRUPT_FILE_FDRSERVER'
		elseif (index == 4 and bit == 1) then
			return 'EMPTY_FILE_FDRSERVER'
		elseif (index == 5 and bit == 1) then
			return 'WRITE_ERROR_DEVICE'
		elseif (index == 6 and bit == 1) then
			return 'WRITE_ERROR_FDRSERVER'
		elseif (index == 7 and bit == 1) then
			return 'HOST_PROVIDED_INVALID'
		elseif (index == 8 and bit == 1) then
			return 'CRC_MISMATCH'
		elseif (index == 12 and bit == 1) then
			return 'PARAMETER_VERSION_MISMATCH'
		elseif (index == 15 and bit == 1) then
			return 'FDR_OPERATIONAL'
		else
			return nil
		end
	elseif (register == 3) then
		if (index == 0 and bit == 1) then
			return 'NO_FILE_HOST'
		elseif (index == 1 and bit == 1) then
			return 'NO_PRMFILE_HOST'
		elseif (index == 2 and bit == 1) then
			return 'NO_OPEN_PRMFILE_HOST'
		elseif (index == 3 and bit == 1) then
			return 'NO_READ_PRMFILE_HOST'
		elseif (index == 4 and bit == 1) then
			return 'COUNT_NO_MATCH_PRM_HOST'
		elseif (index == 5 and bit == 1) then
			return 'INVALID_FILENAME_FDRSERVER'
		elseif (index == 6 and bit == 1) then
			return 'FILESIZE_PRM_FDRSERVER'
		elseif (index == 7 and bit == 1) then
			return 'NO_OPEN_PRMFILE_FDRSERVER'
		elseif (index == 8 and bit == 1) then
			return 'NO_READ_PRMFILE_FDRSERVER'
		else 
			return nil
		end
	else
		return nil
	end
end

return NetworkRESTHandler