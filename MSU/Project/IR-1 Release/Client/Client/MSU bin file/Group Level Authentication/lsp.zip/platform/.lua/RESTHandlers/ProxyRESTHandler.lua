local ProxyRESTHandler = {}
http = require('http')
function ProxyRESTHandler.getHandler(_ENV,path)
    local method = request:method()
    -- Ensure that the response is has a content type of JSON
    response:setheader('content-type', 'application/json; charset=UTF-8')
    if(path == '') then
        if (method == 'POST') then
            HTTPMethods.post(_ENV, ProxyRESTHandler.performProxing, {HTTPStatusCode.BadRequest}, false)
        -- Unknown method
        else
            gf.sendError(_ENV)
        end
    else
        gf.sendError(_ENV)
    end
end
-- Input:
--      ip
--      uri
--      method
--      port
--      payload (optional)
-- Output:
--      http-status-code
--      response (this maybe an error depending on status code)
function ProxyRESTHandler.performProxing(input)
    -- Make sure method is uppercase
    input.method = input.method:upper()
    if type(input.payload) == "table" then
        -- Encode the object into JSON
        input.payload = ba.json.encode(input.payload)
    end

    local op={
        url="http://" .. input.ip .. ':' .. input.port .. '/' .. input.uri,
        method=input.method
    }
    local h=http.create(op)
    h:request()
    if input.method:upper() == "POST" or input.method:upper() == "PUT" and input.payload:len() > 0 then
        local successfulWrite, errorMsg = h:write(input.payload)
        if not successfulWrite then
            return ba.json.encode({
                httpCode=500,
                response="Master Error: HTTP Write Failed when performing the request.",
                devMsg= errorMsg
            })
        end
    end
    local result, errorMsg = h:read"*a"
    if not result then
        result = errorMsg
    end
    local httpStatus = h:status()
    h:close()
    return ba.json.encode({
        httpCode=httpStatus,
        response=result
    })
end

-- Basic Tests
--print(ba.json.encode(performProxing({ip="localhost", port="80", uri="rest/umas/readmultiplebol/", method="POST", payload={4324, {{offset="420", bitOffset="1", block="43", dataType="4"}}}})))
--print(ba.json.encode(performProxing({ip="localhost", port="80", uri="rest/user/", method="GET"})))
--print(ba.json.encode(performProxing({ip="localhost", port="80", uri="rest/datatable/Table1/", method="DELETE"})))
--print(ba.json.encode(performProxing({ip="localhost", port="80", uri="rest/datatable/Table2", method="PUT", payload={description="agbafa", previousId="Table2", id="SuperTable"}})))

return ProxyRESTHandler