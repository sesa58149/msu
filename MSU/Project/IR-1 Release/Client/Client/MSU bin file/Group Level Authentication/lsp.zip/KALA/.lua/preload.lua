return function (dir)
    collectgarbage("setpause", 100)
    collectgarbage("setstepmul", 5000)
    collectgarbage("restart")

    local io = ba.openio(_G.diskIOName)

    _G.Security       = io:dofile('platform/.lua/Security.lua')
    _G.SecurityDA     = io:dofile('platform/.lua/data-access/Security.lua')
    _G.HTTPStatusCode = io:dofile('platform/.lua/HTTPStatusCode.lua')
    _G.HTTPMethods    = io:dofile('platform/.lua/HTTPMethods.lua')
    _G.ErrorObject    = io:dofile('platform/.lua/ErrorObject.lua')
    _G.Constants      = io:dofile('KALA/.lua/Constants.lua')
    _G.ErrorCodes     = io:dofile('KALA/.lua/ErrorCodes.lua')
    _G.gf             = io:dofile('KALA/.lua/GlobalFunctions.lua')
    _G.Utils          = io:dofile('platform/.lua/Utils.lua')
    _G.BinParser      = io:dofile('KALA/.lua/libs/binparser.lua')
    _G.MbC            = io:dofile('platform/.lua/ModbusCommon.lua')

    if _G.isWindows then
        ParametersJSON, ParametersJSONErrorMsg = gf.readFile(Constants.WEBDESCRIPTIONPATH)
    else
        ParametersJSON, ParametersJSONErrorMsg = gf.readFile(Constants.WEBDESCRIPTIONPATH, "ram")
    end

    if ParametersJSON ~= nil then
        ParametersTable = ba.json.decode( ParametersJSON )
    else
        --Try to load the webdesc from web folder
        ParametersJSON, ParametersJSONErrorMsg = gf.readFile('.WebDesc.json', "webram")
        if ParametersJSON ~= nil then
            ParametersTable = ba.json.decode( ParametersJSON )
        else
            trace('FAILED TO OPEN ' .. Constants.WEBDESCRIPTIONPATH .. ' FILE')
        end
    end

    _G.DataTable       = io:dofile('KALA/.lua/data-access/DataTable.lua')
    _G.Chart           = io:dofile('KALA/.lua/data-access/Chart.lua')
    _G.User            = io:dofile('platform/.lua/data-access/User.lua')
    _G.Theme           = io:dofile('platform/.lua/data-access/Theme.lua')
    _G.Dashboard       = io:dofile('platform/.lua/data-access/Dashboard.lua')
    _G.ADL             = io:dofile('KALA/.lua/data-access/ADL.lua')
    _G.Variable        = io:dofile('KALA/.lua/data-access/Variable.lua')
    _G.Diagnostic      = io:dofile('KALA/.lua/data-access/Diagnostic.lua')
    _G.Network         = io:dofile('KALA/.lua/data-access/Network.lua')
    _G.Logo            = io:dofile('platform/.lua/data-access/Logo.lua')
    _G.AutoTest        = io:dofile('KALA/.lua/data-access/AutoTest.lua')
    _G.FileSystem      = io:dofile('KALA/.lua/data-access/FileSystem.lua')
    _G.MultiPart       = io:dofile('KALA/.lua/MultiPart.lua') -- Needs FileSystem
    _G.FC8220x01       = io:dofile('platform/.lua/parsers/modbus/FC-8-22-0x01.lua')
    _G.FC8220x02       = io:dofile('platform/.lua/parsers/modbus/FC-8-22-0x02.lua')
    _G.FC8220x03       = io:dofile('platform/.lua/parsers/modbus/FC-8-22-0x03.lua')
    _G.FC8220x04       = io:dofile('platform/.lua/parsers/modbus/FC-8-22-0x04.lua')
    _G.forceSimulation = false
    _G.allowSession    = true

    -- Make sure that the random number generator returns different numbers
        --math.randomseed( os.time() )
    _G.securityMode = SecurityDA.getMode()
    if _G.securityMode == '1' or _G.securityMode ~= '0' then
        -- Get/Generate the seed
        local salt, errorMsg = Security.getCreateSalt()
        while salt == nil do
            trace('Failed to generate salt. Trying again in 1 second.')
            ba.sleep(1000) -- Sleep for 1 second and try again
            salt, errorMsg = Security.getCreateSalt()
        end

        -- Store the salt globally
        _G.salt = salt

        ------------------------------------------------------------------------
        -- Create the username database from our getPassword func.
        local authuser = ba.create.authuser(Security.getPassword)
        ---- Create authorizer object
        local authorizer = ba.create.authorizer(Security.authorization)

         -- http://domain/logout
        _G.logout = ba.create.dir('logout')
        _G.logout:setfunc(Security.logout)
        dir:insert(_G.logout, true)

        -- Create the authenticator that will be applied to the application's directory
        local authenticator=ba.create.authenticator(authuser,{response=Security.loginResponse, type="form"})

        -- Apply authenticator to our application's resource reader object.
        dir:setauth(authenticator, authorizer)

        -- Upon login check to ensure that the user isn't supposed to be forced to change their password
        dir:setfunc(Security.handleRemindPassword)
        _G.minutesUntilTimeout = tonumber(Security.getSessionTimeout())
    end
    -- http://domain/rest
    local restDirectory = ba.create.dir('rest')
    dir:insertprolog(restDirectory,true)

    -- Create the different URLs to access to REST functions
    --gf.addRESTDirectory('table'        , 'KALA', 'TableRESTHandler'        ) -- http://domain/rest/table
    gf.addRESTDirectory(restDirectory, 'datatable'    , 'KALA'     , 'DataTableRESTHandler'    ) -- http://domain/rest/datatable
    gf.addRESTDirectory(restDirectory, 'adl'          , 'KALA'     , 'ADLRESTHandler'          ) -- http://domain/rest/adl
    gf.addRESTDirectory(restDirectory, 'diagnostic'   , 'KALA'     , 'DiagnosticRESTHandler'   ) -- http://domain/rest/diagnostic
    gf.addRESTDirectory(restDirectory, 'user'         , 'platform' , 'UserRESTHandler'         ) -- http://domain/rest/user
    gf.addRESTDirectory(restDirectory, 'variable'     , 'KALA'     , 'VariableRESTHandler'     ) -- http://domain/rest/variable
    gf.addRESTDirectory(restDirectory, 'chart'        , 'platform' , 'ChartRESTHandler'        ) -- http://domain/rest/chart
    gf.addRESTDirectory(restDirectory, 'theme'        , 'platform' , 'ThemeRESTHandler'        ) -- http://domain/rest/theme
    gf.addRESTDirectory(restDirectory, 'nonadmin'     , 'platform' , 'NonAdminRESTHandler'     ) -- http://domain/rest/nonadmin
    gf.addRESTDirectory(restDirectory, 'network'      , 'KALA'     , 'NetworkRESTHandler'      ) -- http://domain/rest/network
    gf.addRESTDirectory(restDirectory, 'dashboard'    , 'platform' , 'DashboardRESTHandler'    ) -- http://domain/rest/dashboard
    gf.addRESTDirectory(restDirectory, 'file'         , 'KALA'     , 'FileRESTHandler'         ) -- http://domain/rest/file
    gf.addRESTDirectory(restDirectory, 'parser'       , 'KALA'     , 'ParserRESTHandler'       ) -- http://domain/rest/parse
    gf.addRESTDirectory(restDirectory, 'security'     , 'platform' , 'SecurityRESTHandler'     ) -- http://domain/rest/parse
    gf.addRESTDirectory(restDirectory, 'iostatus'     , 'KALA'     , 'IOStatusRESTHandler'     ) -- http://domain/rest/iostatus
    gf.addRESTDirectory(restDirectory, 'kwreport'     , 'KALA'     , 'KWReportRESTHandler'     ) -- http://domain/rest/kwreport
    gf.addRESTDirectory(restDirectory, 'logo'         , 'platform' , 'LogoRESTHandler'         )
    gf.addRESTDirectory(restDirectory, 'pumpdashboard', 'KALA'     , 'PumpDashboardRESTHandler') -- http://domain/rest/pumpdashboard
    gf.addRESTDirectory(restDirectory, 'autotest'     , 'KALA'     , 'AutoTestRESTHandler')
    gf.addRESTDirectory(restDirectory, 'trendviewer'  , 'KALA'     , 'TrendViewerRESTHandler') -- http://domain/rest/trendviewer

    -- Hook up label file to it's own resource directory
    labelsResrdr = ba.create.resrdr(nil, 2, ba.mkio(ba.openio(_G.diskIOName), "KALA/.labels.zip"))
    labelsResrdr:insert()
end