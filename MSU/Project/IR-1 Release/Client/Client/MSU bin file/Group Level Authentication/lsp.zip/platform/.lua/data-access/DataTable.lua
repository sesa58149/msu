local DataTable = {}

function DataTable.update(tableData)
    if luasql == nil then
        return false, ErrorCodes.NO_SQL -- ONLY FOR THE NOSQL VERSION
    end

    local env = luasql.sqlite()
    local connection = env:connect(Constants.DB_PATH)
    local isLockAcquired = connection:setautocommit('IMMEDIATE', 1000)
    local result = false
    local errorMsg = nil

    if isLockAcquired then
        local validTable = false
        --Avoid XSS
        tableData.id = gf.htmlspecialchars(tableData.id)
        tableData.description = gf.htmlspecialchars(tableData.description)
        
        validTable, errorMsg = DataTable.validateTable(connection, tableData, true)
        if validTable then
            local cursor = nil
            if tableData.id ~= tableData.previousId then
                cursor = connection:prepare([[
                    UPDATE data_table
                    SET table_name = ( ? ), description = ( ? )
                    WHERE table_name == ( ? )
                ]])
                cursor:bind{
                    {'TEXT', tableData.id},
                    {'TEXT', tableData.description},
                    {'TEXT', tableData.previousId}
                }
            else
                cursor = connection:prepare([[
                    UPDATE data_table
                    SET description = ( ? )
                    WHERE table_name == ( ? )
                ]])
                cursor:bind{
                    {'TEXT', tableData.description},
                    {'TEXT', tableData.id}
                }
            end

            local numberOfRows = cursor:execute()

            if(numberOfRows == 1 and tableData.id ~= tableData.previousId) then
                cursor = connection:prepare([[
                    UPDATE data_table_variable
                    SET table_name = ( ? )
                    WHERE table_name == ( ? )
                ]])
                cursor: bind{
                    {'TEXT', tableData.id},
                    {'TEXT', tableData.previousId}
                }
                local exec = cursor:execute()
                if not exec then
                    errorMsg = ErrorCodes.UPDATE_DT_VARS_FAILED
                else
                    if connection:commit() then
                        result = true
                    else
                        errorMsg = ErrorCodes.COMMIT_FAIL

                        --local rollback = connection:rollback('IMMEDIATE')
                        --if not rollback then
                        --  trace('Rollback failed')
                        --end
                    end
                end
            elseif tableData.id == tableData.previousId then
                if connection:commit() then
                    result = true
                else
                    errorMsg = ErrorCodes.COMMIT_FAIL
                end
            else
                errorMsg = ErrorCodes.UPDATE_DT_FAILED
            end

            if not cursor:close() then
                trace('FAILED TO CLOSE CURSOR')
            end
        end
    else
        errorMsg = ErrorCodes.LOCK_FAIL
    end
    -- Close connection to database
    if not connection:close() then
        trace('FAILED TO CLOSE SQLITE CONNECTION')
    end
    -- Close connection to SQLite
    if not env:close() then
        trace('FAILED TO CLOSE SQLITE ENVIRONMENT')
    end

    return result, errorMsg
end

function DataTable.exists(connection, tableName)
    local result = false
    local errorMsg = nil

    local cursor = connection:prepare([[
        SELECT COUNT(*)
        FROM data_table
        WHERE table_name == ( ? )
    ]])
    if cursor then
        cursor:bind{{'TEXT', tableName}}
        local exec = cursor:execute()
        if exec then
            -- Get the result
            local queryResult = {}
            cursor:fetch(queryResult)

            local numberOfTables = queryResult[1]
            result = tonumber(numberOfTables) > 0
        else
            errorMsg = ErrorCodes.DATABASE_ERROR
        end
        -- Close cursor
        if not cursor:close() then
            trace('FAILED TO CLOSE CURSOR')
        end
    else
        errorMessage = ErrorCodes.INVALID_SQL_SYNTAX
    end

    return result, errorMsg
end

function DataTable.delete(tableName)
    if luasql == nil then
        return false, ErrorCodes.NO_SQL -- ONLY FOR THE NOSQL VERSION
    end

    local result = false
    local errorMsg = nil
    -- Reference SQLite environment
    local env = luasql.sqlite()
    --Create DB connection
    local connection = env:connect(Constants.DB_PATH)
    -- Establish a lock to prevent conflicting db calls
    local isLockAcquired = connection:setautocommit('IMMEDIATE', 1000)
    if isLockAcquired then
        local tableExists = false
        tableExists, errorMsg = DataTable.exists(connection, tableName)
        if tableExists then
            -- Prepare database call
            local cursor =
                connection:prepare([[
                    DELETE FROM data_table_variable
                    WHERE table_name == ( ? )
                ]])
            -- Bind theme name to previous query statement
            cursor:bind{{'TEXT', tableName}}

            -- Execute the query
            local variableRowsDeleted = cursor:execute()

            if not variableRowsDeleted then
                errorMsg = ErrorCodes.DEL_DT_VARS_FAILED
            else
                local cursor = connection:prepare([[
                    DELETE FROM data_table
                    WHERE data_table.table_name = ( ? )
                ]])
                cursor: bind{{'TEXT', tableName}}
                local numTablesDeleted = cursor:execute()
                if not numTablesDeleted then
                    errorMsg = ErrorCodes.DELETE_TABLE_FAILED
                else
                    -- Commit the transaction
                    if connection:commit() then
                        result = true
                    else
                        errorMsg = ErrorCodes.COMMIT_FAIL
                    end
                end
                -- Close cursor connection
                if not cursor:close() then
                    trace('FAILED TO CLOSE CURSOR')
                end
            end
            -- Close cursor connection
            if not cursor:close() then
                trace('FAILED TO CLOSE CURSOR')
            end
        elseif not tableExists and not errorMsg then
            errorMsg = ErrorCodes.TABLE_DOES_NOT_EXIST
        end
    else
        errorMsg = ErrorCodes.LOCK_FAIL
    end

    -- Close db connection
    if not connection:close() then
        trace('FAILED TO CLOSE DB CONNECTION')
    end
    if not env:close() then
        trace('FAILED TO CLOSE DB ENVIRONMENT')
    end

    return result, errorMsg
end

function DataTable.validateTable(connection, tableData, isUpdate)
    local errorMsg = nil
    local result = nil

    if not tableData.id or tableData.id == "" then
        errorMsg = ErrorObject.new(ErrorCodes.FIELD_REQUIRED, "", { field = "id" })
        return false, errorMsg
    end

    if not tableData.description then
        errorMsg = ErrorObject.new(ErrorCodes.FIELD_NIL, "", { field = "description" })
        return false, errorMsg
    end

    if not gf.checkLength(tableData.id, Constants.MIN_TABLE_NAME_LENGTH, Constants.MAX_TABLE_NAME_LENGTH) then
        local msg = "Table name must be between "..Constants.MIN_TABLE_NAME_LENGTH.." and "..Constants.MAX_TABLE_NAME_LENGTH.." characters long."
        errorMsg = ErrorObject.new(ErrorCodes.INVALID_FIELD_LENGTH, msg, { field = "id" })
        return false, errorMsg
    end

    --Web designer only allows alphanumerics and underscore characters, so we should follow that
    if not (tableData.id):match('^[%w_]+$') then
        errorMsg = ErrorObject.new(ErrorCodes.FIELD_INVALID, "", { field = "id" })
        return false, errorMsg
    end

    if not isUpdate or (isUpdate and tableData.id ~= tableData.previousId) then
        result, errorMsg = DataTable.exists(connection, tableData.id)
        if result then
            errorMsg = ErrorObject.new(ErrorCodes.FIELD_ALREADY_EXIST, "", { field = "id" })
            return false, errorMsg
        elseif errorMsg then
            return false, errorMsg
        end
    end

    if not gf.checkLength(tableData.description, Constants.MIN_TABLE_DESC_LENGTH, Constants.MAX_TABLE_DESC_LENGTH) then
        local msg = "Table description must be between "..Constants.MIN_TABLE_DESC_LENGTH.." and "..Constants.MAX_TABLE_DESC_LENGTH.." characters long."
        errorMsg = ErrorObject.new(ErrorCodes.INVALID_FIELD_LENGTH, msg, { field = "description" })
        return false, errorMsg
    end

    return true, nil
end

function DataTable.getNumberOfVariablesInTable(connection, tableName)
    local result = false
    local errorMsg = nil

    local cursor = connection:prepare([[
        SELECT COUNT(*)
        FROM data_table_variable
        WHERE table_name == ( ? )
    ]])
    if cursor then
        cursor:bind{{'TEXT', tableName}}
        local exec = cursor:execute()
        if exec then
            local queryResult = {}
            cursor:fetch(queryResult)
            result = tonumber(queryResult[1])
        else
            errorMsg = ErrorCodes.DATABASE_ERROR
        end
        if not cursor:close() then
            trace('FAILED TO CLOSE CURSOR')
        end
    else
        errorMessage = ErrorCodes.INVALID_SQL_SYNTAX
    end

    return result, errorMsg
end

function DataTable.getTableCount()
    if luasql == nil then
        return false, ErrorCodes.NO_SQL -- ONLY FOR THE NOSQL VERSION
    end

    local result = false
    local errorMsg = nil
    -- Reference SQLite environment
    local env = luasql.sqlite()
    --Create DB connection
    local connection = env:connect(Constants.DB_PATH)
    -- Establish a lock to prevent conflicting db calls
    local isLockAcquired = connection:setautocommit('IMMEDIATE', 1000)
    if isLockAcquired then

        local cursor = connection:prepare([[
            SELECT COUNT(*)
            FROM data_table
        ]])
        if cursor then
            local exec = cursor:execute()
            if exec then
                local queryResult = {}
                cursor:fetch(queryResult)
                result = tonumber(queryResult[1])
            else
                errorMsg = ErrorCodes.DATABASE_ERROR
            end
            if not cursor:close() then
                trace('FAILED TO CLOSE CURSOR')
            end
        else
            errorMessage = ErrorCodes.INVALID_SQL_SYNTAX
        end

    end

    -- Close db connection
    if not connection:close() then
        trace('FAILED TO CLOSE DB CONNECTION')
    end
    if not env:close() then
        trace('FAILED TO CLOSE DB ENVIRONMENT')
    end

    return result, errorMsg
end

return DataTable