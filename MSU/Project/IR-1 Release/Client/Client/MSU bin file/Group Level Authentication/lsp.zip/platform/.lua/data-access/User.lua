local User = {}
User.totalUsers = 0

function User.validatePasswordBasedOnSecuritySettings(username, userdata, connection, isNewUser)
	local result, errorMsg, env = false, nil, nil
	local connectionSupplied = false
	local password, attrs = userdata.newPassword, tonumber(userdata.attrs)
	if connection then connectionSupplied = true end

	if not password or string.len(password) == 0 then
		errorMsg = ErrorObject.new(ErrorCodes.PASSWORD_REQUIRED, nil, { field = "newPassword" })
	else
		local rules = {}

		if not connectionSupplied then
			env = luasql.sqlite()
			connection = env:connect(Constants.DB_PATH, "READONLY")
		end

		local cursor = connection:prepare([[
			SELECT *
			FROM password_policy, config_attributes
			WHERE config_attributes.attr_key == "security_mode"
		]])
		local exec = cursor:execute()
		if exec then
			cursor:fetch(rules, 'a')
			--Check if security is enabled
			if tonumber(rules.attr_value) == 1 then
				--Check if Password policy is being enforced
				if tonumber(rules.is_enabled) == 1 then
					if tonumber(rules.history) == 1 and not isNewUser then
						-- Can't use any of the last 3 passwords
						if not User.checkPreviousPasswords(connection, username, password, 3) then
							errorMsg = ErrorObject.new(ErrorCodes.CANNOT_USE_LAST_3_PASSWORDS, nil, { field = "newPassword" })
						end
					elseif tonumber(rules.history) == 2 and not isNewUser then
						-- Can't use any of the last 5 passwords
						if not User.checkPreviousPasswords(connection, username, password, 5) then
							errorMsg = ErrorObject.new(ErrorCodes.CANNOT_USE_LAST_5_PASSWORDS, nil, { field = "newPassword" })
						end
					end

					if not errorMsg then
						-- Any previous passwords can be used
						if bit32.band(attrs,0x7F) < tonumber(rules.min_length) then
							errorMsg = ErrorObject.new(ErrorCodes.LESS_THAN_MINIMUM_LENGTH, nil, { field = "newPassword", parameterMsg = { rules.min_length } })
						else
							if tonumber(rules.req_alpha) == 1 then
								if bit32.band(bit32.rshift(attrs,7), 1) ~= 1 then
									errorMsg = ErrorObject.new(ErrorCodes.PASSWORD_REQUIRES_ALPHA_CHAR, nil, { field = "newPassword" })
								end
							end
							if tonumber(rules.req_num) == 1 then
								if bit32.band(bit32.rshift(attrs,8), 1) ~= 1 then
									errorMsg = ErrorObject.new(ErrorCodes.PASSWORD_REQUIRES_NUM_CHAR, nil, { field = "newPassword" })
								end
							end
							if tonumber(rules.req_special) == 1 then
								if bit32.band(bit32.rshift(attrs,9), 1) ~= 1 then
									errorMsg = ErrorObject.new(ErrorCodes.PASSWORD_REQUIRES_SPECIAL_CHAR, nil, { field = "newPassword" })
								end
							end
						end
					end
				end
			end
		end
		if not cursor:close() then
			trace('UNABLE_TO_CLOSE_CURSOR')
		end
		if not connectionSupplied then
			if not connection:close() then
				trace('UNABLE_TO_CLOSE_CONNECTION')
			end
			if not env:close() then
				trace('UNABLE_TO_CLOSE_ENV')
			end
		end
	end
	if not errorMsg then
		result = true
	end
	return result, errorMsg
end

function User.checkPreviousPasswords(connection, user, pw, num)
	local result = true
	local cursor = connection:prepare([[
		SELECT password_history
		FROM user
		WHERE username == (?)
	]])
	cursor:bind{
		{'TEXT', user}
	}
	local exec = cursor:execute()
	if exec then
		local history, total = {}, 1
		cursor:fetch(history, 'a')
		if type(history.password_history) == 'string' then
			history = ba.json.decode(history.password_history)
		end

		if type(history) == 'table' then
			--Don't go out of bounds on the array...
			if #history >= num then
				total = num
			else
				total = #history
			end
			for i=1, total do
				if history[i] == pw then
					result = false
					break
				end
			end
		end
	end
	if not cursor:close() then
		trace('UNABLE_TO_CLOSE_CURSOR')
	end
	return result
end

function User.create(userdata)

	if User.totalUsers == 10 then
		return nil, ErrorCodes.MAX_NUM_USERS_REACHED
	end

    local result = false
    local errorMsg = nil
	-- Grab a reference to SQLite environment
	local env = luasql.sqlite()

	-- Connect to the database with write permissions
	local connection = env:connect(Constants.DB_PATH)

	-- Establish how long to wait for the write lock on the database and acquire the lock.
	local isLockAcquired = connection:setautocommit('IMMEDIATE', 1000)

	if isLockAcquired then

		local userNameInUse = true
		--Avoid XSS
        userdata.username = gf.htmlspecialchars(userdata.username)
		userNameInUse, errorMsg = User.exists(connection, userdata.username)
		if userNameInUse then
			errorMsg = ErrorObject.new(ErrorCodes.USER_EXISTS, nil, { field = "username" })
		elseif not userNameInUse and not errorMsg then
			local pwValResult = false
			pwValResult, errorMsg = User.validatePasswordBasedOnSecuritySettings(userdata.username, userdata, connection, true) --"true" tells new user not to check last passwords if that security is enabled
			if pwValResult then

				-- Force write permission if user is an administrator
				if userdata.isAdmin == 1 then userdata.hasWritePermission = 1 end

				local cursor =
					connection:prepare(
						[[INSERT INTO user(
							username,
							password,
							has_write_permission,
							is_locked,
							default_language,
							num_failed_login_attempts,
							is_admin,
							password_strength,
							remind_to_change_password,
							password_history
						)
						VALUES(
							( ? ),
							( ? ),
							( ? ),
							( ? ),
							( ? ),
							( ? ),
							( ? ),
							( ? ),
							( ? ),
							( ? )
						)]])
				-- Bind username to the prepared statement
				cursor:bind{
					{'TEXT', userdata.username},
					{'TEXT', userdata.newPassword},
					{'INTEGER', userdata.hasWritePermission},
					{'INTEGER', 0},
					{'INTEGER', 0},
					{'INTEGER', 0},
					{'INTEGER', userdata.isAdmin},
					{'INTEGER', userdata.entropy},
					{'INTEGER', 1},
					{'TEXT', ba.json.encode({userdata.newPassword})}
				}
				-- Execute query
				local exec = cursor:execute()
				if not exec then
					errorMsg = ErrorCodes.CREATE_USER_FAILED

					--if not connection:rollback() then
					--	trace('ROLLBACK FAILED')
					--end
				else
					cursor = connection:prepare([[
						INSERT INTO dashboard(username,columns)
						VALUES (( ? ),"[]")
					]])
					cursor:bind{
						{'TEXT', userdata.username}
					}
					exec = cursor:execute()
					if not exec then
						errorMsg = ErrorCodes.CREATE_USER_FAILED
					else
						-- Commit the transaction
						if connection:commit() then
							result = '{"success": true}'
							User.totalUsers = User.totalUsers + 1
						else
							errorMsg = ErrorCodes.COMMIT_FAIL
						end
					end
				end
				-- Close cursor connection to database
				if not cursor:close() then
					trace('FAILED TO CLOSE CURSOR')
				end
			end
		end
	else
		errorMsg = ErrorCodes.LOCK_FAIL
	end

	-- Close connection to database
	if not connection:close() then
		trace('FAILED TO CLOSE SQLITE CONNECTION')
	end
	-- Close connection to SQLite
	if not env:close() then
		trace('FAILED TO CLOSE SQLITE ENVIRONMENT')
	end

    return result, errorMsg
end
function User.update(userdata)
    local result = false
	local errorMsg = nil
	-- Grab a reference to SQLite environment
	local env = luasql.sqlite()

	-- Connect to the database with write permissions
	local connection = env:connect(Constants.DB_PATH)

	-- Establish how long to wait for the write lock on the database and acquire the lock.
	local isLockAcquired = connection:setautocommit('IMMEDIATE', 1000)

	-- Delete the page if the lock has been acquired
	if isLockAcquired then
		local userExists = false
		userExists, errorMsg = User.exists(connection, userdata.username)
		if userExists then

			-- Force write permission if user is an administrator
			if userdata.isAdmin == 1 then userdata.hasWritePermission = 1 end

			local cursor

			if userdata.username ~= "admin" then
				cursor = connection:prepare([[
					UPDATE user SET
						is_admin = ( ? ),
						has_write_permission = ( ? ),
						is_locked = ( ? )
					WHERE username NOT NULL and username == ( ? )
				]])
				-- Bind username to the prepared statement
				cursor:bind{
					{'INTEGER', userdata.isAdmin},
					{'INTEGER', userdata.hasWritePermission},
					{'INTEGER', userdata.isLocked},
					{'TEXT', userdata.username}
				}
			end
			-- Execute query
			local exec = cursor:execute()
			if not exec then
				errorMsg = ErrorCodes.USER_UPDATE_FAILED

				--if not connection:rollback() then
				--	trace('ROLLBACK FAILED')
				--end
			else
				-- Commit the transaction
				if connection:commit() then
					result = true
				else
					errorMsg = ErrorCodes.COMMIT_FAIL
				end
			end
			-- Close cursor connection to database
			if not cursor:close() then
				trace('FAILED TO CLOSE CURSOR')
			end
		elseif not userExists and not errorMsg then
			errorMsg = ErrorCodes.USER_DOES_NOT_EXIST
		end
	else
		errorMsg = ErrorCodes.LOCK_FAIL
	end

	-- Close connection to database
	if not connection:close() then
		trace('FAILED TO CLOSE SQLITE CONNECTION')
	end
	-- Close connection to SQLite
	if not env:close() then
		trace('FAILED TO CLOSE SQLITE ENVIRONMENT')
	end

    return result, errorMsg
end
function User.get(username)
    local env = luasql.sqlite()
    local connection = env:connect(Constants.DB_PATH, "READONLY")
    local cursor, errorMsg = nil
	local result = {}
	local user = {}

    if username ~= nil and username:len() > 0 then
        -- Build Prepared Statement
        cursor =
			connection:prepare(
				[[SELECT * FROM user
				WHERE user.username = ( ? )]])
        -- Bind username to the prepared statement
        cursor:bind{{'TEXT', username}}
    else
       cursor = connection:prepare([[SELECT * FROM user]])
    end
    local exec = cursor:execute()
	if exec then
		-- Grab results in a table
		cursor:fetch(user, 'a')

		local activeUsers = ba.users()
		-- While user is not nil and is not an empty table
		while (user and next(user)) do
			local obj = {
				id = user.username,
				username = user.username,
				isAdmin = tonumber(user.is_admin),
				lastLogin = user.last_logged_in,
				failedLoginAttempts = tonumber(user.num_failed_login_attempts),
				hasWritePermission = tonumber(user.has_write_permission),
				isLocked = tonumber(user.is_locked),
				language = tonumber(user.default_language),
				pwStrength = tonumber(user.password_strength),
				isOnline = gf.contains(activeUsers, user.username)
			}
			table.insert(result,obj)
			-- Grab results in a table
			user = cursor:fetch(user, 'a')
		end

		if #result > 1 then User.totalUsers = #result end

	else
		result = false
		errorMsg = ErrorCodes.GET_USERS_FAILED
	end
    -- Clean up
    if not cursor:close() then
        trace('FAILED TO CLOSE CURSOR')
    end

    if not connection:close() then
        trace('FAILED TO CLOSE SQLITE CONNECTION')
    end

    if not env:close() then
        trace('FAILED TO CLOSE SQLITE ENVIRONMENT')
    end

    return result, errorMsg
end

function User.delete(username)
    local result = false
	local errorMsg = nil
	if username ~= "admin" then
		-- Grab a references to the SQLite environment
		local env = luasql.sqlite()
		-- Connect to the database with write permissions
		local connection = env:connect(Constants.DB_PATH)
		-- Establish how long to wait for the write lock on the database and acquire the lock
		local isLockAcquired = connection:setautocommit('IMMEDIATE', 1000)
		-- Delete the page if the lock has been acquired
		if isLockAcquired then
			local userExists = false
			userExists, errorMsg = User.exists(connection, username)
			-- If the user does exist then delete it
			if userExists then
				-- Prepare the query
				local cursor =
					connection:prepare([[DELETE FROM user WHERE user.username = ( ? )]])
				-- Bind username to the prepared statement
				cursor:bind{{'TEXT', username}}
				-- Execute query
				local exec = cursor:execute()

				if not exec then
					errorMsg = ErrorCodes.DELETE_USER_FAILED

					--if not connection:rollback() then
					--	trace('ROLLBACK FAILED')
					--end
				else
					cursor = connection:prepare([[
						DELETE FROM dashboard WHERE username = ( ? )
					]])
					cursor:bind{
						{'TEXT', username}
					}
					exec = cursor:execute()
					if not exec then
						errorMsg = ErrorCodes.DELETE_USER_FAILED
					else
						-- Commit the transaction
						if connection:commit() then
							result = true
						else
							errorMsg = ErrorCodes.COMMIT_FAIL
						end

						if User.totalUsers > 0 then
							User.totalUsers = User.totalUsers - 1
						end

					end
				end
				-- Close cursor connection to database
				if not cursor:close() then
					trace('FAILED TO CLOSE CURSOR')
				end
			elseif not userExists and not errorMsg then
				errorMsg = ErrorCodes.USER_DOES_NOT_EXIST
			end
		else
			errorMsg = ErrorCodes.LOCK_FAIL
		end

		-- Close connection to database
		if not connection:close() then
			trace('FAILED TO CLOSE SQLITE CONNECTION')
		end
		-- Close connection to SQLite
		if not env:close() then
			trace('FAILED TO CLOSE SQLITE ENVIRONMENT')
		end
	else
		errorMsg = ErrorCodes.CANNOT_DELETE_ADMIN
	end

    return result, errorMsg
end
-- Returns true is 1 or if isReminded is null.
-- Otherwise, returns false
function User.isRemindedToChangePassword(username)
	local env = luasql.sqlite()
    local connection = env:connect(Constants.DB_PATH, "READONLY")
    local cursor, errorMsg = nil
	local result = {}

    if type(username) == "string" and username:len() > 0 then

        -- Build Prepare Statement
        cursor =
			connection:prepare(
				[[SELECT remind_to_change_password FROM user
				WHERE user.username = ( ? )]])

        -- Bind username to the prepared statement
        cursor:bind{{'TEXT', username}}
    else
       return false, ErrorCodes.USERNAME_MUST_BE_PROVIDED
    end

    local exec = cursor:execute()
	if exec then
		local response = {}

		-- Grab results in a table
		cursor:fetch(response, 'a')
		isReminded = response.remind_to_change_password

		if isReminded == "1" then
			result = true
		elseif isReminded == "0" then
			result = false
		else
			-- TODO: Not sure what should happen in this case
			-- Ensure that if something goes wrong that they are forced to change there password?
			result = true
		end
	else
		result = true
		errorMsg = ErrorCodes.FAILED_TO_EXECUTE_SQL_QUERY
	end

    -- Clean up
    if not cursor:close() then
        trace('FAILED TO CLOSE CURSOR')
    end

    if not connection:close() then
        trace('FAILED TO CLOSE SQLITE CONNECTION')
    end

    if not env:close() then
        trace('FAILED TO CLOSE SQLITE ENVIRONMENT')
    end

    return result, errorMsg
end
function User.changePassword(username, userdata, remindToChangePass)
    local result = false
    local errorMsg = nil
    local password = userdata.newPassword
    local pwValResult = false

    pwValResult, errorMsg = User.validatePasswordBasedOnSecuritySettings(username, userdata)

    if pwValResult then
		-- Grab a reference to SQLite environment
		local env = luasql.sqlite()
		-- Connect to the database with write permissions
		local connection = env:connect(Constants.DB_PATH)
		-- Establish how long to wait for the write lock on the database and acquire the lock.
		local isLockAcquired = connection:setautocommit('IMMEDIATE', 1000)
		-- Attempt to change user password
		if isLockAcquired then
			-- Verify that the user even exists
			local userExists, errorMsg = User.exists(connection, username)
			-- If the user exists then change it's password
			if userExists then
				local history = User.addPasswordToHistoryArray(username, password, connection)
				if history then
					-- If the password change request comes from the user management page, the user
					-- should be required to change their password before gaining access to the site.
					-- remindToChangePass added to accomplish this task.
					local cursor =
						connection:prepare([[
							UPDATE user
							SET password = ( ? ),
								password_strength = ( ? ),
								remind_to_change_password = ( ? ),
								password_history = ( ? )
							WHERE username = ( ? )
						]])
					cursor:bind{
						{'TEXT', password},
						{'INTEGER', userdata.entropy},
						{'INTEGER', remindToChangePass},
						{'TEXT', history},
						{'TEXT', username}
					}
					-- Execute query
					local exec = cursor:execute()

					if not exec then
						errorMsg = ErrorCodes.PASSWORD_CHANGE_FAILED

						--if not connection:rollback() then
						--	trace('ROLLBACK FAILED')
						--end
					else
						-- Commit the transaction
						if connection:commit() then
							result = true
						else
							errorMsg = ErrorCodes.COMMIT_FAIL
						end
					end
					-- Close cursor connection to database
					if not cursor:close() then
						trace('FAILED TO CLOSE CURSOR')
					end
				else
					errorMsg = ErrorCodes.HISTORY_UPDATE_FAILED
				end
			elseif not userExists and not errorMsg then
				errorMsg = ErrorCodes.USER_DOES_NOT_EXIST
			end
		else
			errorMsg = ErrorCodes.LOCK_FAIL
		end

		-- Close connection to database
		if not connection:close() then
			trace('FAILED TO CLOSE SQLITE CONNECTION')
		end
		-- Close connection to SQLite
		if not env:close() then
			trace('FAILED TO CLOSE SQLITE ENVIRONMENT')
		end
	end
    return result, errorMsg
end
--@func changeLanguage
--@desc Function used to change the user's default language
--@param username [string] The current user's name
--@param language [integer] The language to make the default for the specified user
function User.changeLanguage(username, language)
    local result = false
    local errorMsg = nil
    -- A language must be provided otherwise an error is returned
    if not language then
        errorMsg = ErrorCodes.LANGUAGE_REQUIRED
        return result, errorMsg
    end
	-- Grab a reference to SQLite environment
	local env = luasql.sqlite()
	-- Connect to the database with write permissions
	local connection = env:connect(Constants.DB_PATH)
	-- Establish how long to wait for the write lock on the database and acquire the lock.
	local isLockAcquired,lockError=connection:setautocommit(false)
	-- Delete the page if the lock has been acquired
	if isLockAcquired then
		 -- Verify that the user even exists
		local userExists, errorMsg = User.exists(connection, username)

		-- If the user exists then change it's language
		if userExists then
			-- Prepare the query
			local cursor =
				connection:prepare([[
					UPDATE user
					SET default_language = ( ? )
					WHERE username = ( ? )
				]])
			-- Bind username to the prepared statement
			cursor:bind{{'INTEGER', tonumber(language)}, {'TEXT', username}}
			-- Execute query
			local exec = cursor:execute()

			if not exec then
				errorMsg = ErrorCodes.LANGUAGE_ERROR

				--if not connection:rollback() then
				--	trace('ROLLBACK FAILED')
				--end
			else
				-- Commit the transaction
				if connection:commit() then
					result = true
				else
					errorMsg = ErrorCodes.COMMIT_FAIL
				end
			end
			-- Close cursor connection to database
			if not cursor:close() then
				trace('FAILED TO CLOSE CURSOR')
			end
		elseif not userExists and not errorMsg then
			errorMsg = ErrorCodes.USER_DOES_NOT_EXIST
		end
	else
		errorMsg = ErrorCodes.LOCK_FAIL
	end

	-- Close connection to database
	if not connection:close() then
		trace('FAILED TO CLOSE SQLITE CONNECTION')
	end
	-- Close connection to SQLite
	if not env:close() then
		trace('FAILED TO CLOSE SQLITE ENVIRONMENT')
	end

    return result, errorMsg
end
-- @func exists
-- @desc Detects whether a user exists with a specific username
-- @param username [String] The username that you wish to see if a user already exists for
function User.exists(connection, username)
	local result = false
	local errorMsg = nil
    -- Prepare query to identify whether the user exists or not
    local cursor =
		connection:prepare([[SELECT count(*) FROM user WHERE user.username = ( ? )]])

	if cursor then
		-- Bind username to the prepared statement
		cursor:bind{{'TEXT', username}}
		-- Execute query
		local exec = cursor:execute()
		if exec then
			local queryResult = {}
			cursor:fetch(queryResult)

			local numberOfUsersWithUserName = queryResult[1]
			result = tonumber(numberOfUsersWithUserName) > 0
		else
			errorMsg = ErrorCodes.DATABASE_ERROR
		end
		-- Clean up database connections
		if not cursor:close() then
			trace('FAILED TO CLOSE CURSOR')
		end
	else
		errorMsg = ErrorCodes.INVALID_SQL_SYNTAX
	end

	return result, errorMsg
end

function User.addPasswordToHistoryArray(user, pw, connection)
	local result = false
	local cursor = connection:prepare([[
		SELECT password_history
		FROM user
		WHERE username == (?)
	]])
	cursor:bind{{'TEXT', user}}
	local exec = cursor:execute()
	if exec then
		local history, total = {}, 1
		cursor:fetch(history, 'a')
		if type(history.password_history) == 'string' then
			history = ba.json.decode(history.password_history)
		end
		table.insert(history, 1, pw)
		-- Drop the 6th element - only store up to 5 passwords
		if #history > 5 then
			table.remove(history, 6)
		end

		result = ba.json.encode(history)
	end
	if not cursor:close() then
		trace('Unable to close cursor')
	end
	return result
end

-- function User.resetAllChangePasswordFlags(connection)
-- 	local result = false
-- 	local cursor = connection:prepare([[
-- 		UPDATE user
-- 		SET remind_to_change_password = 1
-- 	]])
-- 	local exec = cursor:execute()
-- 	if exec then
-- 		if connection:commit() then
-- 			result = true
-- 		end
-- 	end
-- 	if not cursor:close() then
-- 		trace('Unable to close cursor')
-- 	end
-- 	return result
-- end

-- function User.resetAllPasswordHistories(connection)
-- 	local result = false
-- 	local cursor = connection:prepare([[
-- 		UPDATE user
-- 		SET password_history = "[]"
-- 	]])
-- 	local exec = cursor:execute()
-- 	if exec then
-- 		if connection:commit() then
-- 			result = true
-- 		end
-- 	end
-- 	if not cursor:close() then
-- 		trace('Unable to close cursor')
-- 	end
-- 	return result
-- end

-- Remove all the users from the database without admin account
function User.removeAllUsers()
	local result = false
 	local cursor = connection:prepare([[
 		DELETE FROM user
 		WHERE username="admin"
 	]])
 	local exec = cursor:execute()
 	if exec then
 		if connection:commit() then
 			result = true
 		end
 	end
 	if not cursor:close() then
 		trace('Unable to close cursor')
 	end
 	return result
end

return User