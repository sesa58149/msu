local Security = {}
function Security.logout(_ENV, path)
    request:logout()
    -- Sets content type to "text/html" and sets the header "Cache-Control" to "No-Cache"
    response:setdefaultheaders()
    -- 301 Permanent redirect message
    response:sendredirect("/", true)
end
function Security.isBrowser(_ENV, ai)
   if not ai or not ai.username then
      local ua = request:header"User-Agent"
      if ua and (ua:find("Mozilla",1,true) or
                 ua:find("Opera",1,true)) then
         return true
      end
      return false
   end
   return true
end
function Security.getSessionTimeout()
    local env, errorMsg, connection, result = nil, nil, nil, nil
    env, errorMsg = luasql.sqlite()
    if env then
        local connection, errorMsg = env:connect(Constants.DB_PATH, 'READONLY')
        if connection then
            local cursor = connection:prepare([[
                SELECT attr_value
                FROM config_attributes
                WHERE attr_key="sessionTimeout"
            ]])
            local row = nil

            if cursor then
                cursor:execute()
                row = cursor:fetch()
                -- Clean up
                if not cursor:close() then
                    trace('FAILED TO CLOSE CURSOR')
                end
                if row then
                    result = row
                else
                    result = nil
                end
            end

            if not connection:close() then
                trace('FAILED TO CLOSE SQLITE CONNECTION')
            end
        end
        if not env:close() then
            trace('FAILED TO CLOSE SQLITE ENVIRONMENT')
        end
    end

    return result, errorMsg
end
function Security.handleRemindPassword(_ENV, relpath)
    local s = request:session()
    -- Is there an active session?
    if s then
        local username, authType = s:user()
        if type(username) == "string" then
            if User.isRemindedToChangePassword(username) then
                -- The user should be reminded
                if relpath ~= 'platform/changeDefaultPassword.lsp' then
                    -- If there isn't a cookie and the relpath isn't changeDefaultPassword.lsp then redirect to that page
                    response:sendredirect('/platform/changeDefaultPassword.lsp')
                    return true
                else
                    -- The path is either already changeDefaultPassword.lsp or is something else and the cookie is there
                    return false
                end
            else
                return false
            end
        else
            return false
        end
    else
        -- If there is not session security will automatically take the browser to the login page
        return false
    end
end
-- Increments the failed login count for a specific user in the database if a username is provided when authenticating
function Security.incrementFailLoginCounter(_ENV, ai)
    if ai.username then
        --Increase the failed login counter and set a lock on the account after 5 tries
        local env, errorMsg, connection = nil,nil,nil
        env, errorMsg = luasql.sqlite()

        if env then
            connection, errorMsg = env:connect(Constants.DB_PATH)
            if connection then
                -- Build Prepared Statement
                local cursor = connection:prepare(
                    [[  UPDATE user
                        SET num_failed_login_attempts = num_failed_login_attempts + 1 , is_locked = CASE
                            WHEN num_failed_login_attempts <= 5 AND is_locked == 0
                                THEN 0
                            ELSE 1
                        END
                        WHERE username = ( ? ) AND username != "admin"
                    ]]
                )
                if cursor then
                    -- Bind user data
                    cursor:bind{{"TEXT",ai.username}}
                    -- Execute the request
                    local queryResult = cursor:execute()

                    -- We don't know if the user even exists but we do expect a number here
                    if type(queryResult) ~= 'number' then
                        trace('Unexpected Query Result')
                    end

                    -- Close the cursor
                    if not cursor:close() then
                        trace('FAILED TO CLOSE CURSOR')
                    end
                else
                    -- No cursor
                    trace('Unable to perform query.')
                end
                if not connection:close() then
                    trace('FAILED TO CLOSE SQLITE CONNECTION')
                end
            else
                -- No connection
                trace('Unable to connect to database.')
            end
            if not env:close() then
                trace('FAILED TO CLOSE SQLITE ENVIRONMENT')
            end
        else
            -- No SQL Environment
            trace('Unable to get SQL Environment.')
        end
    end
end
function Security.loginResponse(_ENV, ai)
    --[[
        -- Successful response --
        {
            "denied":false,
            "loginattempts":0,
            "seed":"{long}",
            "seedkey":"{long}",
            "type":"form"
        }

        -- Failed response
        {
            "inactive":0,
            "seed":"{long}",
            "maxusers":3 or 999, //Users that don't exist have this value set at 3
            "password":"",
            "denied":false,
            "seedkey":"{long}",
            "type":"form",
            "recycle":false,
            "username":"{user}",
            "loginattempts":0
        }
    ]]--
    if response:committed() then return end

    -- Identify what went wrong and store the message
    local msg = "Unknown error"

    if ai.denied then
        msg="YOU HAVE BEEN BANNED!"
    elseif ai.maxusers and ai.maxusers < 1 then
        msg = ai.maxusers == 0 and
        "The administrator has disabled your account" or
        "You are logged in using too many clients"
    else
        msg = "Incorrect credentials"
    end
    
    response:setdefaultheaders()

    Security.incrementFailLoginCounter(_ENV, ai)

    if Security.isBrowser(_ENV, ai) then
        local uri = request:uri()
        local statusCode = nil
        local errorCode = 0

        if uri and uri:len() == 1 then
            if ai.username and ai.username:len() > 0 then
                if (ai.denied) or (ai.maxusers and ai.maxusers < 1) then
                    errorCode = 2 -- Account Locked
                else
                    errorCode = 1 -- Invalid credentials
                end
            elseif ai.username and ai.username:len() == 0 then
                -- An empty user name has been provided
                errorCode = 1 -- Invalid credentials
            end
        end

        -- Set the HTTP status code
        response:setstatus(401)

        -- Check if it is an AJAX request
         local x=request:header"x-requested-with"

         if type(x) == 'string' and string.lower(x) == "xmlhttprequest" then
            -- Report the error to the AJAX call. DO NOT REDIRECT.
            response:json({err="login",emsg=msg}) -- Exit Point
            -- EXIT POINT
         end

        -- Set authinfo in the global command environment
        authinfo=ai
        authinfo.ba_salt = _G.salt

        if errorCode == 1 then
            response:setheader("Error", "1")
        elseif errorCode == 2 then
            response:setheader("Error", "2")
        end

        response:forward("login.lsp", true)
        -- EXIT POINT
    else
        -- Silverlight cannot read when it is a 4XX error
        response:setstatus(200)

        if username then
            response:write('{"errorMsg":"' .. msg .. '", "ba_seed":' .. ai.seed .. ', "ba_seedkey":' .. ai.seedkey .. ', "ba_salt":"' .. _G.salt .. '"}')
        else
            response:write('{"ba_seed":' .. ai.seed .. ', "ba_seedkey":' .. ai.seedkey .. ', "ba_salt":"' .. _G.salt .. '"}')
        end

        response:flush()
        response:abort()
        -- EXIT POINT
    end
end
function Security.getCreateSalt()
    local env, errorMsg, connection, result = nil, nil, nil, nil
    env, errorMsg = luasql.sqlite()
    if env then
        local connection, errorMsg = env:connect(Constants.DB_PATH, 'READONLY')
        if connection then
            local cursor = connection:prepare([[
                SELECT attr_value
                FROM config_attributes
                WHERE attr_key="salt"
            ]])
            local row = nil
            if cursor then
                cursor:execute()
                row = cursor:fetch()
                -- Clean up
                if not cursor:close() then
                    trace('FAILED TO CLOSE CURSOR')
                end
                if row then
                    result = row
                else
                    -- Generate a new salt and store it in the database
                    result = Security.createSalt()
                end
            end

            if not connection:close() then
                trace('FAILED TO CLOSE SQLITE CONNECTION')
            end
        end
        if not env:close() then
            trace('FAILED TO CLOSE SQLITE ENVIRONMENT')
        end
    end

    return result, errorMsg
end
function Security.generateSalt()
    local salt = ''
    local errMsg = nil

    for i=0, 31 do
        -- 48 through 122
        salt = salt .. string.char(math.ceil(97 + (math.random() * ((122 - 97)))))
    end

    return salt
end
function Security.createSalt()
    local salt = Security.generateSalt()
    local env, connection, errMsg = nil,nil,nil
    -- Grab sqlite environment
    env, errMsg = luasql.sqlite()
    -- Ensure we have the environment
    if env then
        connection = env:connect(Constants.DB_PATH)
        -- Ensure we have the connection
        if connection then
            -- Build Prepared Statement
            local cursor = connection:prepare([[
                INSERT INTO config_attributes (attr_key, attr_value)
                VALUES(
                    "salt",
                    ?
                    )
            ]])
            -- Ensure we get a cursor from the prepare
            if cursor then
                cursor:bind{{"TEXT", salt}}
                local numRowsAffected = cursor:execute()
                -- Ensure numRowsAffected is expected type
                if type(numRowsAffected) == 'number' then
                    if numRowsAffected < 1 then
                        salt, errMsg = nil, "Unable to create security salt."
                    elseif numRowsAffected > 1 then
                        salt, errMsg = nil, "Unexpected Exception: To many rows affected. Database is possible compromised."
                    end
                    -- Fall through if the numRowsAffected is 1
                else
                    --Unexpected type
                    salt, err = nil, "Unexpected Exception: Unexpected type for query result."
                end
                if not cursor:close() then
                    trace('FAILED TO CLOSE CURSOR')
                end
            else
                -- No Cursor
                salt, err = nil, "Unexpected Exception: Prepare failed."
            end
            if not connection:close() then
                trace('FAILED TO CLOSE SQLITE CONNECTION')
            end
        else
            -- Unable to connect to database
            salt, errMsg = nil, 'Unexpected Exception: Unable to connect to SQLite database. "env:connect" returned nil'
        end
        if not env:close() then
            trace('FAILED TO CLOSE SQLITE ENVIRONMENT')
        end
    else
        -- Unable to get SQL environment
        salt, err = nil, "Unexpected Exception: Unable to get SQL environment"
    end

    -- Return the results
    return salt, errMsg
end
function Security.getPassword(username, _ENV)
    if ( _G.allowSession ~= nil and not _G.allowSession) then 
        return nil, "WebSite update is pending"
    end

    local env, cursor, connection, errorMsg, result = nil, nil, nil, nil, nil
    env, errorMsg = luasql.sqlite()
    if env then
        connection, errorMsg = env:connect(Constants.DB_PATH, 'READONLY')
        if connection then
            -- Build Prepared Statement
            cursor, errorMsg = connection:prepare([[
                SELECT COUNT(*), password
                FROM user
                WHERE username=? AND is_locked=0
            ]])
            if cursor then
                -- Bind user data
                cursor:bind{{"TEXT",username}}

                -- Execute the request
                cursor:execute()

                -- Numerical Indices
                local row = cursor:fetch({}, "n")

                -- Make sure there is only a single row
                if (row[1] == "1") then
                    -- return the password as the result
                    result = row[2]
                end

                -- If the password is empty then prevent login
                if result == "" then result = nil end

                if not cursor:close() then
                    trace('FAILED TO CLOSE CURSOR')
                end
                if not connection:close() then
                    trace('FAILED TO CLOSE SQLITE CONNECTION')
                end
                if not env:close() then
                    trace('FAILED TO CLOSE SQLITE ENVIRONMENT')
                end

                return result, 999 -- Returning nil tells the authentication system that the user was not found.
            else
                -- Couldn't get cursor
                if not connection:close() then
                    trace('FAILED TO CLOSE SQLITE CONNECTION')
                end
                if not env:close() then
                    trace('FAILED TO CLOSE SQLITE ENVIRONMENT')
                end
                return nil, errorMsg
            end
        else
            if not env:close() then
                trace('FAILED TO CLOSE SQLITE ENVIRONMENT')
            end
            -- Couldn't get connection
            return nil, errorMsg
        end
    else
        -- Couldn't get environment
        return nil, errorMsg
    end
end

function Security.authorization(username, method, relpath)
    return true
end

return Security