local Variable = {}

function Variable.getVariableValues(variables)
    local errorMsg = nil

    local result = {}
    local addresses = {}
    local mVariables = {}

    if ParametersTable ~= nil then
        for i,v in pairs(variables) do
            local mAddress = ParametersTable['parameterlist'][v.mnemonic]
            if(mAddress and mAddress:len() > 0) then
                mAddress = tonumber(mAddress)
                table.insert( addresses, mAddress )
                table.insert( mVariables, v.mnemonic ) --so, we know which value is for which mnemonic...
            end
        end
    end


    --After building the array of addresses above, make a call to adl.ReadParamsNonCons(....)
    if #addresses > 0 then
        local response, errorMsg = ReadParamsNonCons.fetch(248, addresses)

        if response then
            for i=1, #response do
                local tmpTbl = {
                    id = mVariables[i],
                    mnemonic = mVariables[i],
                    address = response[i].address,
                    value = response[i].value,
                    type = response[i].type
                }
                table.insert(result, tmpTbl)
            end
        end
    end
    
    return result, errorMsg
end

-- Use WriteParamsNonCons to update the values of several mnemonics...
-- NOT TESTED
function Variable.updateVariableValues(variables)

    local result, errMsg = {}, nil
    local addresses = {}
    local mVariables = {}

    if ParametersTable ~= nil then
        for i,v in pairs(variables) do
            local mAddress = ParametersTable['parameterlist'][v.mnemonic]
            if(mAddress and mAddress:len() > 0) then
                mAddress = tonumber(mAddress:sub(4)) --can address be longer than 4?
                table.insert(newValues, {address = mAddress, value = v.value} )
            end
        end

        if adlClient then
            adlClient.WriteParamsNonCons(newValues)
            result['response'] = 'SUCCESS'
        else
            result['response'] = 'ADL_CLIENT_NOT_SUPPORTED'
        end
    end

    return result, errMsg

end

-- Return all available variables available to user
-- This is for when they create a table or chart so they can choose which variables will be in the chart
function Variable.get()
    local result, errorMsg = nil, nil
    if ParametersTable ~= nil and ParametersTable.parameterlist ~= nil and ParametersTable.listparam ~= nil and ParametersTable.listdef ~= nil then
        result = {}
        for mnemonic, address in pairs(ParametersTable.parameterlist) do
            local variable = {
                id = mnemonic,
                address = address,
                mnemonic = mnemonic,
                options = ParametersTable.listdef[ParametersTable.listparam[mnemonic]]
            }
            table.insert(result, variable)
        end
    end
    return result, errorMsg
end

function Variable.getSelectedVariables(lists)
    local result, errorMsg = nil, nil
    if ParametersTable ~= nil and ParametersTable.parameterlist ~= nil and ParametersTable.listparam ~= nil and ParametersTable.listdef ~= nil then
        result = {}
        for i = 1, #lists do
            local listId = ParametersTable.listparam[lists[i]];
             local variable = {
                id = lists[i],
                address = ParametersTable.parameterlist[lists[i]],
                mnemonic = lists[i],
                options = ParametersTable.listdef[listId]
            }
            table.insert(result, variable)
        end
    end
    return result, errorMsg
end

function Variable.getMonitVariables()
    local result, errorMsg = nil, nil
    if ParametersTable ~= nil and ParametersTable.monitoringlist ~= nil and ParametersTable.listparam ~= nil and ParametersTable.listdef ~= nil then
        result = {}
        for id, mnemonic in pairs(ParametersTable.monitoringlist) do
            local variable = {
                id = mnemonic,
                address = ParametersTable.parameterlist[mnemonic],
                mnemonic = mnemonic,
                options = ParametersTable.listdef[ParametersTable.listparam[mnemonic]]
            }
            table.insert(result, variable)
        end
    end
    return result, errorMsg
end
function Variable.getSetupVariables()
    local result, errorMsg = nil, nil
    if ParametersTable ~= nil and ParametersTable.configurationlist ~= nil and ParametersTable.listparam ~= nil and ParametersTable.listdef ~= nil then
        result = {}
        for id, mnemonic in pairs(ParametersTable.configurationlist) do
            local variable = {
                id = mnemonic,
                address = ParametersTable.parameterlist[mnemonic],
                mnemonic = mnemonic,
                options = ParametersTable.listdef[ParametersTable.listparam[mnemonic]]
            }
            table.insert(result, variable)
        end
    end
    return result, errorMsg
end
function Variable.variablesExist(connection, variables)
    local result = false
    local errorMsg = nil
    
    --To Do: check JSON file to see if this variable exists...
    return variables, errorMsg
end

return Variable