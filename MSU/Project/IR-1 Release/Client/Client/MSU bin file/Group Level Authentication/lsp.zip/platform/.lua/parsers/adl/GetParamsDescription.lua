local GetParamsDescription = {}

-- Send the modbus request and parse the result
function GetParamsDescription.fetch(unitID, addresses)
    if type(unitID) ~= 'number' then
        return nil, ErrorObject.new(ErrorCodes.INVALID_DATATYPE,'"unitID" is not the correct type in GetParamsDescription.fetch. Number expected.')
    end
    if type(addresses) ~= 'table' then
        return nil, ErrorObject.new(ErrorCodes.INVALID_DATATYPE,'"addresses" is not the correct type in GetParamsDescription.fetch. Table expected.')
    end

    -- TODO: Need to check the types of all the data in the table.
    --       If strings make it to the LuaWrapper things break.

    local data, errMsg = {}, nil
    if LuaADL and not _G.forceSimulation then
        local mT = {}
        local x = 0
        local count = 1
        for i, v in pairs(addresses) do
            if x < 0 then
                table.insert(mT, v)
                x = x + 1
            else
                table.insert(mT, v)
                mData, errMsg = LuaADL.GetParamsDescription(unitID, #mT, mT)
                collectgarbage("collect")
                if mData then
                    for i=1, #mData do
                        mData[i][2] = addresses[count]
                        table.insert(data, mData[i])
                        count = count + 1
                    end
                else
                    -- COM error
                    return nil, ErrorObject.new(ErrorCodes.ADL_READ_FAILED, errMsg, nil, HTTPStatusCode.InternalServerError) --errMsg
                end

                mT = nil
                mT = {}
                x = 0
            end
        end
        if #mT > 0 then
            mData, errMsg = LuaADL.GetParamsDescription(unitID, #mT, mT)
            collectgarbage("collect")

            if mData then
                for i=1, #mData do
                    mData[i][2] = addresses[count]
                    table.insert(data, mData[i])
                    count = count + 1
                end
            else
                return nil, ErrorObject.new(ErrorCodes.ADL_READ_FAILED,  errMsg, nil, HTTPStatusCode.InternalServerError) --errMsg
            end
        end
    else
        data, errMsg = GetParamsDescription.generateSimulationData(addresses), nil
    end
    if errMsg ~= nil then
        return nil, errMsg
    elseif #data == 0 then
        return nil, ErrorObject.new(ErrorCodes.INVALID_RESPONSE_FROM_SERVER)
    end
    return GetParamsDescription.parse(data)
end

-- Parse the result
function GetParamsDescription.parse(data)
    if type(data) ~= 'table' then
        return nil, ErrorObject.new(ErrorCodes.INVALID_DATATYPE ,'"data" invalid type in GetParamsDescription.parse. Expected Table')
    end

    local result, errMsg = {}, nil

    for i=1, #data do

        local variable = data[i]
        local dataType = nil
        local dataLen = #variable
        if dataLen > 1 then
            result[i] = {
                status  = variable[1],
                address = variable[2]
            }

            if result[i].status == 0 and dataLen >= 9 then
                -- Good status and meets the minimum length requirements
                result[i].mnemonic = variable[3]
                result[i].type = variable[4]
                result[i].signed = variable[5]
                result[i].visible = variable[6]
                result[i].mutable = variable[7]
                -- Store type
                dataType = variable[4]
            elseif result[i].status ~= 0 then
                -- Bad status, no need to parse anything else for thie variable
                break
            elseif dataLen < 9 then
                -- Invalid length
                return nil, ErrorObject.new(ErrorCodes.INVALID_RESPONSE_FROM_SERVER)
            end

            -- Check the type and length of the message
            if dataType == 0 and dataLen ~= 10
            or dataType == 1 and dataLen ~= 13
            or dataType == 2 and dataLen ~= 13
            or dataType == 3 and dataLen ~= 9
            or dataType == 4 and dataLen ~= 10
            or dataType < 0
            or dataType > 4 then
                return nil, ErrorObject.new(ErrorCodes.INVALID_RESPONSE_FROM_SERVER)
            end

            if dataType == 0 then
                result[i].value = variable[8]
                result[i].defaultValue = variable[9]
                result[i].possibleValues = variable[10]
            elseif dataType == 1 or dataType == 2 then
                result[i].unit = string.gsub(variable[8], "\v", "")
                result[i].dot = variable[9]
                result[i].min = variable[10]
                result[i].max = variable[11]
                result[i].value = variable[12]
                result[i].defaultValue = variable[13]
            elseif dataType == 3 then
                result[i].value = variable[8]
                result[i].defaultValue = variable[9]
            elseif dataType == 4 then
                local beginIndex, arrayResult = 9, {}
                for j = 1, variable[8] do
                    table.insert(arrayResult, beginIndex)
                    beginIndex = beginIndex + 1
                end
                result[i].value = arrayResult
                result[i].defaultValue = variable[beginIndex+1]
                result[i].possibleValues = variable[beginIndex+2]
                --TODO - Moke to test
                --if (variable[8] == 0) then
                --    result[i].value = {0,146}
                --    result[i].defaultValue = variable[beginIndex+1]
                --    result[i].possibleValues ={255,255,255,255,0,0,0,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255}
                --end
            else
                return nil,  ErrorObject.new(ErrorCodes.INVALID_DATATYPE)
            end
        else
            return nil, ErrorObject.new(ErrorCodes.INVALID_RESPONSE_FROM_SERVER)
        end
    end
    return result, errMsg
end

function GetParamsDescription.generateSimulationData(addresses)
    local result, errMsg = {}, nil
    
    if ParametersTable ~= nil then
        local listParam = ParametersTable.listparam
        local listDef = ParametersTable.listdef
        for i=1, #addresses do
            local name = GetParamsDescription.GetKeyByValue(ParametersTable['parameterlist'],  addresses[i])
            if (name == nil) then
                name = 'XX' .. math.random(30)
            end

            local options = listDef[listParam[name]]

            if type(options) == "table" then
                result[i] = {
                    0,
                    addresses[i],
                    name,
                    0,
                    false,
                    true,
                    0,
                    math.random(7),
                    0,
                    {3,0,0,0,255,12,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}
                }
            else
                result[i] = {
                    0,
                    addresses[i],
                    name,
                    1,
                    false,
                    true,
                    0,
                    'rpm',
                    0,
                    0,
                    7,
                    math.random(7),
                    0
                }
            end
        end
    end
    return result, errMsg
end

function GetParamsDescription.GetKeyByValue( t, value )
  for k,v in pairs(t) do
    if tostring(v)==tostring(value) then
        return k
    end
  end
  return nil
end

return GetParamsDescription