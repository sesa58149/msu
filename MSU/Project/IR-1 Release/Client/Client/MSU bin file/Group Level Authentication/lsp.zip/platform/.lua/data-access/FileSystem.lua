local FileSystem = {}

function FileSystem.getIO()
    return _G.diskIOName
end

function FileSystem.getFileFromLocal(_ENV, path)
    local splitPath = gf.split(path, "\\")
    local fileName = splitPath[#splitPath]

    if (gf.fileExists(path, true)) then
        -- Get IO interface specific to the environment
        local io = ba.openio(_G.diskIOName)

        if io then
            local fileStats = io:stat(path)
            if fileStats and fileStats.type == 'regular' then
                local fileSizeBytes = fileStats.size

                -- Open the file READONLY
                local file = io:open(path, 'r')
                if file then
                    response:setheader('Content-Disposition', 'attachment;filename="'..fileName..'"')
                    response:setcontentlength(fileSizeBytes) -- Set in bytes
                    if fileSizeBytes <= 8192 then
                        -- Read the entire file
                        local fileData = file:read("*all")
                        -- Close the file
                        file:close()
                        response:send(fileData)
                    else
                        while fileSizeBytes >= 8192 do
                            local fileData = file:read(8192)
                            if fileData then
                                response:send(fileData)
                                fileSizeBytes = fileSizeBytes - 8192
                            else
                                file:close()
                                response:setcontenttype('application/json; charset=UTF-8')
                                response:write(ba.json.encode({success = false, errorMsg = ErrorCodes.ERROR_OCCURRED_DURING_FILE_READ}))
                            end
                        end
                        if fileSizeBytes > 0 then
                            local fileData = file:read(8192)
                            if fileData then
                                response:send(fileData)
                                fileSizeBytes = fileSizeBytes - 8192
                                file:close()
                            else
                                file:close()
                                response:setcontenttype('application/json; charset=UTF-8')
                                response:write(ba.json.encode({success = false, errorMsg = ErrorCodes.ERROR_OCCURRED_DURING_FILE_READ}))
                            end
                        else
                            file:close()
                        end
                    end
                else
                    response:setcontenttype('application/json; charset=UTF-8')
                    response:write(ba.json.encode({success = false, errorMsg = ErrorCodes.FAILED_TO_OPEN_FILE}))
                end
            else
                response:setcontenttype('application/json; charset=UTF-8')
                response:write(ba.json.encode({success = false, errorMsg = ErrorCodes.FAILED_TO_OPEN_FILE}))
            end
        else
            response:setcontenttype('application/json; charset=UTF-8')
            response:write(ba.json.encode({success = false, errorMsg = ErrorCodes.IO_UNAVAILABLE}))
        end
    else
        response:setcontenttype('application/json; charset=UTF-8')
        response:write(ba.json.encode({success = false, errorMsg = ErrorCodes.FILE_NOT_AVAILABLE}))
    end
end

function FileSystem.handleUpload(_ENV, relativePath, fileName, attrs)
    local success, errorMsg, folderStructExists = false, nil, false
    if relativePath and fileName then
        local fullName = relativePath .. fileName -- relativePath should end in /
        folderStructExists, errorMsg = FileSystem.createFolderStructure(relativePath)
        if folderStructExists then
            MultiPart.start(_ENV, {pathLocal = (fullName)}, false)
            -- request:multipart(callBackMultiPart, false)
            if not errorMsg then
                if attrs and attrs.logo == true then
                    local io = ba.openio(_G.diskIOName)

                    if io then
                        local stats = io:stat(fullName)
                        local data  = nil
                        data, errorMsg  = FileSystem.readAllFileData(io, fullName)

                        if stats and data then
                            success, errorMsg = Logo.add(io, stats, data)
                        else
                            errorMsg = fullName
                        end
                    else
                        errorMsg = ErrorCodes.CANNOT_ACCESS_DISK
                    end
                elseif attrs and attrs.theme == true then
                    local io = ba.openio(_G.diskIOName)

                    if io then
                        local stats = io:stat(fullName)
                        local data  = nil
                        data, errorMsg = FileSystem.readAllFileData(io, fullName)

                        if stats and data then
                            success, errorMsg = Theme.addFromFile(io, stats, data)
                        else
                            errorMsg = fullName
                        end
                    else
                        errorMsg = ErrorCodes.CANNOT_ACCESS_DISK
                    end
                else
                    success = true
                end
            end
        else
            errorMsg = ErrorCodes.FAILED_TO_CREATE_FOLDER_STRUCTURE
        end
    else
        errorMsg = ErrorCodes.INVALID_UPLOAD_PATH
    end

    local obj = {success = success}
    if not success then
        obj.errorMsg = errorMsg
    end

    response:write(ba.json.encode(obj))
end

function FileSystem.readAllFileData(io, filePath)
    local success, errorMsg = false, nil
    if filePath and string.len(filePath) > 0 then
        local file = io:open(filePath)
        if file then
            local data = file:read("*a")
            if data then
                file:close()
                success = data
            else
                file:close()
                errorMsg = ErrorCodes.UNABLE_TO_READ_FILE
            end
        else
            errorMsg = ErrorCodes.FILE_DOES_NOT_EXIST
        end
    else
        errorMsg = ErrorCodes.NO_FILE_PROVIDED
    end
    return success, errorMsg
end

function FileSystem.createFolderStructure(filePath)
    if filePath == nil then
        return false, ErrorCodes.INVALID_CONSTANT_PATH
    end
    -- Check if it is just a filename. If it is then we don't need to do anything.
    local directoryPath = nil
    local i, endIndex = nil, nil
    local directoryInPath = false

    for i=filePath:len(), 1, -1 do
        if string.byte(filePath:sub(i,i)) == 92 then
            endIndex = i - 1
            directoryInPath = true
            break
        end
    end

    if directoryInPath then
        directoryPath = filePath:sub(1, endIndex)
    else
        -- No need to create a directory cause it will get written to the root of the io
        return true
    end

    return FileSystem.createFolders(directoryPath, FileSystem.getIO(false))
end

function FileSystem.createFolders(folderPath, resourceName)
    local result, errorMsg = false, nil
    if not gf.directoryExists(folderPath) then
        local parentPath = FileSystem.navUpDirectory(folderPath)
        if parentPath then
            result, errorMsg = FileSystem.createFolders(parentPath)
            if result then
                if resourceName then
                    local io = ba.openio(resourceName)

                    if io then
                        result, errorMsg = io:mkdir(folderPath)
                    else
                        errorMsg = ErrorCodes.FAILED_TO_CREATE_FILE_DURING_UPLOAD
                    end
                end
            end
            -- Create your folder using your parents path to open
        else
            if resourceName then
                -- Base case
                local io = ba.openio(resourceName)

                if io then
                    result, errorMsg = io:mkdir(folderPath)
                else
                    errorMsg = ErrorCodes.FAILED_TO_CREATE_FILE_DURING_UPLOAD
                end
            end
        end
    else
        result = true
    end

    return result, errorMsg
end

-- Assume folderPath is just a path that has nested folders
function FileSystem.navUpDirectory(folderPath)
    local hasBackslashes = false
    local i, endIndex = nil, nil
    for i=folderPath:len(), 1, -1 do
        if string.byte(folderPath:sub(i,i)) == 92 then
            endIndex = i - 1
            hasBackslashes = true
            break
        end
    end

    if hasBackslashes then
        directoryPath = folderPath:sub(1,endIndex)
    else
        return false -- No need to create a directory cause it will get written to the root of the io
    end
    return directoryPath
end

function FileSystem.UserAgentIsIE(userAgent)
    return (string.find(userAgent, 'MSIE'))
end

return FileSystem