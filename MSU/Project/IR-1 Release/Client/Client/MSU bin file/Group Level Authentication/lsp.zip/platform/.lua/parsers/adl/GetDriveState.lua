-- UMAS : Read Multiple BOL

local GetDriveState = {}

function GetDriveState.isValidInput(input)
    if type(input) == 'nil' then
        return true
    end

    if type(input) ~= 'table' then
        return false
    end

    -- Session is optional for now.
    if type(input.session) ~= 'nil' and type(input.session) ~= 'number' then
        return false
    end
    -- Valid variables
    return true
end
function GetDriveState.getParams()
    local min = nil
    local max = nil
    local isDirectionAllowed = false

    if type(ParametersTable) == 'table' and
       type(ParametersTable["parameterlist"]) == 'table' and
       type(ParametersTable["parameterlist"]['HSP']) == 'string' and
       type(ParametersTable["parameterlist"]['RIN']) == 'string' and
       type(ParametersTable["parameterlist"]['LSP']) == 'string' then

        local lspAddress = tonumber(ParametersTable["parameterlist"]['LSP'])
        local hspAddress = tonumber(ParametersTable["parameterlist"]['HSP'])
        local rinAddress = tonumber(ParametersTable["parameterlist"]['RIN'])

        local result, errorMsg = ReadParamsNonCons.fetch(Constants.DRIVE_UNIT_ID, {lspAddress, hspAddress, rinAddress})
        if type(result) == 'table' and #result == 3 then
            min = result[1].value
            max = result[2].value
            isDirectionAllowed = result[3].value
        else
            return nil, ErrorCodes.UNABLE_TO_GET_REQUIRED_PARAMS
        end
    else
        return nil, ErrorCodes.PARAMS_NOT_IN_WEB_DESC
    end

    return {min=min, max=max, isDirectionAllowed=isDirectionAllowed}
end

function GetDriveState.getData(input)
    local result, data, errorMsg = nil, nil, nil

    -- Check input validity
    if GetDriveState.isValidInput(input) then
        if LuaADL and not _G.forceSimulation then
            local session = 0 -- Default to 0 if no session is provided

            -- If a session was inputted then use it when performing the read object
            if type(input) == 'table' and type(input.sessionID) == 'number' then session = input.sessionID end

            -- Perform Request
            data, errorMsg = LuaADL.ReadObject(Constants.DRIVE_UNIT_ID, session, {0, 0x0101})
        else
            data, errorMsg = GetDriveState.getSimulationData()
        end

        if GetDriveState.isValidResponse(data) then
            local params, errorMsg = GetDriveState.getParams()
            if type(params) ~= 'table' then
                return nil, errorMsg
            end

            result = GetDriveState.generateServiceResponse(data, params)
        end
    else
        errorMsg = ErrorCodes.INVALID_REQUEST
    end

    --Return variable data with values
    return result, errorMsg
end

function GetDriveState.isValidResponse(data)

    if type(data) ~= 'table' or #data ~= 2 then
        return false
    end

    if type(data[2]) ~= 'table' or #data[2] ~= 7 then
        return false
    end

    for i=1,7 do
        if type(data[2][i]) ~= 'number' then
            return false
        end
    end

    return true
end

function GetDriveState.generateServiceResponse(resp, params)
    local respData = resp[2]

    local result = {}

    status = Utils.convertBytesToInt32(respData[1], respData[2], respData[3], respData[4])
    result.isMemorizationInProgress = bit32.extract(status, 0, 1) == 1
    result.isHighPowerSupplyOn = bit32.extract(status, 1, 1) == 1
    result.isDriveRunning = bit32.extract(status, 2, 1) == 1
    result.isInDCInjection = bit32.extract(status, 3, 1) == 1
    result.isGoingForward = bit32.extract(status, 4, 1) == 0
    result.faultState = bit32.extract(status, 5, 2)
    result.isControlledByCommTool = bit32.extract(status, 7, 1) == 1
    result.isControlledByMyCommTool = bit32.extract(status, 8, 1) == 1
    result.isInForcedLocalMode = bit32.extract(status, 9, 1) == 1
    result.isDriveReadyToRun = bit32.extract(status, 10, 1) == 0
    result.isBlockedByDisableVoltage = bit32.extract(status, 11, 1) == 1
    result.isBlockedByDCStopOrder = bit32.extract(status, 12, 1) == 1
    result.isBlockedByFastStopOrder = bit32.extract(status, 13, 1) == 1
    result.isBlockedBySTOOrder = bit32.extract(status, 14, 1) == 1
    result.isDriveLocked = bit32.extract(status, 15, 1) == 1
    result.freqRef = Utils.convertBytesToInt16(respData[5], respData[6])
    result.currentFault = GetDriveState.getDriveFaultLbl(respData[7])
    result.freqRefMin = params.min
    result.freqRefMax = params.max
    result.isDirectionAllowed = params.isDirectionAllowed == 0

    return result
end
function GetDriveState.getDriveFaultLbl(state)
    local result = state
    if ParametersTable then
        local listID = ParametersTable.listparam['LFT']
        local faultStates = ParametersTable.listdef[listID]
        local lookUpVal = faultStates[tostring(state)]
        if type(lookUpVal) == "string" and #lookUpVal > 0 then
            result = lookUpVal
        end
    end
    return result
end
function GetDriveState.getSimulationData(obj)
    return {0, {0,0,0,0,0,0,0}}
end

return GetDriveState