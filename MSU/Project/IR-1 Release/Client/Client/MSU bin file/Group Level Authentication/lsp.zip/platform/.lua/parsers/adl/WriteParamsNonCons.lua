local WriteParamsNonCons = {}

-- Send the modbus request and parse the result
function WriteParamsNonCons.fetch(unitID, address, mnemonicType, value)
    if type(unitID) ~= 'number' then
        return nil, ErrorObject.new(ErrorCodes.INVALID_DATATYPE, '"unitID" is not the correct type in WriteParamsNonCons.fetch. Number expected.')
    end

    if type(mnemonicType) ~= 'number' or mnemonicType > 5 then
        trace(mnemonicType)
        return nil, ErrorObject.new(ErrorCodes.INVALID_DATATYPE,'"type" is not the correct type in WriteParamsNonCons.fetch. Number expected.')
    end

    if type(address) ~= 'number' then
        return nil, ErrorObject.new(ErrorCodes.INVALID_DATATYPE, '"address" is not the correct type in WriteParamsNonCons.fetch. Number expected.')
    end

    if mnemonicType == 4 then
        -- Check for table
        if type(value) ~= 'table' then
            return nil, ErrorObject.new(ErrorCodes.INVALID_VALUE)
        end

        -- Check that all the values in the table are a number
        for i=1, #value do
            if type(value[i]) ~= 'number' then
                return nil, ErrorObject.new(ErrorCodes.INVALID_VALUE)
            end
        end
    else
        if type(value) ~= 'number' then
            return nil, ErrorObject.new(ErrorCodes.INVALID_VALUE)
        end
    end

    local data, errMsg = nil, nil

    if LuaADL and not _G.forceSimulation then
        if mnemonicType == 4 then
            local convertedValue = {#value}
            for i=1, #value do
                convertedValue[i+1] = value[i]
            end
            data, errMsg = LuaADL.WriteParamsNonCons(unitID, 1, {address, mnemonicType, convertedValue})
        else
            data, errMsg = LuaADL.WriteParamsNonCons(unitID, 1, {address, mnemonicType, value})
        end
        collectgarbage("collect")
    else
        data, errMsg = WriteParamsNonCons.generateSimulationData(), nil
    end

    if errMsg ~= nil then
        return nil, ErrorObject.new(ErrorCodes.ADL_WRITE_FAILED, errMsg)
    elseif type(data) ~= 'number' then
        return nil, ErrorObject.new(ErrorCodes.INVALID_DATATYPE)
    end
    return WriteParamsNonCons.parse(data), nil
end

-- Parse the result
function WriteParamsNonCons.parse(data)
    if type(data) ~= 'number' then
        return nil, ErrorObject.new(ErrorCodes.INVALID_DATATYPE, '"data" invalid type in WriteParamsNonCons.parse. Expected Number')
    end

    return {
        status = data
    }
end

function WriteParamsNonCons.generateSimulationData()
    return 0
end

return WriteParamsNonCons