--[[
	ModbusCommon (MbC)
]]

local MbC = {}

MbC.noComm = _G.forceNoModbus
if not MbC.noComm then
	if not LuaModBus then
		MbC.noComm = true
	end
end

-- Modbus.FC3(int startReg, int length, String errorCode, function noCommCallback)
-- Performs a generic Modbus Read Multiple Registers request
function MbC.FC3(id, startReg, length, errorCode, noCommCallback)
	local data, errMsg = nil, nil
	if MbC.noComm then
		if type(noCommCallback) == 'function' then
			data = noCommCallback()
		end
	else
		data, errMsg = LuaModBus.ReadMultipleRegisters(id, startReg, length)
		collectgarbage("collect")
	end
	if (not data or data[1] < 0) and not errMsg then
		return nil, errorCode
	elseif (not data or data[1] < 0) then
		return nil, errMsg
	end
	return data, errMsg
end

-- Modbus.FC8(int subcode, int opcode, Table moreData, String errorCode, function noCommCallback)
-- Performs a generic Modbus function code 8 request
function MbC.FC8(subcode, opcode, moreData, errorCode, noCommCallback)
	local data, errMsg = nil, nil
	if MbC.noComm then
		if type(noCommCallback) == 'function' then
			data = noCommCallback(moreData)
		end
	else
		if moreData ~= nil then
			data, errMsg = LuaModBus.DiagnosticsData(subcode, opcode, moreData)
		else
			data, errMsg = LuaModBus.DiagnosticsData(subcode, opcode)
		end
		collectgarbage("collect")
	end
	if not data and not errMsg then
		return nil, errorCode
	elseif not data then
		return nil, errMsg
	end
	return data, errMsg
end

-- Modbus.FC16(int startingRegister, int registerCount, Table writeData, String errorCode, function noCommCallback)
-- Performs a generic Modbus function code 16 request
function MbC.FC16(id, startingRegister, registerCount, writeData, errorCode, noCommCallback)
	local result, errMsg = false, nil
	if MbC.noComm then
		if type(noCommCallback) == 'function' then
			result = noCommCallback()
		end
	else
		if type(writeData) == 'table' and registerCount == #writeData then
			result = LuaModBus.WriteMultipleRegisters(id, startingRegister, registerCount, writeData)
		else
			errMsg = ErrorCodes.INVALID_INPUT
		end
		collectgarbage("collect")
	end

	if type(result) == 'string' then
		if not errorCode then
			errMsg = result
			result = false
		else
			errMsg = errorCode
		end
	end

	return result, errMsg
end


-- MbC.getNumberOfPorts()
-- Returns the number of ports associated with the device
function MbC.getNumberOfPorts()
	if not MbC.noComm then
		local portList = LuaModBus.DiagnosticsData(22, Constants.LIST_PORTS_INFO, {0, 0})
		collectgarbage("collect")
		if portList and portList[1] > 0 then
			return tonumber(portList[6])
		else
			return 0
		end
	else
		return 5
	end
end

-- MbC.clearBytes(Table data, int bytes)
-- Removes a number of bytes from the beginning of data - generally used for header data
function MbC.clearBytes(data, bytes)
	for el = 1, bytes do
		table.remove(data, 1)
	end
	return data
end

-- Get number of ports once and reuse - can't do this - ASYNCHRONOUS
--MbC.numPorts = MbC.getNumberOfPorts()

return MbC