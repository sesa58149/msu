-- UMAS : Read Multiple BOL

local OpenSession = {}

function OpenSession.isValidInput(input)
    if type(input) ~= 'table' then
        return false
    end

    if type(input.timeout) ~= 'number' then
       return false
    end

    -- Valid variables
    return true
end

function OpenSession.getData(input)
    local result, data, errorMsg = nil, nil, nil

    -- Check input validity
    if OpenSession.isValidInput(input) then

        if LuaADL and not _G.forceSimulation then
            -- Perform Request
            data, errorMsg = LuaADL.OpenSession(Constants.DRIVE_UNIT_ID, input.timeout)
        else
            data, errorMsg = OpenSession.getSimulationData()
        end

        if OpenSession.isValidResponse(data) then
            result = OpenSession.generateServiceResponse(data, variables)
        end
    else
        errorMsg = ErrorCodes.INVALID_REQUEST
    end

    --Return variable data with values
    return result, errorMsg
end

function OpenSession.isValidResponse(data)
    if type(data) ~= 'table' or #data ~= 2 then
        return false
    end

    for i=1, 2 do
        if type(data[i]) ~= 'number' then
            return false
        end
    end
    -- Valid response
    return true
end

function OpenSession.generateServiceResponse(resp)
    local formattedResp = {}

    formattedResp.sessionID = resp[1]
    formattedResp.actualTimeout = resp[2]

    -- If the response from the server is valid then return true
    return formattedResp
end

function OpenSession.getSimulationData(obj)
    return {0x74, 3000}
end

return OpenSession