local AutoTest = {};
local testRunning, typeTest = false, -1;

function AutoTest.startTest(testType)
    local result, errMsg = nil, nil
    if (not testRunning) then
        if (ParametersTable ~= nil) then
            local unitID = 248
            local address = tonumber(ParametersTable["parameterlist"]["DIAC"])
            local mnemonicType = 0
            local value = tonumber(testType)

            if not type(unitID) == 'number' or not type(address) == 'number' or not type(mnemonicType) == 'number' or not type(value) == 'number' then
                result, errMsg = nil, ErrorCodes.INVALID_REQUEST
            else
                local data, errorMsg = ADL.WriteParamsNonCons(unitID, address, mnemonicType, value)
                if data then
                    typeTest = value
                    testRunning = true
                    result = ba.json.encode(data)
                else
                    result, errMsg =  nil,  errorMsg
                end
            end
        else
            result, errMsg =  nil, ErrorObject.new(ErrorCodes.FILE_NOT_AVAILABLE, 'Parameter table not available')
        end
    else
        result, errMsg =  nil, ErrorObject.new(ErrorCodes.TEST_ALREADY_STARTED, tostring(typeTest))
    end

    return result, errMsg
end

function AutoTest.getStatus()
    local result, errorMsg = nil, nil
    if (ParametersTable ~= nil) then
        local address = tonumber(ParametersTable["parameterlist"]["DIAS"])
        address = 13728
        if LuaADL then
            local data, errMsg = ADL.ReadParamsNonCons(248, {address});
            if data ~= nil and #data > 0 then
                result = data[1].value
            else
                errMsg = errorMsg
            end
        else
           result = 2;
        end
    else
        errorMsg = ErrorObject.new(ErrorCodes.FILE_NOT_AVAILABLE, 'Parameter table not available')
    end
    return result, errorMsg
end

function AutoTest.getResult(testType)
    local result, errorMsg = {}, nil
    local decRead, interResult = {}, {}
    local skip, testString = 1, ""

    if (ParametersTable ~= nil) then
        --FAN Tests
        if (testType =="3") then
            testString = "DFAN"
            local address = tonumber(ParametersTable["parameterlist"]["DFAN"])
            if LuaADL then
               decRead = ADL.ReadParamsNonCons(248, {address})
            else
               decRead = {{status=0,address=13726,value=1,type=1}} --Simulate Value
            end
            interResult = AutoTest.parseResult(decRead[1].value, 0, 1, 1)
        --IGBT Tests
        elseif ((testType =="5") or (testType == "6")) then
            testString = "PWI1"
            local address = tonumber(ParametersTable["parameterlist"]["PWI1"])
            if LuaADL then
               decRead = ADL.ReadParamsNonCons(248, {address})
            else
               decRead = {{status=0,address=13727,value=32761,type = 1}} --Simulate Value
            end
            if (testType =="5") then
                interResult = AutoTest.parseResult(decRead[1].value, 0, 11, 1)
            else
                interResult = AutoTest.parseResult(decRead[1].value,  0, 11, 2)
                skip = 2 --Step for the result generation
            end
        end
    else
        errorMsg = ErrorObject.new(ErrorCodes.FILE_NOT_AVAILABLE, 'Parameter table not available')
    end

    local index = skip
    for i=1, #interResult do
        local diagO = {}
        diagO["nameResult"] = testString .. "_" .. index
        diagO["testResult"] = interResult[i]
        table.insert(result, diagO)
        index = index + skip
    end
    testRunning = false -- Able to make an other test
    return result, errorMsg
end

function AutoTest.parseResult(value, beginIndex, endIndex, step)
    local buffer = {}
    for i = beginIndex,endIndex,step do
        --table.insert(buffer, bit32.band(bit32.rshift(value, i), 1))
        table.insert(buffer, bit32.extract(value, i))
    end
    return buffer
end

return AutoTest;