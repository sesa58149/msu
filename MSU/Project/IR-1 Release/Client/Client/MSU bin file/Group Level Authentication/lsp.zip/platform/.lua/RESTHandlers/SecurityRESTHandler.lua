local SecurityRESTHandler = {}

function SecurityRESTHandler.getHandler(_ENV, path)
    local result, tableData, errorMsg = nil, nil, nil
    local method = request:method()

    -- Ensure that the response is has a content type of JSON
    response:setheader('content-type', 'application/json; charset=UTF-8')

    -- Case insensitive
    path = path:lower()

    if(path == '') then
        gf.sendError(_ENV)
    elseif(path == 'mode' or path == 'mode/') then
        if (method == 'GET') then
            HTTPMethods.get(_ENV, SecurityRESTHandler.getMode)
        elseif (method == 'POST') then
            HTTPMethods.post(_ENV, SecurityRESTHandler.setMode)
        else
            gf.sendError(_ENV) -- Not Implemented
        end
    elseif(path == 'pwpolicy' or path == 'pwpolicy/') then
        if (method == 'GET') then
            HTTPMethods.get(_ENV, SecurityRESTHandler.getPwPolicy)
        elseif method == 'PUT' then
            HTTPMethods.put(_ENV, SecurityRESTHandler.setPwPolicy)
        else
            gf.sendError(_ENV)
        end
    else
        gf.sendError(_ENV) -- Not Implemented
    end
end

function SecurityRESTHandler.getPwPolicy()
    local result, errMsg = SecurityDA.getPwPolicy()
    if type(result) == 'table' then
        return ba.json.encode(result)
    elseif type(result) ~= 'table' and not errMsg then
        return nil, ErrorCodes.GET_PW_POLICY_FAILED
    else
        return nil, errMsg
    end
end

function SecurityRESTHandler.setPwPolicy(data)
    if type(data) ~= 'table' then
        return nil, ErrorCodes.SET_PW_POLICY_FAILED
    end
    local result, errMsg = SecurityDA.setPwPolicy(data)
    if not errMsg then
        return ba.json.encode({success = result})
    else
        return nil, errMsg
    end
end

function SecurityRESTHandler.getMode()
    local result, errorMsg = SecurityDA.getMode()
    if type(result) ~= 'string' or result ~= '1' and result ~= '0' then
        result = 1 -- Force security enabled
        if not errorMsg then
            errorMsg = ErrorCodes.INVALID_REQUEST
        end
    end
    return ba.json.encode({mode=tonumber(result), errorMsg=errorMsg})
end

function SecurityRESTHandler.setMode(jsonObject)
    if type(jsonObject) ~= "table" or type(jsonObject.mode) ~= "number" or jsonObject.mode ~= 1 and jsonObject.mode ~= 0 then
        return ba.json.encode({success=false, errorMsg=ErrorCodes.INVALID_REQUEST})
    end

    local mode = jsonObject.mode

    local result, errorMsg = SecurityDA.setMode(mode)
    if result then
        if mode == 1 then
            _G.minutesUntilTimeout = tonumber(Security.getSessionTimeout())
            _G.securityMode = '1'
            -- Get/Generate the seed
            local salt, errorMsg = Security.getCreateSalt()
            while salt == nil do
                trace('Failed to generate salt. Trying again in 1 second.')
                ba.sleep(1000) -- Sleep for 1 second and try again
                salt, errorMsg = Security.getCreateSalt()
            end

            -- Store the salt globally
            _G.salt = salt

            ------------------------------------------------------------------------
            -- Create the username database from our getPassword func.
            local authuser = ba.create.authuser(Security.getPassword)
            ---- Create authorizer object
            local authorizer = ba.create.authorizer(Security.authorization)

             -- http://domain/logout
            _G.logout = ba.create.dir('logout')
            _G.logout:setfunc(Security.logout)
            _G.resrdr:insert(_G.logout, true)

            -- Create the authenticator that will be applied to the application's directory
            local authenticator=ba.create.authenticator(authuser,{response=Security.loginResponse, type="form"})

            -- Apply authenticator to our application's resource reader object.
            _G.resrdr:setauth(authenticator, authorizer)

            -- Upon login check to ensure that the user isn't supposed to be forced to change their password
            _G.resrdr:setfunc(Security.handleRemindPassword)
        else
            _G.securityMode = '0'
            _G.minutesUntilTimeout = nil

            -- Remove security
            _G.resrdr:setauth(nil, nil)
            _G.logout:unlink()
            _G.resrdr:setfunc(nil)
        end
    else
        if not errorMsg then
            errorMsg = ErrorCodes.INVALID_REQUEST
        end
    end
    return ba.json.encode({success=result, errorMsg=errorMsg})
end

return SecurityRESTHandler