local Dashboard = {}

function Dashboard.save(dashboardData, user_name)
    local result = false
	local errorMsg = nil
	-- Grab a reference to SQLite environment
	local env = luasql.sqlite()

	-- Connect to the database with write permissions
	local connection = env:connect(Constants.DB_PATH)

	-- Establish how long to wait for the write lock on the database and acquire the lock.
	local isLockAcquired = connection:setautocommit('IMMEDIATE', 1000)

	-- Process update if the lock has been acquired
	if isLockAcquired then
		local userExists = false
		userExists, errorMsg = Dashboard.exists(connection, user_name)
		if userExists then
			-- Prepare the query
			local cursor  = connection:prepare([[
				UPDATE dashboard
				SET columns = ( ? )
				WHERE username = ( ? )
			]])
			if cursor ~= nil then
				-- Bind username to the prepared statement
				cursor:bind{
					{'TEXT', dashboardData.columns},
					{'TEXT', user_name}
				}
				-- Execute query
				local exec = cursor:execute()
				if not exec then
					errorMsg = ErrorCodes.USER_UPDATE_FAILED

					--if not connection:rollback() then
					--	trace('ROLLBACK FAILED')
					--end
				else
					-- Commit the transaction
					if connection:commit() then
						result = true
					else
						errorMsg = ErrorCodes.COMMIT_FAIL
					end
				end
				-- Close cursor connection to database
				if not cursor:close() then
					trace('FAILED TO CLOSE CURSOR')
				end
			end
		elseif not userExists and not errorMsg then
			errorMsg = ErrorCodes.USER_DOES_NOT_EXIST
		end
	else
		errorMsg = ErrorCodes.LOCK_FAIL
	end

	-- Close connection to database
	if not connection:close() then
		trace('FAILED TO CLOSE SQLITE CONNECTION')
	end
	-- Close connection to SQLite
	if not env:close() then
		trace('FAILED TO CLOSE SQLITE ENVIRONMENT')
	end

    return result, errorMsg
end

function Dashboard.get(user_name)
	local result = {}
	local dashboard = {}
	local env = luasql.sqlite()
	local connection = env:connect(Constants.DB_PATH, 'READONLY')
	local cursor, errorMsg = nil

	if env ~= nil and user_name ~= nil and user_name:len() > 0 then
		-- Build Prepared Statement
		if connection ~= nil then
			cursor = connection:prepare([[
				SELECT *
				FROM dashboard
				WHERE dashboard.username = ( ? )
			]])
			-- Bind username to the prepared statement
			if cursor ~= nil then
				cursor:bind{{'TEXT', user_name}}
				local exec = cursor:execute()
				if exec then
					-- Grab results in a table
					cursor:fetch(dashboard, 'a')
					-- While user is not nil and is not an empty table
					if dashboard then
			            result.columns = dashboard.columns
					end
				else
					result = false
					errorMsg = ErrorCodes.GET_DASHBOARD_FAILED
				end
				-- Clean up
				if not cursor:close() then
					trace('FAILED TO CLOSE CURSOR')
				end
			end
			if not connection:close() then
				trace('FAILED TO CLOSE SQLITE CONNECTION')
			end
		end
		if not env:close() then
			trace('FAILED TO CLOSE SQLITE ENVIRONMENT')
		end
	end

    return result, errorMsg
end

function Dashboard.exists(connection, username)
	local result = false
	local errorMsg = nil
    -- Prepare query to identify whether the user exists or not
    local cursor =
		connection:prepare([[SELECT count(*) FROM dashboard WHERE dashboard.username = ( ? )]])

	if cursor then
		-- Bind username to the prepared statement
		cursor:bind{{'TEXT', username}}
		-- Execute query
		local exec = cursor:execute()
		if exec then
			local queryResult = {}
			cursor:fetch(queryResult)

			local numberOfUsersWithUserName = queryResult[1]
			result = tonumber(numberOfUsersWithUserName) > 0
		else
			errorMsg = ErrorCodes.DATABASE_ERROR
		end
		-- Clean up database connections
		if not cursor:close() then
			trace('FAILED TO CLOSE CURSOR')
		end
	else
		errorMsg = ErrorCodes.INVALID_SQL_SYNTAX
	end

	return result, errorMsg
end

return Dashboard