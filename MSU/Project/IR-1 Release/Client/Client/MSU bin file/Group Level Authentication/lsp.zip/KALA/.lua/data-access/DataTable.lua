local io = ba.openio(_G.diskIOName)
local DataTable = io:dofile('platform/.lua/data-access/DataTable.lua')

function DataTable.getTableInfo(tableName)
	if luasql == nil then
		return false, ErrorCodes.NO_SQL -- ONLY FOR THE NOSQL VERSION
	end

	if( tableName == 'Simply_Start' ) then
		return {
			table_name = tableName,
			table_type = "1",
			description = '',
			numvars = #ParametersTable['simplystart'] -- todo: count 
		}
	end

	local result, errorMsg = {}, nil

	if ParametersTable ~= nil then
		for k, v in pairs( ParametersTable.monitfunc ) do
			if( string.gsub(k, " ", "") == string.gsub(tableName, " ", "") ) then
				result = {
					table_name = k,
					table_type = "4",
					description = '',
					numVars = #v
				}
				break
			end
		end
		for k, v in pairs( ParametersTable.comfunc ) do
			if( string.gsub(k, " ", "") == string.gsub(tableName, " ", "") ) then
				result = {
					id = k,
					table_type = "5",
					description = '',
					numVars = #v
				}
				break
			end
		end
		--driveparam menu
		for k, v in pairs( ParametersTable.drivefunc ) do
			if( string.gsub(k, " ", "") == string.gsub(tableName, " ", "") ) then
				result = {
					id = k,
					table_type = "6",
					description = '',
					numVars = #v
				}
				break
			end
		end
	end



	if( #result ~= 0 ) then
		return result, nil
	end

	local env = luasql.sqlite()
    local connection = env:connect(Constants.DB_PATH, 'READONLY')
    local cursor
    if tableName ~= nil and tableName:len() > 0 then
        -- Build Prepared Statement
        cursor = connection:prepare(
			[[SELECT *
			FROM  data_table
			WHERE data_table.table_name = ( ? )]]
		)
        if not cursor then
            return nil, ErrorCodes.INVALID_SQL_SYNTAX
        end

        -- Bind chart to the prepared statement
        cursor:bind{{'TEXT', tableName}}
    else
        return nil, ErrorCodes.TABLE_NAME_REQUIRED
    end

    local exec = cursor:execute()

	if exec then
		-- Grab results in a table
		cursor:fetch(result, 'a')
	else
        result = false
		errorMsg = ErrorCodes.GET_TABLE_FAILED
    end

    -- Close database connection as soon as it is no longer needed
    if not cursor:close() then
        trace('FAILED TO CLOSE CURSOR')
    end

    if not connection:close() then
        trace('FAILED TO CLOSE SQLITE CONNECTION')
    end

    if not env:close() then
        trace('FAILED TO CLOSE SQLITE ENVIRONMENT')
    end

    return result, errorMsg
end

function DataTable.getTables()
	if luasql == nil then
		return false, ErrorCodes.NO_SQL -- ONLY FOR THE NOSQL VERSION
	end
	local result = {}
	local errorMsg = nil

    local env = luasql.sqlite()

    if env ~= nil then

	    local connection = env:connect(Constants.DB_PATH, 'READONLY')
	    local dataTable = {}

	    if connection ~= nil then
		    local cursor = connection:prepare([[
				SELECT *
				FROM data_table
			]])
			if cursor ~= nil then
			    local exec = cursor:execute()
			    if exec then
					-- Grab results in a table
					cursor:fetch(dataTable, 'a')
					-- While user is not nil and is not an empty table
					while (dataTable and next(dataTable)) do
						local numVars = DataTable.getNumberOfVariablesInTable(connection, dataTable.table_name)
						local obj = {
							id = dataTable.table_name,
							table_type = dataTable.table_type,
							description = dataTable.description,
							numVars = numVars
						}
						table.insert(result,obj)
						-- Grab results in a table
						dataTable = cursor:fetch(dataTable, 'a')
					end
				else
					errorMsg = ErrorCodes.GET_TABLE_NAMES_ERROR
					return nil, errorMsg
				end

				-- Clean up
			    if not cursor:close() then
			        trace('FAILED TO CLOSE CURSOR')
			    end

			    if not connection:close() then
			        trace('FAILED TO CLOSE SQLITE CONNECTION')
			    end
			else
				trace('Sqlite cursor is nil')
			end
		else
			trace('Coult not make sqlite connection')
		end
	    if not env:close() then
	        trace('FAILED TO CLOSE SQLITE ENVIRONMENT')
	    end
	else
		trace('Could not invoke luasql.sqlite()')
	end
    --Loop through list of tables in ParametersTable

    if ParametersTable ~= nil then
		for k, v in pairs( ParametersTable.monitfunc ) do
			local MonitFunc = {
				id = k,
				table_type = "4",
				description = '',
				numVars = #v
			}
			table.insert(result, MonitFunc)
		end
		for k, v in pairs( ParametersTable.comfunc ) do
			local ConfigFunc = {
				id = k,
				table_type = "5",
				description = '',
				numVars = #v
			}
			table.insert(result, ConfigFunc)
		end
		for k, v in pairs( ParametersTable.drivefunc ) do
			local DriveFunc = {
				id = k,
				table_type = "6",
				description = '',
				numVars = #v
			}
			table.insert(result, DriveFunc)
		end
	end

    return result, errorMsg
end

function DataTable.create(tableData)
	if luasql == nil then
		return false, ErrorCodes.NO_SQL -- ONLY FOR THE NOSQL VERSION
	end

	local env = luasql.sqlite()
	local connection = env:connect(Constants.DB_PATH)
	local isLockAcquired = connection:setautocommit('IMMEDIATE', 1000)
	local result = false
	local errorMsg = nil

	if isLockAcquired then
		local validTable = false
		    --Avoid XSS
    	tableData.id = gf.htmlspecialchars(tableData.id)
    	tableData.description = gf.htmlspecialchars(tableData.description)
    	
		validTable, errorMsg = DataTable.validateTable(connection, tableData, false)
		if validTable then
			local cursor = connection:prepare([[
				INSERT INTO data_table (table_name, table_type, description)
				VALUES (?,?,?)
			]])
			cursor:bind{
				{'TEXT', tableData.id},
				{'INTEGER', tableData.table_type},
				{'TEXT', tableData.description}
			}
			local exec = cursor:execute()
			if not exec then
				errorMsg = ErrorCodes.CREATE_TABLE_FAILED
			else
				if connection:commit() then
					result = true
				else
					errorMsg = ErrorCodes.COMMIT_FAIL
				end
			end

			if not cursor:close() then
				trace('FAILED TO CLOSE CURSOR')
			end
		end
	else
		errorMsg = ErrorCodes.LOCK_FAIL
	end

	--Close DB connection
	if not connection:close() then
		trace('FAILED TO CLOSE SQLITE CONNECTION')
	end
	if not env:close() then
		trace('FAILED TO CLOSE SQLITE ENVIRONMENT')
	end

	return result, errorMsg
end

----------------- DATA TABLE VARIABLE FUNCTIONS --------------------
function DataTable.getTable(tableName)
	if luasql == nil then
		return false, ErrorCodes.NO_SQL -- ONLY FOR THE NOSQL VERSION
	end

	if( tableName == 'Simply_Start' ) then
		return DataTable.getJsonTable(tableName)
	end

	local mnemonics, result = {}, {}

	if( ParametersTable ~= nil and ParametersTable['monitfunc'][tableName] ~= nil ) then
		for k, v in pairs(ParametersTable['monitfunc'][tableName]) do
			table.insert(mnemonics, v)
		end
	elseif( ParametersTable ~= nil and ParametersTable['comfunc'][tableName] ~= nil ) then
		for k, v in pairs(ParametersTable['comfunc'][tableName]) do
			table.insert(mnemonics, v)
		end
	elseif( ParametersTable ~= nil and ParametersTable['drivefunc'][tableName] ~= nil ) then
		for k, v in pairs(ParametersTable['drivefunc'][tableName]) do
			table.insert(mnemonics, v)
		end
	else
		--keep locals down here since we usualy won't use them
		local env = luasql.sqlite()
	    local connection = env:connect(Constants.DB_PATH, 'READONLY')
	    local cursor, errorMsg = nil
		local tableVars = {}
	    if tableName ~= nil and tableName:len() > 0 then
	        -- Build Prepared Statement
	        cursor = connection:prepare(
				[[SELECT DISTINCT mnemonic
				FROM  data_table_variable
				WHERE data_table_variable.table_name = ( ? )]]
			)
	        if not cursor then
	            return nil, ErrorCodes.INVALID_SQL_SYNTAX
	        end

	        -- Bind chart to the prepared statement
	        cursor:bind{{'TEXT', tableName}}
	    else
	        return nil, ErrorCodes.TABLE_NAME_REQUIRED
	    end

	    local exec = cursor:execute()

		if exec then
			-- Grab results in a table
			cursor:fetch(tableVars, 'a')

			while (tableVars and next(tableVars)) do
				mnemonics[#mnemonics+1] = tableVars.mnemonic
				-- Grab results in a table
				tableVars = cursor:fetch(tableVars, 'a')
			end
		else
	        result = false
			errorMsg = ErrorCodes.GET_TABLE_FAILED
	    end

	    -- Close database connection as soon as it is no longer needed
	    if not cursor:close() then
	        trace('FAILED TO CLOSE CURSOR')
	    end

	    if not connection:close() then
	        trace('FAILED TO CLOSE SQLITE CONNECTION')
	    end

	    if not env:close() then
	        trace('FAILED TO CLOSE SQLITE ENVIRONMENT')
	    end

	end

	if #mnemonics > 0 then
		local mnemonicDetails = DataTable.getMnemonicDetails(mnemonics)
		if mnemonicDetails then
			result, errorMsg = DataTable.getVarDescription(mnemonicDetails)
			if result ~= nil then
				for i=1, #result do
					local address = tostring(result[i].address)
					if type(result[i].address) == "number" then
						local mnemonic = DataTable.findMemonic(mnemonicDetails, result[i].address)
						if mnemonic then
							result[i].id = mnemonic.mnemonic
							result[i].mnemonic = mnemonic.mnemonic
							if (result[i].type == 0 or result[i].type == 4) then
								result[i].options = gf.filterOptionsList(mnemonic.options, result[i].possibleValues)
								result[i].listdef = ParametersTable.listparam[mnemonic.mnemonic]
								result[i].possibleValues = nil
							end
							result[i].safety = DataTable.getSafetyMessage(result[i].id)
						end
					end
				end
			else
				result = nil
				if not errorMsg then
					errorMsg = ErrorCodes.INVALID_REQUEST
				end
			end
		end
	end
    return result, errorMsg
end

function DataTable.getSafetyMessage(id)
	if (ParametersTable ~= nil and ParametersTable.safety ~= nil) then
		local safety = ParametersTable.safety[id]
		return safety
	else
		return nil
	end
end

function DataTable.getMnemonicDetails(mnemonics)
	local result = {}
	if ParametersTable ~= nil then
		local parameterList = ParametersTable.parameterlist
		local listParam = ParametersTable.listparam
		local listDef = ParametersTable.listdef

		for i=1, #mnemonics do
			local mnemonic = mnemonics[i]
			local address = parameterList[mnemonic]
			local options = listDef[listParam[mnemonic]]
			table.insert(result, {
				mnemonic = mnemonic,
				address = tonumber(address),
				options = options
			})
		end
	end
	return result
end

function DataTable.getParamTable(tableName)
	local result, errMsg = {}, nil
	if tableName == 'simply_start' then tableName = 'simplystart' end
	
	if ParametersTable ~= nil then
		local mnemonics = ParametersTable[tableName]

		if mnemonics == nil then
			result, errMsg = nil, ErrorCodes.INVALID_REQUEST
		else
			result = DataTable.getMnemonicDetails(mnemonics)
		end
	end
	return result, errMsg
end

function DataTable.getJsonTable(tableName)
	local result = {}
	tableName = tableName:lower()
	local parmTable, errMsg = DataTable.getParamTable(tableName)
	if parmTable then
		result, errMsg = DataTable.getVarDescription(parmTable)
		if result then
			for i=1, #result do
				if result[i].address then
					local mnemonic = DataTable.findMemonic(parmTable, result[i].address)
					if mnemonic then
						result[i].mnemonic = mnemonic.mnemonic
						if (result[i].type == 0 or result[i].type == 4) then
							result[i].options = gf.filterOptionsList(mnemonic.options, result[i].possibleValues)
							result[i].listdef = ParametersTable.listparam[mnemonic.mnemonic]
							result[i].possibleValues = nil
						end
						result[i].id = result[i].mnemonic -- Required for dashboard (looks for IDs for unified polling mechanism)
						result[i].safety = DataTable.getSafetyMessage(result[i].id)
					end
				end
			end
		end
	end
    return result, errMsg
end

function DataTable.findMemonic(paramTable, address)
	for j=1, #paramTable do
		if paramTable[j].address == address then
			return paramTable[j]
		end
	end
	return nil
end

function DataTable.getVarDescription(result)
	-- TODO: Type checking
	-- Generate request payload
	local unitID = 248
	local addresses = {}

	-- Build array of addresses
	for k,v in pairs(result) do
		table.insert(addresses, v.address)
	end

	-- Perform ADL request
	local result, errorMsg = ADL.GetParamsDescription(unitID, addresses)
	return result, errorMsg
end
-- Grab the value for each addressed variable using modbus
-- Variable.getVarValues is for Monitoring->Datatables...
-- This version is for Setup->Datatables...
function DataTable.getVarValues(variables)
    local result, errorMsg = {}, nil
    if ParametersTable ~= nil then
	    for i=1, #variables do
	    	local variable = {
	            id = variables[i].mnemonic,
	            address = ParametersTable.parameterlist[variables[i].mnemonic],
	            mnemonic = variables[i].mnemonic,
	            options = ParametersTable.listdef[ParametersTable.listparam[variables[i].mnemonic]],
	            listdef = ParametersTable.listparam[variables[i].mnemonic]
	        }
	        table.insert(result, variable)
	    end
	end
	return result, errorMsg
end

function DataTable.addVariablesToTable(variables, tableName)
	if luasql == nil then
		return false, ErrorCodes.NO_SQL -- ONLY FOR THE NOSQL VERSION
	end

	local result = false
	local errorMsg = nil
	-- Check input types
    if (type(tableName) ~= 'string') or (type(variables) ~= 'table') then
        return result, ErrorCodes.INVALID_REQUEST
    end
	-- Check to make sure variables and tableName are the correct length
	if #variables < Constants.MIN_NUM_VARS_PER_TABLE or #variables > Constants.MAX_NUM_VARS_PER_TABLE then
        return result, ErrorObject.new(ErrorCodes.NUM_DATATABLE_VARS_OUT_OF_RANGE, '', nil, HTTPStatusCode.BadRequest)

	elseif tableName:len() < Constants.MIN_TABLE_NAME_LENGTH
		or tableName:len() > Constants.MAX_TABLE_NAME_LENGTH then
		return result, ErrorCodes.INVALID_TABLE_NAME_LENGTH
	end
	-- There should be at least 1 variable being added
	if #variables > 0 then
		local env = luasql.sqlite()
		local connection = env:connect(Constants.DB_PATH)
		local isLockAcquired = connection:setautocommit('IMMEDIATE', 1000)

		if isLockAcquired then
			-- Check to make sure that the table actually exists
			local tableExists = false

			tableExists, errorMsg = DataTable.exists(connection, tableName)

			-- Ensure that the table exists that the variables are being added to
			if tableExists then
				local varsExist = nil
				-- Ensure that the variables exist in the namespace that are being added to the table
				varsExist, errorMsg = Variable.variablesExist(connection, variables)
				if varsExist then
					local numVarsExisting = 0
					numVarsExisting, errorMsg =
						DataTable.getNumberOfVariablesInTable(connection, tableName)
					if not errorMsg then
						local cursor = nil
						local maxVarsToAdd = Constants.MAX_NUM_VARS_PER_TABLE + 1 - numVarsExisting
						for el,var in pairs(variables) do
							--We support up to 120 variables per table
							if(el < maxVarsToAdd) then
								cursor = connection:prepare(
									[[INSERT INTO data_table_variable (mnemonic, table_name)
									VALUES (?, ?)]])
								cursor:bind{
									{'TEXT', var.mnemonic},
									{'TEXT', tableName}
								}
								local varsAdded = cursor:execute()
							else
								break
							end
						end

						-- Commit the transaction
						if connection:commit() then
							result = true
						else
							errorMsg = ErrorCodes.COMMIT_FAIL
						end

						-- Close cursor connection
						if not cursor:close() then
							trace('FAILED TO CLOSE CURSOR')
						end
					end
				elseif not varsExist and not errorMsg then
					errorMsg = ErrorCodes.VARS_DO_NOT_EXIST
				end
			elseif not tableExists and not errorMsg then
				errorMsg = ErrorCodes.TABLE_DOES_NOT_EXIST
			end
		else
			errorMsg = ErrorCodes.LOCK_FAIL
		end
		-- Clean up
		if not connection:close() then
			trace('FAILED TO CLOSE SQLITE CONNECTION')
		end
		if not env:close() then
			trace('FAILED TO CLOSE SQLITE ENVIRONMENT')
		end
	else
		--No variables to add...
	end
	return result, errorMsg
end

function DataTable.deleteVariables(variables, tableName)
	if luasql == nil then
		return false, ErrorCodes.NO_SQL -- ONLY FOR THE NOSQL VERSION
	end

	local result = false
	local errorMsg = nil

	-- Check input types
    if (type(tableName) ~= 'string') or (type(variables) ~= 'table') then
        return result, ErrorCodes.INVALID_REQUEST
    end
	-- Check to make sure variables and tableName are the correct length
	if #variables < 0 then
		return result, ErrorCodes.INVALID_REQUEST
	elseif tableName:len() < Constants.MIN_TABLE_NAME_LENGTH
		or tableName:len() > Constants.MAX_TABLE_NAME_LENGTH then
		return result, ErrorCodes.INVALID_TABLE_NAME_LENGTH
	end

	local env = luasql.sqlite()
	if env ~= nil then
		local connection = env:connect(Constants.DB_PATH)
		if connection ~= nil then
			local isLockAcquired = connection:setautocommit('IMMEDIATE', 1000)
			if isLockAcquired then
				-- Check to make sure that the table actually exists
				local tableExists = false
				tableExists, errorMsg = DataTable.exists(connection, tableName)
				if tableExists then
					local statement = 'DELETE FROM data_table_variable WHERE ('
					local ctr = 0;
					local numVars = #variables
					--Loop to build statement
					for el,var in pairs(variables) do
						ctr = ctr + 1
						statement = statement .. ' mnemonic = ( ? )'
						if ctr < numVars then
							statement = statement .. ' OR'
						end
					end
					statement = statement .. ') AND table_name = ( ? )'

					local cursor = connection:prepare(statement)
					if cursor ~= nil then
						local bindings = {}
						local temp = {}

						for el,var in pairs(variables) do
							temp = {'TEXT', var.id}
							table.insert(bindings,temp)
						end
						table.insert(bindings,{'TEXT',tableName})

						cursor:bind( bindings )
						local exec = cursor:execute()

						if exec then
							-- Commit the transaction
							if connection:commit() then
								result = true
							else
								errorMsg = ErrorCodes.COMMIT_FAIL
							end
						else
							errorMsg = ErrorCodes.DELETE_VARS_FAILED
						end
						-- Close cursor connection
						if not cursor:close() then
							trace('FAILED TO CLOSE CURSOR')
						end
					else
						trace('Failed to utilize sqlite cursor')
					end
				elseif not tableExists and not errorMsg then
					errorMsg = ErrorCodes.TABLE_DOES_NOT_EXIST
				end
			else
				errorMsg = ErrorCodes.LOCK_FAIL
			end
			-- Clean up
			if not connection:close() then
				trace('FAILED TO CLOSE SQLITE CONNECTION')
			end
		else
			trace('Failed to open SQLITE Connection')
		end
		if not env:close() then
			trace('FAILED TO CLOSE SQLITE ENVIRONMENT')
		end
	else
		trace('Failed to open luasql.sqlite()')
	end
	return result, errorMsg
end

return DataTable