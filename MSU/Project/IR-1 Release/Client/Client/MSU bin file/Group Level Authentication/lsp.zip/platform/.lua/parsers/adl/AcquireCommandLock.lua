-- UMAS : Read Multiple BOL

local AcquireCommandLock = {}

function AcquireCommandLock.isValidInput(input)
    if type(input) ~= 'table' then
        return false
    end

    if type(input.sessionID) ~= 'number' then
       return false
    end

    -- Valid variables
    return true
end

function AcquireCommandLock.getData(input)
    local result, data, errorMsg = nil, nil, nil

    -- Check input validity
    if AcquireCommandLock.isValidInput(input) then

        if LuaADL and not _G.forceSimulation then
            -- Perform Request
            data, errorMsg = LuaADL.Lock(Constants.DRIVE_UNIT_ID, input.sessionID)
        else
            data, errorMsg = AcquireCommandLock.getSimulationData()
        end

        if AcquireCommandLock.isValidResponse(data) then
            result = AcquireCommandLock.generateServiceResponse(data, variables)
        end
    else
        errorMsg = ErrorCodes.INVALID_REQUEST
    end

    --Return variable data with values
    return result, errorMsg
end

function AcquireCommandLock.isValidResponse(data)
    return type(data) == 'boolean'
end

function AcquireCommandLock.generateServiceResponse(resp)
    return {success = resp}
end

function AcquireCommandLock.getSimulationData(obj)
    return true
end

return AcquireCommandLock