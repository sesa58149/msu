-- Instanciate the modbus client

-- Instanciate the new object
local FC8220x04 = {}

-- Send the modbus request and parse the result
function FC8220x04.fetch()
    local data = nil
    if LuaModBus then
        data = LuaModBus.DiagnosticsData( 22, 1, {4, 0, 0} )
    end

    if not data then
        data = {
            22,0,1,4,0,0,0,38,0,7,                       -- Diag header (Connection Table Validity?)
            0,2,                                         -- Number of Entries (NE)
            0,0,                                         -- Starting Entry Index (SE) ???
            0,0,192,168,0,1,215,111,246,1,0,0,0,12,0,1,     -- Connection Table Entry 1
            1,0,192,168,0,1,40,243,246,1,249,0,250,12,20,30   -- Connection Table Entry 2

            --22,0,                                      -- Diag header (Connection Table Validity?)
            --0,2,                                       -- Number of Entries (NE)
            --0,1,                                       -- Starting Entry Index (SE) ???
            --1,3,5,1,3,1,2,4,2,1,2,4,5,6,7,8,           -- Connection Table Entry 1
            --1,3,0,4,3,5,1,3,1,1,8,9,6,5,5,3,           -- Connection Table Entry 2
        }
    end

    return FC8220x04.parse(data)
end

-- Parse the result
function FC8220x04.parse(data)
    local result = {}
    local c = 1
    local field = 0

    result["diagnostic_header"] = Utils.convertBytesToInt32(
        data[c],
        data[c+1],
        data[c+2],
        data[c+3]
    );

    c = c + 10

    result["number_of_entries"] = Utils.convertBytesToInt16(
        data[c],
        data[c+1]
    );

    c = c + 2

    result["starting_entry_index"] = Utils.convertBytesToInt16(
        data[c],
        data[c+1]
    );
    c = c + 2

    local i = 0
    local tempCnxn
    result.connections = {}
    while i < result["number_of_entries"] do
        --if (Utils.convertBytesToInt16( data[c+1], data[c+0]) ~= 0) then
            tempCnxn = {}
            tempCnxn.connectionIndex = Utils.convertBytesToInt16( data[c+1], data[c] )
            tempCnxn.remoteAddress = Utils.convertBytesToAddress( data[c+2], data[c+3], data[c+4], data[c+5] )
            tempCnxn.remotePort = Utils.convertBytesToInt16( data[c+6], data[c+7] )
            tempCnxn.localPort = Utils.convertBytesToInt16( data[c+8], data[c+9] )
            tempCnxn.messagesSent = Utils.convertBytesToInt16( data[c+10], data[c+11] )
            tempCnxn.messagesReceived = Utils.convertBytesToInt16( data[c+12], data[c+13] )
            tempCnxn.errors = Utils.convertBytesToInt16( data[c+14], data[c+15] )
            tempCnxn.id = tostring(tempCnxn.remoteAddress) .. ":" .. tostring(tempCnxn.localPort) .. ":" .. tostring(tempCnxn.remotePort)
            -- An entry is 16 bytes long...
            -- Don't return the loopback address
            if (tempCnxn.remoteAddress ~= '127.0.0.1') then
                table.insert(result.connections, tempCnxn)
            end
        --end

        i = i + 1
        c = c + 16
    end

    return result
end
return FC8220x04
