local fd = ba.openio(_G.diskIOName)
local MultiPart = fd:dofile('platform/.lua/MultiPart.lua')

MultiPart.pathDrive = nil
MultiPart.io = nil
MultiPart.errorMsg = nil
MultiPart.file = nil
MultiPart.pathLocal = nil
MultiPart.useWebRoot = false

local cbFunctions = {}

function cbFunctions.formdata(name, value)
end

function cbFunctions.beginfile(name, filename, contenttype, transferencoding)
    -- Clear previous error messages if there was one
    MultiPart.errorMsg = nil
    --Create File with the filename
    local io
    if MultiPart.useWebRoot then
        io = ba.openio(_G.diskIOName)
        MultiPart.useWebRoot = false -- reset
    else
        local tempIO = FileSystem.getIO((MultiPart.pathDrive ~= nil))
        if tempIO ~= nil then
            io = ba.openio(tempIO)
        end
    end

    if io then --Drive
        MultiPart.file = io:open(MultiPart.pathLocal, 'w+b')
        MultiPart.io = io
    else
        MultiPart.file, MultiPart.errorMsg = gf.openFileDrive(MultiPart.pathDrive, 1)
    end
    if not MultiPart.file then
        MultiPart.errorMsg = ErrorCodes.FAILED_TO_CREATE_FILE_DURING_UPLOAD
        return false
    end
end

function cbFunctions.filedata(data)
    -- Write data into the file
    if (MultiPart.io) then
        (MultiPart.file):write(data)
    else --Drive
        local result, errorMsg = gf.writeFileDrive(MultiPart.file, data)
        if (not result and errorMsg ~= nil) then
            trace('Error Write')
            MultiPart.errorMsg = errorMsg
        end
    end
    -- No return otherwise commit the request
end

function cbFunctions.endmp()
    -- Close the file
    if (MultiPart.io) then --Drive
        (MultiPart.file):close()
    else
        local result, errMsg = gf.closeFileDrive(MultiPart.file)
        if (not result) then
            trace('Error Close')
            MultiPart.errorMsg = errMsg
        end
    end
    return true
end

function cbFunctions.error(emsg)
    MultiPart.useWebRoot = false
    if (MultiPart.io) then
        (MultiPart.file):close()
    else
        gf.closeFileDrive(MultiPart.file)
    end
    if emsg then
        MultiPart.errorMsg = emsg
        response:setcontenttype('application/json; charset=UTF-8')
        response:write(MultiPart.errorMsg:get_JSON())
    end
    return false
end

-- Only function visible to the outside world
function MultiPart.start(_ENV, paths, bufferSize, keepAlive)
    MultiPart.pathLocal = paths.pathLocal
    MultiPart.pathDrive = paths.pathDrive
    if type(bufferSize) == "number" then
        request:multipart(cbFunctions, bufferSize, keepAlive)
    else
        keepAlive = bufferSize
        request:multipart(cbFunctions, keepAlive)
    end
end

return MultiPart