local FC8220x01 = {}

-- Send the modbus request and parse the result
function FC8220x01.fetch()
    local data = nil
    if LuaModBus then
        data = LuaModBus.DiagnosticsData(22, 1, {1, 0, 0}) -- checked OK
    end

    if not data then
        data = {
            22,0,0,0,                            -- Diag header
            0,0,0,0,                             -- Diag Validity
            0,0,                                 -- Global Status
            1,0,                                 -- Supported TR services
            0,0,                                 -- Status of TR services
            10,1,2,3,                            -- IP Address
            255,255,255,0,                       -- Subnet mask
            10,1,2,254,                          -- Gateway
            0,17,0,19,128,160,                   -- MAC
            0,0,                                 -- Ethernet Frame Format Capability
            0,0,0,255,                           -- Ethernet Rcv Frame OK
            0,0,0,255,                           -- Ethernet Transmit Frame OK
            0,0,                                 -- Num Open Client Conn
            0,0,                                 -- Num Open Server Conn
            0,0,0,12,                            -- Num MB Error Msgs Sent
            0,0,2,2,                             -- Num MB Msgs Sent
            0,0,12,123,                          -- Num MB Msgs Rcvd
            65,66,67,68,0,0,0,0,0,0,0,0,0,0,0,0, -- FDR Device Name
            0,0,                                 -- FDR Device Param Status
            192,168,44,1,                        -- FDR Device IP Address
            0,0,                                 -- FDR Device IP Address Assignment Mode
            0,0                                  -- FDR Error code
        }
    end

    return FC8220x01.parse(data)
end

-- Parse the result
function FC8220x01.parse(data)
    local result = {}
    local c = 9
    local field = 0

    --result["diagnostic_header"] = chart.convertBytesToInt32(
    --    data[c],
    --    data[c+1],
    --    data[c+2],
    --    data[c+3]
    --)
    --c = c + 11

    result.validity = Utils.convertBytesToInt32(
        data[c],
        data[c+1],
        data[c+2],
        data[c+3]
    )
    c = c + 4

    local validity = result.validity

    if(bit32.extract(validity, 17, 1) == 1) then
        result["global_status"] = Utils.convertBytesToInt16(
            data[c],
            data[c+1]
        )
        c = c + 2
    end

    if(bit32.extract(validity, 16, 1) == 1) then
        field = bit32.bor( -- Concatenates the two bytes to use masks
            bit32.lrotate(data[c  ], 8*1),
            bit32.lrotate(data[c+1], 8*0)
        )
        result["supp_TR_services"] = {
            ["FE" ] = (bit32.extract(field, 0 , 1) == 1),
            ["502"] = (bit32.extract(field, 1 , 1) == 1),
            ["IOS"] = (bit32.extract(field, 2 , 1) == 1),
            ["GD" ] = (bit32.extract(field, 3 , 1) == 1),
            ["WEB"] = (bit32.extract(field, 4 , 1) == 1),
            ["AS" ] = (bit32.extract(field, 5 , 1) == 1),
            ["TM" ] = (bit32.extract(field, 6 , 1) == 1),
            ["EM" ] = (bit32.extract(field, 7 , 1) == 1),
            ["FC" ] = (bit32.extract(field, 8 , 1) == 1),
            ["FS" ] = (bit32.extract(field, 9 , 1) == 1),
            ["BW" ] = (bit32.extract(field, 10, 1) == 1),
            ["SN" ] = (bit32.extract(field, 11, 1) == 1)
        }
        c = c + 2
    end

    if(bit32.extract(validity, 14, 1) == 1) then
        field = bit32.bor( -- Concatenates the two bytes to use masks
            bit32.lrotate(data[c  ], 8*1),
            bit32.lrotate(data[c+1], 8*0)
        )
        -- result["status_TR_services"] = {
        --     --["FE" ] = (bit32.extract(field, 0, 1) == 1),
        --     ["502"] = (
        --         bit32.btest(bit32.extract(field, 1, 3), 0x1) and "IDLE"        or
        --         bit32.btest(bit32.extract(field, 1, 3), 0x2) and "OPERATIONAL" or "???"
        --     ),
        --     ["IOS"] = (
        --         bit32.btest(bit32.extract(field, 4, 3), 0x1) and "IDLE"        or
        --         bit32.btest(bit32.extract(field, 4, 3), 0x2) and "OPERATIONAL" or
        --         bit32.btest(bit32.extract(field, 4, 3), 0x3) and "STOPPED"     or "???"
        --     ),
        --     ["GD"] = (
        --         bit32.btest(bit32.extract(field, 7, 3), 0x1) and "IDLE"        or
        --         bit32.btest(bit32.extract(field, 7, 3), 0x2) and "OPERATIONAL" or
        --         bit32.btest(bit32.extract(field, 7, 3), 0x3) and "STOPPED"     or "???"
        --     ),
        --     ["WEB"] = (
        --         bit32.btest(bit32.extract(field, 10, 3), 0x1) and "IDLE"        or
        --         bit32.btest(bit32.extract(field, 10, 3), 0x2) and "OPERATIONAL" or "???"
        --     ),
        --     ["AS"] = (
        --         bit32.btest(bit32.extract(field, 13, 3), 0x1) and "IDLE"        or
        --         bit32.btest(bit32.extract(field, 13, 3), 0x2) and "OPERATIONAL" or "???"
        --     ),
        --     ["TM"] = (
        --         "???" -- not defined in the doc
        --     ),
        --     ["EM"] = (
        --         bit32.btest(bit32.extract(field, 20, 3), 0x1) and "IDLE"        or
        --         bit32.btest(bit32.extract(field, 20, 3), 0x2) and "OPERATIONAL" or
        --         bit32.btest(bit32.extract(field, 20, 3), 0x3) and "STOPPED"     or "???"
        --     ),
        --     ["FC"] = (
        --         bit32.btest(bit32.extract(field, 23, 3), 0x0) and "INIT"          or
        --         bit32.btest(bit32.extract(field, 23, 3), 0x2) and "OPERATIONAL"   or
        --         bit32.btest(bit32.extract(field, 23, 3), 0x4) and "READY"         or
        --         bit32.btest(bit32.extract(field, 23, 3), 0x5) and "IP CONFIGURED" or -- 101
        --         bit32.btest(bit32.extract(field, 23, 3), 0x6) and "FALL BACK"     or -- 110
        --         bit32.btest(bit32.extract(field, 23, 3), 0x7) and "UNCONFIGURED"  or -- 111
        --         "???"
        --     ),
        --     ["FS"] = (
        --         bit32.btest(bit32.extract(field, 26, 3), 0x1) and "IDLE"        or
        --         bit32.btest(bit32.extract(field, 26, 3), 0x2) and "OPERATIONAL" or "???"
        --     ),
        --     ["SN"] = (
        --         bit32.btest(bit32.extract(field, 29, 3), 0x1) and "IDLE"        or
        --         bit32.btest(bit32.extract(field, 29, 3), 0x2) and "OPERATIONAL" or "???"
        --     )
        -- }
        c = c + 2
    end

    if(bit32.extract(validity, 13, 1) == 1) then
        result["IP_address"] = Utils.convertBytesToAddress(
            data[c],
            data[c+1],
            data[c+2],
            data[c+3]
        )
        c = c + 4
    end

    if(bit32.extract(validity, 12, 1) == 1) then
        result["subnet_mask"] = Utils.convertBytesToAddress(
            data[c],
            data[c+1],
            data[c+2],
            data[c+3]
        )
        c = c + 4
    end

    if(bit32.extract(validity, 11, 1) == 1) then
        result["default_gateway"] = Utils.convertBytesToAddress(
            data[c],
            data[c+1],
            data[c+2],
            data[c+3]
        )
        c = c + 4
    end

    if(bit32.extract(validity, 10, 1) == 1) then
        result["MAC_address"] = Utils.convertBytesToMac({
            data[c],
            data[c+1],
            data[c+2],
            data[c+3],
            data[c+4],
            data[c+5]
        })
        c = c + 6
    end

    if(bit32.extract(validity, 9, 1) == 1) then
        --field = bit32.bor( -- Concatenates the two bytes to use masks
        --    bit32.lrotate(data[c  ], 8*1),
        --    bit32.lrotate(data[c+1], 8*0)
        --)
        --result["ether_frame_format"] = {
        --    ["ADC" ] = (bit32.extract(field, 0 , 1) == 1),
        --    ["82SC"] = (bit32.extract(field, 1 , 1) == 1),
        --    ["82RC"] = (bit32.extract(field, 2 , 1) == 1),
        --    ["E2C" ] = (bit32.extract(field, 3 , 1) == 1),
        --    ["ADG" ] = (bit32.extract(field, 4 , 1) == 1),
        --    ["82SG"] = (bit32.extract(field, 5 , 1) == 1),
        --    ["82RG"] = (bit32.extract(field, 6 , 1) == 1),
        --    ["E2G" ] = (bit32.extract(field, 7 , 1) == 1),
        --    ["ADO" ] = (bit32.extract(field, 12, 1) == 1),
        --    ["82SO"] = (bit32.extract(field, 13, 1) == 1),
        --    ["82RO"] = (bit32.extract(field, 14, 1) == 1),
        --    ["E2O" ] = (bit32.extract(field, 15, 1) == 1)
        --}
        c = c + 6
    end

    if(bit32.extract(validity, 8, 1) == 1) then
        result["ether_rcv_frames_ok"] = Utils.convertBytesToInt32(
    		data[c], data[c+1], data[c+2], data[c+3]
    	)
        c = c + 4
    end

    if(bit32.extract(validity, 7, 1) == 1) then
        result["ether_xmit_frames_ok"] = Utils.convertBytesToInt32(
    		data[c], data[c+1], data[c+2], data[c+3]
    	)
        c = c + 4
    end

    if(bit32.extract(validity, 6, 1) == 1) then
        result["num_open_client_conn"] = Utils.convertBytesToInt16(
    		data[c], data[c+1]
    	)
        c = c + 2
    end

    if(bit32.extract(validity, 5, 1) == 1) then
        result["num_open_serv_conn"] = Utils.convertBytesToInt16(
    		data[c], data[c+1]
    	)
        c = c + 2
    end

    if(bit32.extract(validity, 4, 1) == 1) then
        result["num_MB_error_msgs_sent"] = Utils.convertBytesToInt32(
    		data[c], data[c+1], data[c+2], data[c+3]
    	)
        c = c + 4
    end

    if(bit32.extract(validity, 3, 1) == 1) then
        result["num_MB_msgs_sent"] = Utils.convertBytesToInt32(
    		data[c], data[c+1], data[c+2], data[c+3]
    	)
        c = c + 4
    end

    if(bit32.extract(validity, 2, 1) == 1) then
        result["num_MB_msgs_rcvd"] = Utils.convertBytesToInt32(
    		data[c], data[c+1], data[c+2], data[c+3]
    	)
        c = c + 4
    end

    if(bit32.extract(validity, 1, 1) == 1) then
        result["FDR_device_name"] = ""
        for i = 0, 15 do
            if data[c+i] ~= nil then
                result["FDR_device_name"] = result["FDR_device_name"] .. string.char(data[c+i])
            end
        end
        c = c + 16
    end
    --
    --field = bit32.bor( -- Concatenates the two bytes to use masks
    --    bit32.lrotate(data[c  ], 8*1),
    --    bit32.lrotate(data[c+1], 8*0)
    --)
    --result["FDR_device_params_status"] = {
    --    ["PSV"] = (
    --        bit32.btest(bit32.extract(field, 0, 1), 0x1) and "STORED_EQUAL_SERV_PARAMS" or
    --        "STORED_NOT_EQUAL_SERV_PARAMS"
    --    ),
    --    ["DEVICE_CURR_PARAMS_STATUS"] = (
    --        bit32.btest(bit32.extract(field, 8, 3), 0x1) and "DEFAULT" or
    --        bit32.btest(bit32.extract(field, 8, 3), 0x2) and "FDR_SERV" or
    --        bit32.btest(bit32.extract(field, 8, 3), 0x4) and "STORED" or
    --        "???"
    --    )
    --}
    --c = c + 2
    --
    --result["FDR_IP_address"] = Utils.convertBytesToAddress(
    --    data[c],
    --    data[c+1],
    --    data[c+2],
    --    data[c+3]
    --);
    --c = c + 4
    --
    --field = bit32.bor(
    --    bit32.lrotate(data[c  ], 8*1),
    --    bit32.lrotate(data[c+1], 8*0)
    --)
    --result["FDR_ERROR_CODE"] = field
    --c = c + 2

    return result
end
return FC8220x01
