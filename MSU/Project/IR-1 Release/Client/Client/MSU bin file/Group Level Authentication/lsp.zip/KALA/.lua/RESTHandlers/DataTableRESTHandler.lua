local io = ba.openio(_G.diskIOName)
local DataTableRESTHandler = io:dofile('platform/.lua/RESTHandlers/DataTableRESTHandler.lua')

-- Override for KALA
function DataTableRESTHandler.getTableInfo(tableName)
    local tableData, errorMsg = DataTable.getTableInfo(tableName)
    if tableData then
        return ba.json.encode(tableData), nil
    else
        return nil, errorMsg
    end
end

return DataTableRESTHandler