--TODO if the file don't exist in ram, let's load a default file from disk that we know is there
--the addresses might be incorrect in the default file...
local WebConfJSON = gf.readFile( Constants.WEBCONFPATH, "ram" )
WebConfConstants = false
IsAdvanced = false
if WebConfJSON ~= nil then
    WebConfConstants = ba.json.decode( WebConfJSON )
    if (WebConfConstants.FEATURES.SWITCH_CONTROL.NUMREGS == 7) then
        IsAdvanced = true
    end
else
    trace( 'Unable To Open "' .. Constants.WEBCONFPATH .. '" file. Now tying to use JSON from web server.')
    WebConfJSON = gf.readFile( ".webconf.json", "webram" )
    if WebConfJSON ~= nil then
        WebConfConstants = ba.json.decode( WebConfJSON )
    else
        trace( 'Unable To Open .webconf.json file from web server.')
    end
end

local Network = {}

function Network.getIOScan()
    local obj = {
        modbus_enable=true,
        eip_control=true,
        distributed_io_enable=true,
        ip_address_management='IPAM_AND_FDR_ENABLE'
    }
    return obj, false
end

function Network.setIOScan(data)
    return false, ErrorCodes.NOT_IMPLEMENTED
end

function Network.addressConversion(addr)
    --Find ':', v6. Otherwise, v4.
    if addr ~= nil and string.len(addr) > 0 then
        if not addr:match(':') then
            addr = Utils.convertHexIP(addr)
        end
    else
        addr = ''
    end
    return addr
end

function Network.getTCPIP()
    local result, errorMsg, temp = {}, nil, nil
    local ip, subnet, gateway, deviceName = nil, nil, nil, nil
    if LuaModBus then
        -- Address assignments --------------------------------------------------------------
        temp = LuaModBus.ReadMultipleRegisters(Constants.MULTI_REG_DEVICE_ID, WebConfConstants.FEATURES.DUAL_IP.STARTREG, WebConfConstants.FEATURES.DUAL_IP.NUMREGS)
        collectgarbage('collect')
        if not temp then return nil, ErrorCodes.MODBUS_READ_FAILED end
        --Make sure it is the correct size:
        if #temp < WebConfConstants.FEATURES.DUAL_IP.NUMREGS then
            return nil, ErrorCodes.INCORRECT_NUMBER_OF_REGS
        end

        temp = gf.removeElements(temp, 3)

        --V4 subnet mask #1
        local sub1 = Utils.convertRegistersToInt32(temp[1], temp[2])
        if (sub1 ~= 0) then
            table.insert(result, Utils.convertRegistersToAddress(temp[1], temp[2]))
        else
            table.insert(result, '')
        end
        --V4 subnet mask #2
        local sub2 = Utils.convertRegistersToInt32(temp[3], temp[4])
        if(sub2 ~= 0) then
            table.insert(result, Utils.convertRegistersToAddress(temp[3], temp[4]))
        else
            table.insert(result, '')
        end

        --gateway #1
        local gatewayOne = Utils.convertRegistersToAscii(temp, 5, 32)
       -- gatewayOne = Network.addressConversion(gatewayOne)
        table.insert(result, gatewayOne)

        --gateway #2
        local gatewayTwo = Utils.convertRegistersToAscii(temp, 37, 32)
       -- gatewayTwo = Network.addressConversion(gatewayTwo)
        table.insert(result, gatewayTwo)

        --ip address #1
        local ipAddr = Utils.convertRegistersToAscii(temp, 69, 20)
        --ipAddr = Network.addressConversion(ipAddr)
        table.insert(result, ipAddr)

        temp = nil

        -- Device Name v2 -----------------------------------------------------------------------------
        temp = LuaModBus.ReadMultipleRegisters(Constants.MULTI_REG_DEVICE_ID, WebConfConstants.FEATURES.DEVICE_NAME2.STARTREG, WebConfConstants.FEATURES.DEVICE_NAME2.NUMREGS)
        collectgarbage('collect')
        if not temp then return nil, ErrorCodes.MODBUS_READ_FAILED end
        --Make sure it is the correct size:
        if #temp < WebConfConstants.FEATURES.DEVICE_NAME2.NUMREGS then
            return nil, ErrorCodes.INCORRECT_NUMBER_OF_REGS
        end

        table.insert(result, Utils.convertRegistersToAscii(temp, 1, 32))

        temp = nil

        -- IP Address Assignment Mode ------------------------------------------------------------------
        temp = LuaModBus.ReadMultipleRegisters(Constants.MULTI_REG_DEVICE_ID, WebConfConstants.FEATURES.IPAM.STARTREG , WebConfConstants.FEATURES.IPAM.NUMREGS)
        collectgarbage('collect')
        if not temp then return nil, ErrorCodes.MODBUS_READ_FAILED end
        --Make sure it is the correct size:
        if #temp < WebConfConstants.FEATURES.IPAM.NUMREGS then
            return nil, ErrorCodes.INCORRECT_NUMBER_OF_REGS
        end

        table.insert(result, bit32.extract(temp[1], 2, 2))               --IP Address Assignment

        temp = nil
    else
        result = {
            "255.255.255.0", --subnet
            "255.255.255.0", --subnet2  
            "192.168.1.1", --gateway
            "192.168.1.1",  --gateway2
            "192.168.1.100", --ip
            "KALA", --deviceName
            0 --ipAddrAssign
        }
    end
    return result, errorMsg
end

function Network.getMasterIP(data)

    local result, errorMsg = {}, nil
    if LuaModBus then
        -- Address assignments --------------------------------------------------------------
        temp = LuaModBus.ReadMultipleRegisters(Constants.MULTI_REG_DEVICE_ID, WebConfConstants.FEATURES.MASTER_IP.STARTREG, WebConfConstants.FEATURES.MASTER_IP.NUMREGS)
        collectgarbage('collect')
        if not temp then return nil, ErrorCodes.MODBUS_READ_FAILED end
        --Make sure it is the correct size:
        if #temp < WebConfConstants.FEATURES.MASTER_IP.NUMREGS then
            return nil, ErrorCodes.INCORRECT_NUMBER_OF_REGS
        end


        --V4 IP Master #1
        local masterIP1 = Utils.convertRegistersToInt32(temp[4], temp[5])
        if (masterIP1 ~= 0) then
            table.insert(result, Utils.convertRegistersToAddress(temp[4], temp[5]))
        else
            table.insert(result, '')
        end

        --V4 IP Master #2
        local masterIP2 = Utils.convertRegistersToInt32(temp[6], temp[7])
        if (masterIP2 ~= 0) then
            table.insert(result, Utils.convertRegistersToAddress(temp[6], temp[7]))
        else
            table.insert(result, '')
        end

        --V4 IP Master #3
        local masterIP3 = Utils.convertRegistersToInt32(temp[8], temp[9])
        if (masterIP3 ~= 0) then
            table.insert(result, Utils.convertRegistersToAddress(temp[8], temp[9]))
        else
            table.insert(result, '')
        end

        --Reservation Time
        table.insert(result, temp[1])
        --Holdup Time
        table.insert(result, temp[2])
        --Link Failure MOde
        table.insert(result, temp[3])
        temp = nil
    else
        result = {
            "192.168.1.100",
            "192.168.1.100",
            "192.168.1.100",
            "300",
            "26",
            "75"
        }
    end
    return result, errorMsg
end

function Network.setMasterIP(data)
    --local result, errorMsg, temp = true, nil, nil
        if data.masterIP1 == '' or gf.validateIP(data.masterIP1) ~= 0 then
            if data.masterIP2 == '' or gf.validateIP(data.masterIP2) ~= 0 then
                if data.masterIP3 == '' or gf.validateIP(data.masterIP3) ~=0 then
                    if LuaModBus then
                        local regArr = LuaModBus.ReadMultipleRegisters(Constants.MULTI_REG_DEVICE_ID, WebConfConstants.FEATURES.MASTER_IP.STARTREG, WebConfConstants.FEATURES.MASTER_IP.NUMREGS)
                        collectgarbage('collect')
                        if not regArr then return nil, ErrorCodes.MODBUS_WRITE_FAILED end

                        if data.reservationTime then
                            regArr[1] = tonumber(data.reservationTime)
                        end

                        if data.holdupTime then
                            regArr[2] = tonumber(data.holdupTime)
                        end

                        if data.linkFailureMode then
                            regArr[3] = tonumber(data.linkFailureMode)
                        end

                        local currentPos = 3;

                        if gf.validateIP(data.masterIP1) == 1 then
                            if data.masterIP1:len() == 0 then
                                regArr[1+currentPos] = 0
                                regArr[2+currentPos] = 0
                            else
                                temp = Utils.ipv4AddressToWordArray(data.masterIP1)
                                for i = 1, #temp do
                                    regArr[i+currentPos] = temp[i]
                                end
                            end
                        else
                            temp = Utils.convertHexIP(data.masterIP1)
                                for i = 1, #temp do
                                    regArr[i+currentPos] = temp[i]
                                end
                        end
                        currentPos = currentPos + 2
                        if gf.validateIP(data.masterIP2) == 1 then
                            if data.masterIP2:len() == 0 then
                                regArr[1+currentPos] = 0
                                regArr[2+currentPos] = 0
                            else
                                temp = Utils.ipv4AddressToWordArray(data.masterIP2)
                                for i = 1, #temp do
                                    regArr[i+currentPos] = temp[i]
                                end
                            end
                        end

                        currentPos = currentPos + 2
                        if gf.validateIP(data.masterIP3) == 1 then
                            if data.masterIP3:len() == 0 then
                                regArr[1+currentPos] = 0
                                regArr[2+currentPos] = 0
                            else
                                temp = Utils.ipv4AddressToWordArray(data.masterIP3)
                                for i = 1, #temp do
                                    regArr[i+currentPos] = temp[i]
                                end
                            end
                        end

                        LuaModBus.WriteMultipleRegisters(Constants.MULTI_REG_DEVICE_ID, WebConfConstants.FEATURES.MASTER_IP.STARTREG, #regArr, regArr)
                        Network.setEndWrite()
                    else
                        errorMsg = ErrorCodes.NO_MODBUS_CONNECTION
                        result = false
                    end
                else
                    errorMsg = ErrorCodes.NO_MODBUS_CONNECTION
                        result = false
                end
            else
                errorMsg = ErrorCodes.NO_MODBUS_CONNECTION
                        result = false
            end
        else
            result = false
            errorMsg = 'BAD IP'
        end
            return result, errorMsg
end

function Network.getRateDuplex()
    local result, errorMsg = {}, nil
    if LuaModBus then
        -- Address assignments --------------------------------------------------------------
        local temp = LuaModBus.ReadMultipleRegisters(Constants.MULTI_REG_DEVICE_ID, WebConfConstants.FEATURES.SWITCH_CONTROL.STARTREG, WebConfConstants.FEATURES.SWITCH_CONTROL.NUMREGS)
        collectgarbage('collect')
        if not temp then return nil, ErrorCodes.MODBUS_READ_FAILED end
        --Make sure it is the correct size:
        if #temp < WebConfConstants.FEATURES.SWITCH_CONTROL.NUMREGS then
            return nil, ErrorCodes.INCORRECT_NUMBER_OF_REGS
        end
        --Get number
        local result = {}
        local number = temp[5]
        for i=1, number do
            local register = temp[5 + i]
            if register ~= nil then
                local speed = bit32.bor(bit32.lrotate(bit32.extract(register, 12, 2),2), bit32.lrotate(bit32.extract(register, 10, 2),0))
                table.insert(result, speed)    
            end 
        end
        --Speed (12-13)
        --01 = 10 Mbps
        --10 = 100 Mbps
        --11 = Auto negotiate
        --Duplex (10-11)
        --01 = Half-Duplex
        --10 = Full-Duplex
        --11 = Auto negotiate
        return result, errorMsg
    else
        return {15,10}, errorMsg
    end
end

function Network.setRateDuplex(data)
    if LuaModBus then
        -- Address assignments --------------------------------------------------------------
        local temp = LuaModBus.ReadMultipleRegisters(Constants.MULTI_REG_DEVICE_ID, WebConfConstants.FEATURES.SWITCH_CONTROL.STARTREG, WebConfConstants.FEATURES.SWITCH_CONTROL.NUMREGS)
        collectgarbage('collect')
        if not temp then return nil, ErrorCodes.MODBUS_READ_FAILED end
        --Make sure it is the correct size:
        if #temp < WebConfConstants.FEATURES.SWITCH_CONTROL.NUMREGS then
            return nil, ErrorCodes.INCORRECT_NUMBER_OF_REGS
        end
        local number = temp[5]
        -------- 4 bits ----------------
        -- Speed -- Duplex -- Dec Value
        -- 10    --  10        10
        -- 10        01        9
        -- 01        10        6
        -- 01        01        5
        -- 11        11        15

        local duplex = bit32.extract(data.port1, 0, 2)
        local speed = bit32.extract(data.port1, 2, 2)
        temp[6] = bit32.replace(temp[6], tonumber(duplex), 10, 2)
        temp[6] = bit32.replace(temp[6], tonumber(speed), 12, 2)
        if (tonumber(data.port1) == 15) then -- Auto-Nego
            temp[6] = bit32.replace(temp[6], tonumber(1), 9, 1)
        else
            temp[6] = bit32.replace(temp[6], tonumber(0), 9, 1)
        end
        if (number == 2) then --Advanced
            duplex = bit32.extract(data.port2, 0, 2)
            speed = bit32.extract(data.port2, 2, 2)
            temp[7] = bit32.replace(temp[7], tonumber(duplex), 10, 2)
            temp[7] = bit32.replace(temp[7], tonumber(speed), 12, 2)
            if (tonumber(data.port2) == 15) then -- Auto-Nego
                temp[7] = bit32.replace(temp[7], tonumber(1), 9, 1)
            else
                temp[7] = bit32.replace(temp[7], tonumber(0), 9, 1)
            end
        end

            --Write to the device
        LuaModBus.WriteMultipleRegisters(Constants.MULTI_REG_DEVICE_ID, WebConfConstants.FEATURES.SWITCH_CONTROL.STARTREG, #temp, temp)
    end

    return nil
end

function Network.getFDR()
    local result, errorMsg, temp = {}, nil, nil
    local ip, subnet, gateway, deviceName = nil, nil, nil, nil
    if LuaModBus then
         -- IP Sync data -------------------------------------------------------------------------------
        temp = LuaModBus.ReadMultipleRegisters(Constants.MULTI_REG_DEVICE_ID, WebConfConstants.FEATURES.FDR_2.STARTREG, WebConfConstants.FEATURES.FDR_2.NUMREGS)
        collectgarbage('collect')
        if not temp then return nil, ErrorCodes.MODBUS_READ_FAILED end
        --Make sure it is the correct size:
        if #temp < WebConfConstants.FEATURES.FDR_2.NUMREGS then
            return nil, ErrorCodes.INCORRECT_NUMBER_OF_REGS
        end
       -- table.insert(result, bit32.band(bit32.rshift(temp[1], 6), 1))              --Sync direction
        table.insert(result, bit32.band(bit32.rshift(temp[1], 5), 1))              --Configuration control
        table.insert(result, bit32.extract(temp[1], 2, 2))                         --Sync mode
        table.insert(result, temp[66] * 10)                                         --Sync cycle
        table.insert(result, bit32.band(bit32.rshift(temp[1], 8), 1))              --Fault brick down
        table.insert(result, bit32.band(bit32.rshift(temp[1], 15), 1))             --FDR Regular
        temp = nil
    else
        result = {
            0, --configControl
            2, --syncMode
            300, --autoSyncCheckCycleTime
            1, --faultBrickDown
            1 --FDRStatus
        }
    end
    return result, errorMsg
end

function Network.setFDR(data)
    local result, errorMsg, temp = true, nil, nil
    if LuaModBus then
        errorMsg = Network.setTCPSyncData(data)
        if errorMsg then return nil, errorMsg end
        --send event to write the config file after all write
        errorMsg = Network.setEndWrite()
     else
        errorMsg = ErrorCodes.NO_MODBUS_CONNECTION
        result = false
    end
    return result, errorMsg
end

function Network.setTCPIP(data)
    local result, errorMsg, temp = true, nil, nil
    if LuaModBus then
        errorMsg = Network.setdisabledFDR(data.ipAddrAssign)
        if errorMsg then return nil, errorMsg end
        errorMsg = Network.setTCPMode(data.ipAddrAssign)
        if errorMsg then return nil, errorMsg end
        errorMsg = Network.setTCPAddresses(data)
        if errorMsg then return nil, errorMsg end
        errorMsg = Network.setDeviceName(data.deviceName)
        if errorMsg then return nil, errorMsg end
        errorMsg = Network.setRateDuplex(data)
        --send event to write the config file after all write
        errorMsg = Network.setEndWrite()
    else
        errorMsg = ErrorCodes.NO_MODBUS_CONNECTION
        result = false
    end
    return result, errorMsg
end

function Network.setTCPMode(data)
    -- Create register array with current values
    local regArr = LuaModBus.ReadMultipleRegisters(Constants.MULTI_REG_DEVICE_ID, WebConfConstants.FEATURES.IPAM.STARTREG , WebConfConstants.FEATURES.IPAM.NUMREGS)
    collectgarbage('collect')
    if not regArr then return ErrorCodes.MODBUS_WRITE_FAILED end

    if data ~= nil then
        regArr[1] = bit32.replace(regArr[1], tonumber(data), 2, 2)
        regArr[1] = bit32.replace(regArr[1], 3, 0, 1)
    end

    --Write to the device
    LuaModBus.WriteMultipleRegisters(Constants.MULTI_REG_DEVICE_ID, WebConfConstants.FEATURES.IPAM.STARTREG, #regArr, regArr)

    return nil
end

function Network.setTCPSyncData(data)
    -- Create register array with current values
    local regArr = LuaModBus.ReadMultipleRegisters(Constants.MULTI_REG_DEVICE_ID, WebConfConstants.FEATURES.FDR_2.STARTREG, WebConfConstants.FEATURES.FDR_2.NUMREGS)
    collectgarbage('collect')
    if not regArr then return ErrorCodes.MODBUS_WRITE_FAILED end
    local currentPos = 1
    --write at 20
    if data.syncMode ~= nil and tonumber(data.syncMode) == 1 then
        regArr[currentPos] = bit32.replace(regArr[currentPos], tonumber(1), 6, 1) --SYD --Device to server only Automatic
    end

    if data.configControl ~= nil then
        regArr[currentPos] = bit32.replace(regArr[currentPos], tonumber(data.configControl), 5, 1) --UST
    end

    if data.syncMode ~= nil then
        regArr[currentPos] = bit32.replace(regArr[currentPos],  tonumber(data.syncMode), 2, 2) --SYM
    end
    --if data.faultBrickDown ~= nil then
    --    regArr[currentPos] = bit32.replace(regArr[currentPos], tonumber(data.faultBrickDown), 8, 1) --FBD
    --end
    if data.FDRStatus ~= nil then
        regArr[currentPos] = bit32.replace(regArr[currentPos], tonumber(data.FDRStatus), 15, 1) --FRE
    end   
    currentPos = currentPos + 64

    --65, write at 66
    currentPos = currentPos + 1
    if data.autoSyncCheckCycleTime ~= nil then
        regArr[currentPos] = math.ceil(tonumber(data.autoSyncCheckCycleTime) / 10)
    end
    --Write to the device
    LuaModBus.WriteMultipleRegisters(Constants.MULTI_REG_DEVICE_ID, WebConfConstants.FEATURES.FDR_2.STARTREG, #regArr, regArr)

    return nil
end

function Network.setdisabledFDR(data)
    --Static or Bootp 
    if (data ~= nil and (tonumber(data) == 1 or tonumber(data) == 2)) then
        -- Create register array with current values
        local regArr = LuaModBus.ReadMultipleRegisters(Constants.MULTI_REG_DEVICE_ID, WebConfConstants.FEATURES.FDR_2.STARTREG, WebConfConstants.FEATURES.FDR_2.NUMREGS)
        collectgarbage('collect')

        if not regArr then return ErrorCodes.MODBUS_WRITE_FAILED end

        local currentPos = 1
        regArr[currentPos] = bit32.replace(regArr[currentPos], 0, 15, 1) --FRE

            --Write to the device
        LuaModBus.WriteMultipleRegisters(Constants.MULTI_REG_DEVICE_ID, WebConfConstants.FEATURES.FDR_2.STARTREG, #regArr, regArr)
    end
    return nil
end

function Network.setTCPAddresses(data)
    local regArr = LuaModBus.ReadMultipleRegisters(Constants.MULTI_REG_DEVICE_ID, WebConfConstants.FEATURES.DUAL_IP.STARTREG, WebConfConstants.FEATURES.DUAL_IP.NUMREGS)
    collectgarbage('collect')
    if not regArr then return ErrorCodes.MODBUS_WRITE_FAILED end
    
    if tonumber(data.ipAddrAssign) == 1 then
        regArr[2] = bit32.replace(regArr[2], tonumber(1), 10, 1)
    end

    local currentPos = 3
    -- current pos 3, write 4
    if data.subnet and tonumber(data.ipAddrAssign) == 1 then
        regArr = Network.eraseRegister(regArr, currentPos, 4)
        temp = Utils.ipv4AddressToWordArray(data.subnet)
        for i = 1, #temp do
            regArr[i+currentPos] = temp[i]
        end
    else -- Other mode than Stored remove data
        regArr = Network.eraseRegister(regArr, currentPos, 4)  
    end
    currentPos = currentPos + 4
    -- current pos 7, write 8 (skip over second subnet)
    if data.gateway and tonumber(data.ipAddrAssign) == 1 then
        -- Erase the register
        regArr = Network.eraseRegister(regArr, currentPos, 32) 
        --local gateway = Utils.checkIfIPv4AndConvert(data.gateway)
        regArr = Utils.overwriteAscii(data.gateway, currentPos, regArr, 32)
    else
        -- Erase the register
       regArr = Network.eraseRegister(regArr, currentPos, 32)  
    end

    currentPos = currentPos + 64
    -- current pos 71, write 72 (skip over second gateway)
    if data.ip and tonumber(data.ipAddrAssign) == 1 then
        regArr = Network.eraseRegister(regArr, currentPos, 20)
        regArr = Utils.overwriteAscii(data.ip, currentPos, regArr, 20)
    else
        regArr = Network.eraseRegister(regArr, currentPos, 20)  
    end

    --Write to the device
    LuaModBus.WriteMultipleRegisters(Constants.MULTI_REG_DEVICE_ID, WebConfConstants.FEATURES.DUAL_IP.STARTREG, #regArr, regArr)

    return nil
end

function Network.setDeviceName(devName)
    local regArr = LuaModBus.ReadMultipleRegisters(Constants.MULTI_REG_DEVICE_ID, WebConfConstants.FEATURES.DEVICE_NAME2.STARTREG, WebConfConstants.FEATURES.DEVICE_NAME2.NUMREGS)
    collectgarbage('collect')
    if not regArr then return ErrorCodes.MODBUS_WRITE_FAILED end

    regArr = Network.eraseRegister(regArr, 0, WebConfConstants.FEATURES.DEVICE_NAME2.NUMREGS)
    if devName and #devName > 0 then
        regArr = Utils.overwriteAscii(devName, 0, regArr, WebConfConstants.FEATURES.DEVICE_NAME2.NUMREGS)
    end
    --Write to the device
    LuaModBus.WriteMultipleRegisters(Constants.MULTI_REG_DEVICE_ID, WebConfConstants.FEATURES.DEVICE_NAME2.STARTREG, #regArr, regArr)


    regArr = LuaModBus.ReadMultipleRegisters(Constants.MULTI_REG_DEVICE_ID, WebConfConstants.FEATURES.SNMP.STARTREG + 64, WebConfConstants.FEATURES.SNMP.NUMREGS - 64)
    currentPos = 1
    regArr = Network.eraseRegister(regArr, currentPos, 16)  
    if devName and #devName > 0 then
        regArr = Utils.overwriteAscii(devName, currentPos, regArr, 16)
    end

    --Write to the device
    LuaModBus.WriteMultipleRegisters(Constants.MULTI_REG_DEVICE_ID, WebConfConstants.FEATURES.SNMP.STARTREG + 64, #regArr, regArr)

    return nil
end

function Network.getDeviceName()
    if LuaModBus then
        local temp = nil
        -- Device Name v2 -----------------------------------------------------------------------------
        temp = LuaModBus.ReadMultipleRegisters(Constants.MULTI_REG_DEVICE_ID, WebConfConstants.FEATURES.DEVICE_NAME2.STARTREG, WebConfConstants.FEATURES.DEVICE_NAME2.NUMREGS)
        collectgarbage('collect')
        if not temp then return nil, ErrorObject.new(ErrorCodes.MODBUS_READ_FAILED, '', nil ,HTTPStatusCode.InternalServerError) end
        --Make sure it is the correct size:
        if #temp < WebConfConstants.FEATURES.DEVICE_NAME2.NUMREGS then
            return nil, ErrorObject.new(ErrorCodes.INCORRECT_NUMBER_OF_REGS, '', nil ,HTTPStatusCode.InternalServerError)
        end

        return Utils.convertRegistersToAscii(temp, 1, 32)
    else
        return "KALA"
    end
end

function Network.getRSTP()
    return false, ErrorCodes.NOT_IMPLEMENTED
end

function Network.setRSTP(data)
    return false, ErrorCodes.NOT_IMPLEMENTED
end

function Network.getDNS(data)
    local result, errorMsg, temp = {}, nil, {}
    if LuaModBus then
        temp = LuaModBus.ReadMultipleRegisters(Constants.MULTI_REG_DEVICE_ID, WebConfConstants.FEATURES.DNS.STARTREG, WebConfConstants.FEATURES.DNS.NUMREGS)
        collectgarbage('collect')
        if not temp then return nil, ErrorCodes.MODBUS_READ_FAILED end
        table.insert(result, temp[1])
        table.insert(result, Utils.convertRegistersToAscii(temp, 2, 20))
        table.insert(result, Utils.convertRegistersToAscii(temp, 22, 20))
    else
        result = {
            0,
            "192.168.1.1",
            "192.168.1.100"
        }
    end
    return result, errorMsg
end

function Network.setDNS(data)
    local result, errorMsg, temp = true, nil, nil
    local currentPos = 0
    if LuaModBus then
        local regArr = LuaModBus.ReadMultipleRegisters(Constants.MULTI_REG_DEVICE_ID, WebConfConstants.FEATURES.DNS.STARTREG, WebConfConstants.FEATURES.DNS.NUMREGS)
        collectgarbage('collect')
        if not regArr then return nil, ErrorCodes.MODBUS_WRITE_FAILED end
        if data.isDHCPEnabled ~= nil then
            regArr[1] = tonumber(data.isDHCPEnabled)
        end
        currentPos = currentPos + 1

        regArr = Network.eraseRegister(regArr, currentPos, 20) 
        if data.preferredServer and data.isDHCPEnabled == 0 then
            regArr = Utils.overwriteAscii(data.preferredServer, currentPos, regArr, 20)  
        end

        currentPos = currentPos + 20
        regArr = Network.eraseRegister(regArr, currentPos, 20)
        if data.alternateServer and data.isDHCPEnabled == 0 then
            regArr = Utils.overwriteAscii(data.alternateServer, currentPos, regArr, 20)
        end
        --Write to the device
        LuaModBus.WriteMultipleRegisters(Constants.MULTI_REG_DEVICE_ID, WebConfConstants.FEATURES.DNS.STARTREG, #regArr, regArr)

        Network.setEndWrite()
    else
        errorMsg = ErrorCodes.NO_MODBUS_CONNECTION
        result = false
    end
    return result, errorMsg
end

function Network.getSNTP(data)
    local result, errorMsg, temp, startDst, endDst = {}, nil, {}, {}, {}
    if LuaModBus then
        temp = LuaModBus.ReadMultipleRegisters(Constants.MULTI_REG_DEVICE_ID, WebConfConstants.FEATURES.SNTP.STARTREG, WebConfConstants.FEATURES.SNTP.NUMREGS)
        collectgarbage('collect')
        if not temp then return nil, ErrorCodes.MODBUS_READ_FAILED end
        table.insert(result, bit32.band(bit32.rshift(temp[1], 14), 1))  --ntp enable
        table.insert(result, Utils.convertRegistersToAscii(temp, 2, 32)) -- primary server
        table.insert(result, Utils.convertRegistersToAscii(temp, 34, 32)) -- secondary server
        table.insert(result, bit32.band(bit32.rshift(temp[1], 8), 0x3F)) -- sync interval
        table.insert(result, bit32.band(temp[1], 0xFF)) -- time zone index
        table.insert(result, bit32.band(bit32.rshift(temp[1], 15), 1)) -- dst enable

        table.insert(startDst, bit32.band(bit32.rshift(temp[67], 1), 0x1F)) -- hour
        table.insert(startDst, bit32.band(bit32.rshift(temp[67], 6), 0x07)) -- day
        table.insert(startDst, bit32.band(bit32.rshift(temp[67], 9), 0x07)) -- week
        table.insert(startDst, bit32.band(bit32.rshift(temp[67], 12), 0x0F)) -- month
        table.insert(result,startDst) -- dst start

        table.insert(endDst, bit32.band(bit32.rshift(temp[68], 1), 0x1F)) -- hour
        table.insert(endDst, bit32.band(bit32.rshift(temp[68], 6), 0x07)) -- day
        table.insert(endDst, bit32.band(bit32.rshift(temp[68], 9), 0x07)) -- week
        table.insert(endDst, bit32.band(bit32.rshift(temp[68], 12), 0x0F)) -- month
        table.insert(result,endDst) -- dst end


        table.insert(result,
            string.format(
                "20%02d-%02d-%02d",
                bit32.band(temp[69], 0xFF),
                bit32.band(bit32.rshift(temp[70], 8), 0xFF),
                bit32.band(temp[70], 0xFF)
            )
        )   -- current date

        table.insert(result,
            string.format(
                "%02d:%02d:%02d",
                bit32.band(bit32.rshift(temp[71], 8), 0xFF),
                bit32.band(temp[71], 0xFF),
                tonumber(temp[72]/1000)
            )
        )   -- current time
    else
        result = {
            1,
            "192.168.5.101",
            "192.168.5.102",
            2,
            0,
            1,
            {5, 6, 3, 10},
            {5, 4, 2, 8},
            "2011-09-13",
            "17:36:00.0"
        }
    end
    return result, errorMsg
end

function Network.setSNTP(data)
    local result, errorMsg, temp = true, nil, nil
    local currentPos = 1
    if LuaModBus then
        local regArr = LuaModBus.ReadMultipleRegisters(Constants.MULTI_REG_DEVICE_ID, WebConfConstants.FEATURES.SNTP.STARTREG, WebConfConstants.FEATURES.SNTP.NUMREGS)
        collectgarbage('collect')
        if not regArr then return nil, ErrorCodes.MODBUS_WRITE_FAILED end
        if data.timeZone ~= nil then
            regArr[currentPos] = bit32.replace(regArr[currentPos], tonumber(data.timeZone), 0, 8)
        end
        if data.pollingInterval ~= nil then
            regArr[currentPos] = bit32.replace(regArr[currentPos], tonumber(data.pollingInterval), 8, 6)
        end
        if data.ntpEnable ~= nil then
            regArr[currentPos] = bit32.replace(regArr[currentPos], tonumber(data.ntpEnable), 14, 1)
        end
        if data.dstEnable ~= nil then
            regArr[currentPos] = bit32.replace(regArr[currentPos], tonumber(data.dstEnable), 15, 1)
        end
        --currentPos == 1
        currentPos = currentPos
        regArr = Network.eraseRegister(regArr, currentPos, 32) 
        if data.server1IP and data.ntpEnable == 1 then
            regArr = Utils.overwriteAscii(data.server1IP, currentPos, regArr, 32)
        end
        currentPos = currentPos + 32
        
        --currentPos == 34 - 33 register OK
        regArr = Network.eraseRegister(regArr, currentPos, 32)
        if data.server2IP and data.ntpEnable == 1 then
            regArr = Utils.overwriteAscii(data.server2IP, currentPos, regArr, 32)
        end
        currentPos = currentPos + 32
        --Skip over time difference (uses index value instead)
        currentPos = currentPos + 2
        --currentPos == 67 OK
        if data.startDate ~= nil and data.dstEnable == 1 then
            regArr[currentPos] = bit32.replace(regArr[currentPos], tonumber(data.startDate.time)         , 1, 5) -- Hour
            regArr[currentPos] = bit32.replace(regArr[currentPos], tonumber(data.startDate.dayOfWeek)    , 6, 3) -- Day
            regArr[currentPos] =  bit32.replace(regArr[currentPos], tonumber(data.startDate.weekOfMonth)  , 9, 3) -- Week
            regArr[currentPos] =  bit32.replace(regArr[currentPos], tonumber(data.startDate.month)        , 12,4) -- Month
        elseif  data.dstEnable == 0 then
            regArr[currentPos] = 0   
        end
        currentPos = currentPos + 1
        --currentPos == 68 OK
        if data.endDate ~= nil and data.dstEnable == 1 then
            regArr[currentPos] = bit32.replace(regArr[currentPos], tonumber(data.endDate.time)         , 1, 5) -- Hour
            regArr[currentPos] = bit32.replace(regArr[currentPos], tonumber(data.endDate.dayOfWeek)    , 6, 3) -- Day
            regArr[currentPos] = bit32.replace(regArr[currentPos], tonumber(data.endDate.weekOfMonth)  , 9, 3) -- Week
            regArr[currentPos] = bit32.replace(regArr[currentPos], tonumber(data.endDate.month)        , 12,4) -- Month
        elseif  data.dstEnable == 0 then
            regArr[currentPos] = 0       
        end
        currentPos = currentPos + 1
        --currentPos == 69 OK
        if data.currentDate ~= nil then
            local tempDate = Utils.parseDate(data.currentDate)
            regArr[currentPos] = tempDate.year
            regArr[currentPos+1] = Utils.convertBytesToInt16(tempDate.month, tempDate.day)
        end
        currentPos = currentPos + 2
        --currentPos == 71 OK
        if data.currentTime ~= nil then
            local tempTime = Utils.parseTime(data.currentTime)
            regArr[currentPos] = Utils.convertBytesToInt16(tempTime.hours, tempTime.minutes)
            regArr[currentPos+1] = tempTime.seconds * 1000
        end
        --Write to the device
        LuaModBus.WriteMultipleRegisters(Constants.MULTI_REG_DEVICE_ID, WebConfConstants.FEATURES.SNTP.STARTREG, #regArr, regArr)

        Network.setEndWrite()
    else
        errorMsg = ErrorCodes.NO_MODBUS_CONNECTION
        result = false
    end
    return result, errorMsg
end

function Network.getSNMP()
    local result, errorMsg, temp = {}, nil, {}
    if LuaModBus then
        -- Read 64 Register
        temp = LuaModBus.ReadMultipleRegisters(Constants.MULTI_REG_DEVICE_ID, WebConfConstants.FEATURES.SNMP.STARTREG, 64)
        collectgarbage('collect')
        if not temp then return nil, ErrorCodes.MODBUS_READ_FAILED end
        Utils.convertRegistersToAscii(temp, 1, 32)
        table.insert(result, Utils.convertRegistersToAscii(temp, 1, 32))   -- m1 ip
        table.insert(result, Utils.convertRegistersToAscii(temp, 33, 32)) -- m2 ip
        temp = LuaModBus.ReadMultipleRegisters(Constants.MULTI_REG_DEVICE_ID, WebConfConstants.FEATURES.SNMP.STARTREG + 64, WebConfConstants.FEATURES.SNMP.NUMREGS - 64)
        collectgarbage('collect')
        if not temp then return nil, ErrorCodes.MODBUS_READ_FAILED end
        table.insert(result, Utils.convertRegistersToAscii(temp, 2, 16)) -- sys name
        table.insert(result, Utils.convertRegistersToAscii(temp, 18, 16)) -- sys loc
        table.insert(result, Utils.convertRegistersToAscii(temp, 34, 16)) -- sys contact
        table.insert(result, Utils.convertRegistersToAscii(temp, 50, 16)) -- get
        table.insert(result, Utils.convertRegistersToAscii(temp, 66, 16)) -- set
        table.insert(result, Utils.convertRegistersToAscii(temp, 82, 16)) -- trap
        table.insert(result, Utils.convertRegistersToInt32(temp[98], temp[99])) -- en. traps
    else
        result = {
            "192.168.1.3",
            "192.168.1.5",
            "Altivar NERA",
            "North Andover",
            "John Smith",
            "public",
            "public",
            "public",
            20  --Link down + Auth failure traps set
        }
    end
    return result, errorMsg
end

function Network.setSNMP(data)
    local result, errorMsg, temp = true, nil, nil
    local currentPos = 0
    if LuaModBus then
        local regArr = LuaModBus.ReadMultipleRegisters(Constants.MULTI_REG_DEVICE_ID, WebConfConstants.FEATURES.SNMP.STARTREG, 64)
        collectgarbage('collect')
        if not regArr then return nil, ErrorCodes.MODBUS_WRITE_FAILED end
        -- Erase the register
        regArr = Network.eraseRegister(regArr, currentPos, 32)  
        if data.manager1IP then
            regArr = Utils.overwriteAscii(data.manager1IP, currentPos, regArr, 32)
        end

        currentPos = currentPos + 32
        regArr = Network.eraseRegister(regArr, currentPos, 32)  
        if data.manager2IP then
            regArr = Utils.overwriteAscii(data.manager2IP, currentPos, regArr, 32)
        end
        --Write to the device
        LuaModBus.WriteMultipleRegisters(Constants.MULTI_REG_DEVICE_ID, WebConfConstants.FEATURES.SNMP.STARTREG, #regArr, regArr)

        regArr = LuaModBus.ReadMultipleRegisters(Constants.MULTI_REG_DEVICE_ID, WebConfConstants.FEATURES.SNMP.STARTREG + 64, WebConfConstants.FEATURES.SNMP.NUMREGS - 64)
        currentPos = 1
        --regArr = Network.eraseRegister(regArr, currentPos, 16)  
        --if data.systemName then
        --    regArr = Utils.overwriteAscii(data.systemName, currentPos, regArr, 16)
        --end

        currentPos = currentPos + 16
        -- Erase the register
        regArr = Network.eraseRegister(regArr, currentPos, 16)  
        if data.systemLocation then
            regArr = Utils.overwriteAscii(data.systemLocation, currentPos, regArr, 16)
        end

        currentPos = currentPos + 16
        regArr = Network.eraseRegister(regArr, currentPos, 16)  
        if data.systemContact then
            regArr = Utils.overwriteAscii(data.systemContact, currentPos, regArr, 16)
        end

        currentPos = currentPos + 16
        -- Erase the register
        regArr = Network.eraseRegister(regArr, currentPos, 16)  
        if data.communityGet then
            regArr = Utils.overwriteAscii(data.communityGet, currentPos, regArr, 16)
        end

        currentPos = currentPos + 16
        regArr = Network.eraseRegister(regArr, currentPos, 16)  
        if data.communitySet then
            regArr = Utils.overwriteAscii(data.communitySet, currentPos, regArr, 16)
        end

        currentPos = currentPos + 16
        regArr = Network.eraseRegister(regArr, currentPos, 16)  
        if data.communityTrap then
            regArr = Utils.overwriteAscii(data.communityTrap, currentPos, regArr, 16)
        end

        currentPos = currentPos + 16
        if data.enabledTraps then
            regArr[currentPos + 2] = bit32.replace(regArr[currentPos + 2], tonumber(data.enabledTraps.coldStart), 0, 1)
            regArr[currentPos + 2] = bit32.replace(regArr[currentPos + 2], tonumber(data.enabledTraps.linkDown), 2, 1)
            regArr[currentPos + 2] = bit32.replace(regArr[currentPos + 2], tonumber(data.enabledTraps.linkUp), 3, 1)
            regArr[currentPos + 2] = bit32.replace(regArr[currentPos + 2], tonumber(data.enabledTraps.authTrap), 4, 1)
        end
        --Write to the device
        LuaModBus.WriteMultipleRegisters(Constants.MULTI_REG_DEVICE_ID, WebConfConstants.FEATURES.SNMP.STARTREG + 64, #regArr, regArr)

        Network.setDeviceName(data.systemName)

        Network.setEndWrite()
    else
        errorMsg = ErrorCodes.NO_MODBUS_CONNECTION
        result = false
    end
    return result, errorMsg
end

function Network.setEndWrite()
    if LuaModBus then
        local regArr = LuaModBus.ReadMultipleRegisters(Constants.MULTI_REG_DEVICE_ID, Constants.CONF_ACTION_OFFSET, Constants.CONF_ACTION_COUNT)
        collectgarbage('collect')
        if not regArr then 
            return nil, ErrorCodes.MODBUS_WRITE_FAILED 
        end
        regArr[1] = bit32.replace(regArr[1], tonumber(1), 6, 1)
        --Write to the device
        LuaModBus.WriteMultipleRegisters(Constants.MULTI_REG_DEVICE_ID, Constants.CONF_ACTION_OFFSET, #regArr, regArr)
    end
    return true, nil
end

function Network.setTrigger(data)
    if LuaModBus then
        local regArr = LuaModBus.ReadMultipleRegisters(Constants.MULTI_REG_DEVICE_ID, Constants.CONF_ACTION_OFFSET, Constants.CONF_ACTION_COUNT)
        collectgarbage('collect')
        if not regArr then 
            return nil, ErrorCodes.MODBUS_WRITE_FAILED 
        end
        if data.direction then
            if (data.direction == 0) then --Server-Device
                regArr[1] = bit32.replace(regArr[1], tonumber(1), 4, 1)
            elseif (data.direction == 1) then --Device-Server
                regArr[1] = bit32.replace(regArr[1], tonumber(1), 8, 1)
            end
            --Write to the device
            LuaModBus.WriteMultipleRegisters(Constants.MULTI_REG_DEVICE_ID, Constants.CONF_ACTION_OFFSET, #regArr, regArr)
        else
            return nil, nil
        end
    end
    return true, nil
end

function Network.eraseRegister(register, currentPos, size)
    for i=1,size do
        register[i+currentPos] = 0
    end
    return register
end

function Network.readFDRStatus()
    if LuaModBus then
        local temp = LuaModBus.ReadMultipleRegisters(Constants.MULTI_REG_DEVICE_ID,  Constants.CONF_ACTION_OFFSET , Constants.CONF_ACTION_COUNT)
        collectgarbage('collect')
        if not temp then 
            return nil, ErrorCodes.MODBUS_WRITE_FAILED 
        end
        local result = bit32.extract(temp[1], 2, 1)
        return result, nil
    end
    return math.random(1), nil
end

function Network.readFDRResult()
    if LuaModBus then
        local temp = LuaModBus.ReadMultipleRegisters(Constants.MULTI_REG_DEVICE_ID,  Constants.FDR_STATUS_OFFSET , Constants.FDR_STATUS_COUNT)
        collectgarbage('collect')
        if not temp then 
            return nil, ErrorCodes.MODBUS_WRITE_FAILED 
        end
        return temp, nil
    end
    return math.random(1), nil
end

function Network.eraseFDRStatus()
    if LuaModBus then
        local regArr = LuaModBus.ReadMultipleRegisters(Constants.MULTI_REG_DEVICE_ID, Constants.CONF_ACTION_OFFSET,Constants.CONF_ACTION_COUNT)
        collectgarbage('collect')
        if not regArr then 
            return nil, ErrorCodes.MODBUS_WRITE_FAILED 
        end
        regArr[1] = bit32.replace(regArr[1], tonumber(0), 2, 1)
        --Write to the device
        LuaModBus.WriteMultipleRegisters(Constants.MULTI_REG_DEVICE_ID,  Constants.CONF_ACTION_OFFSET, #regArr, regArr)
    end
    return true, nil
end
return Network