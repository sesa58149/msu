local DataTableRESTHandler = {}

function DataTableRESTHandler.getHandler(_ENV,path)
    local tableData, errorMsg = nil
    local method = request:method()
    -- Ensure that the response is has a content type of JSON
    response:setheader('content-type', 'application/json; charset=UTF-8')
    if(path == '') then
        -- GET http://localhost/rest/datatable :: List Data Tables
        if (method == 'GET') then
            HTTPMethods.get(_ENV, DataTableRESTHandler.getTableList)
        -- PUT http://localhost/rest/datatable :: Create a New Table
        elseif (method == 'POST') then
            HTTPMethods.post(_ENV, DataTableRESTHandler.crudTable, {HTTPStatusCode.BadRequest}, false)
        -- Unknown method
        else
            gf.sendError(_ENV)
        end
    else
        if not path:match("^[%w_]+$") and not path:match("^[%w_]+/.*$") then
            -- Respond Bad Request
            gf.sendError(_ENV, HTTPStatusCode.BadRequest, ErrorCodes.INVALID_REQUEST)
        elseif path:match("^[%w_]+/variables") then
            local tableName = path:match("^[%w_]+")
            -- Update variables in a table
            if (method == 'PUT') then
                HTTPMethods.put(_ENV, DataTableRESTHandler.updateVariables, {}, tableName)
            -- Add variables to a table
            elseif (method == 'POST') then
                HTTPMethods.post(_ENV, DataTableRESTHandler.addVariablesToTable, {}, tableName)
            -- Delete variables from a table
            elseif (method == 'DELETE') then
                HTTPMethods.delete(_ENV, DataTableRESTHandler.deleteVariables, true, {}, tableName)
            -- Get values of variables by datatable name
            elseif (method == 'GET') then
                HTTPMethods.get(_ENV, DataTableRESTHandler.getTable, HTTPStatusCode.InternalServerError, tableName)
            -- Uknown HTTP Request?
            else
                gf.sendError(_ENV)
            end
        elseif path:match("^[%w_]+/tableinfo") then
            local tableName = path:match("^[%w_]+")
            -- Get all the information about a table...
            if (method == 'GET') then
                HTTPMethods.get(_ENV, DataTableRESTHandler.getTableInfo, HTTPStatusCode.InternalServerError, tableName)
            end
        else
            local tableName = path:match("^[%w_]+")
            -- GET http://localhost/rest/datatable/tableName :: Retrieve table representation (list variables)
            if (method == 'GET') then
                HTTPMethods.get(_ENV, DataTableRESTHandler.getTable,
                    HTTPStatusCode.InternalServerError, tableName)
            -- PUT http://localhost/rest/datatable/tableName :: Update the table
            elseif (method == 'PUT') then
                HTTPMethods.put(_ENV, DataTableRESTHandler.crudTable,
                    {HTTPStatusCode.NotFound}, true)
            -- DELETE http://localhost/rest/datatable/tableName :: Delete table
            elseif (method == 'DELETE') then
                HTTPMethods.delete(_ENV, DataTableRESTHandler.deleteTable, false,
                    {HTTPStatusCode.InternalServerError}, tableName)
            -- Unknown method
            else
                gf.sendError(_ENV)
            end
        end
    end
end

function DataTableRESTHandler.getTableList()
    local result, errorMsg = DataTable.getTables()
    if not errorMsg then
        return ba.json.encode(result), nil
    else
        return nil, errorMsg
    end
end

function DataTableRESTHandler.crudTable(tableData, isUpdate)
    local errorMsg = nil
    local success = false
    if tableData then
        if not isUpdate then

            --test number of tables
            local numTables = DataTable.getTableCount()

            if numTables < Constants.MAX_NUM_TABLES then
                success, errorMsg = DataTable.create(tableData)
            else
                -- Send message saying max number tables reached...
                trace( ErrorCodes.MAX_NUM_DATATABLES_REACHED )
                return nil, ErrorObject.new(ErrorCodes.MAX_NUM_DATATABLES_REACHED, '', nil, HTTPStatusCode.BadRequest)
            end
        else
            success, errorMsg = DataTable.update(tableData)
        end
        if success then
            return '{"success":true}', nil
        else
            return nil, errorMsg
        end
    else
        return nil, ErrorCodes.INVALID_REQUEST
    end
end

function DataTableRESTHandler.deleteTable(tableName)
    local success, errorMsg = DataTable.delete(tableName)
    if success then
        return '{"success":true}', nil
    else
        return nil, errorMsg
    end
end

function DataTableRESTHandler.addVariablesToTable(variables, tableName)
    local success, errorMsg = DataTable.addVariablesToTable(variables, tableName)
    if success then
        return '{"success":true}', nil
    else
        return nil, errorMsg
    end
end

function DataTableRESTHandler.deleteVariables(variables, tableName)
    local success, errorMsg = DataTable.deleteVariables(variables, tableName)
    if success then
        return '{"success":true}', nil
    else
        return nil, errorMsg
    end
end

function DataTableRESTHandler.getTable(tableName)
    local tableData, errorMsg = DataTable.getTable(tableName)
    if tableData then
        return ba.json.encode(tableData), nil
    else
        return nil, errorMsg
    end
end

function DataTableRESTHandler.getTableInfo(tableName)
    local tableData, errorMsg = DataTable.getTables(tableName)
    if tableData then
        return ba.json.encode(tableData), nil
    else
        return nil, errorMsg
    end
end

function DataTableRESTHandler.updateVariables(variables, tableName)
    local success, errorMsg = DataTable.updateVariables(variables, tableName)
    if success then
        return '{"success":true}', nil
    else
        return nil, errorMsg
    end
end

return DataTableRESTHandler