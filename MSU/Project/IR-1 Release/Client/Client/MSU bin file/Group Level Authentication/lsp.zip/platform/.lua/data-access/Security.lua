local Security = {}

function Security.getPwPolicy()
    local env, result, connection, errorMsg = nil, 0, nil, nil
    env, errorMsg = luasql.sqlite()
    if env then
        connection, errorMsg = env:connect(Constants.DB_PATH, 'READONLY')
        if connection then
            local cursor = connection:prepare([[
                SELECT * FROM password_policy
            ]])
            if cursor then
                cursor, errorMsg = cursor:execute()

                local queryResult = {}
                cursor:fetch(queryResult, 'a')
                if type(queryResult) == 'table' then
                    result = queryResult
                end

                if not cursor:close() then
                    trace(ErrorCodes.FAILED_TO_CLOSE_DB_CURSOR)
                end
            end
            if not connection:close() then
                trace(ErrorCodes.FAILED_TO_CLOSE_DB_CONNECTION)
            end
        end
        if not env:close() then
            trace(ErrorCodes.FAILED_TO_CLOSE_DB_ENVIRONMENT)
        end
    end
    return result, errorMsg
end

function Security.setPwPolicy(data)
    local env, connection, errorMsg, result, isLockAcquired = nil, nil, nil, false, false
    env, errorMsg = luasql.sqlite()
    if env then
        connection, errorMsg = env:connect(Constants.DB_PATH)
        if connection then
            isLockAcquired, errorMsg = connection:setautocommit('IMMEDIATE', 1000)
            if isLockAcquired then
                local cursor = connection:prepare([[
                    UPDATE password_policy
                    SET is_enabled = ( ? ),
                        history = ( ? ),
                        req_special = ( ? ),
                        req_num = ( ? ),
                        req_alpha = ( ? ),
                        min_length = ( ? )
                ]])

                if cursor then
                    cursor:bind{
                        {'INTEGER', tonumber(data.is_enabled)},
                        {'INTEGER', tonumber(data.history)},
                        {'INTEGER', tonumber(data.req_special)},
                        {'INTEGER', tonumber(data.req_num)},
                        {'INTEGER', tonumber(data.req_alpha)},
                        {'INTEGER', tonumber(data.min_length)}
                    }
                    local exec = cursor:execute()
                    if exec then
                        if connection:commit() then
                            --TODO: Fix bug with password flags
			    --User.resetAllChangePasswordFlags(connection)
                            --if tonumber(data.history) == 0 then
                            --    User.resetAllPasswordHistories(connection)
                            --end
                            result = true
                        else
                            errorMsg = ErrorCodes.COMMIT_FAIL
                        end
                    end
                    if not cursor:close() then
                        trace(ErrorCodes.FAILED_TO_CLOSE_DB_CURSOR)
                    end
                end
            else
                return nil, ErrorCodes.DB_LOCK_NOT_ACQUIRED
            end
            if not connection:close() then
                trace(ErrorCodes.FAILED_TO_CLOSE_DB_CONNECTION)
            end
        end
        if not env:close() then
            trace(ErrorCodes.FAILED_TO_CLOSE_DB_ENVIRONMENT)
        end
    end
    return result, errorMsg
end

function Security.getMode()
    -- Result defaults to security enabled
    local env, result, connection, errorMsg = nil, 1, nil, nil

    env, errorMsg = luasql.sqlite()

    if env then

        connection, errorMsg = env:connect(Constants.DB_PATH, 'READONLY')

        if connection then

            local cursor = connection:prepare([[
                SELECT attr_value FROM config_attributes
                WHERE attr_key == "security_mode"
            ]])

            if cursor then
                cursor = cursor:execute()

                local queryResult = {}
                cursor:fetch(queryResult, 'a')

                -- Expect 1 or 0 otherwise default to security enabled
                if type(queryResult) == 'table'
                   and type(queryResult.attr_value) == 'string'
                   and queryResult.attr_value == '0' or queryResult.attr_value == '1'
                then
                    result = queryResult.attr_value
                end

                if not cursor:close() then
                    trace(ErrorCodes.FAILED_TO_CLOSE_DB_CURSOR)
                end
            end

            if not connection:close() then
                trace(ErrorCodes.FAILED_TO_CLOSE_DB_CONNECTION)
            end
        end
        if not env:close() then
            trace(ErrorCodes.FAILED_TO_CLOSE_DB_ENVIRONMENT)
        end
    end
    -- If an error occurred then result will be 1
    return result, errorMsg
end

function Security.setMode(mode)
    local env, connection, errorMsg, result = nil, nil, nil, false
    if type(mode) == 'number' and mode == 0 or mode == 1 then
        env, errorMsg = luasql.sqlite()
        if env then
            connection, errorMsg = env:connect(Constants.DB_PATH)
            if connection then
                isLockAcquired, errorMsg = connection:setautocommit('IMMEDIATE', 1000)
                if isLockAcquired then
                    local cursor, errorMsg = connection:prepare([[
                        UPDATE config_attributes SET
                            attr_value = ( ? )
                        WHERE attr_key == "security_mode"
                    ]])

                    if cursor then
                        cursor:bind({{'TEXT', tostring(mode)}})
                        local exec = cursor:execute()
                        if exec == 1 then
                            if connection:commit() then
                                result = true
                            else
                                errorMsg = ErrorCodes.COMMIT_FAIL
                            end
                            if not cursor:close() then
                                trace(ErrorCodes.FAILED_TO_CLOSE_DB_CURSOR)
                            end
                        else
                            -- Close the first cursor
                            if not cursor:close() then
                                trace(ErrorCodes.FAILED_TO_CLOSE_DB_CURSOR)
                            end
                            -- key doesn't exist insert it instead
                            local cursor, errorMsg = connection:prepare([[
                                INSERT INTO config_attributes (attr_key, attr_value)
                                VALUES (?, ?)
                            ]])
                            if cursor then
                                cursor:bind({{'TEXT', "security_mode"},{'TEXT', tostring(mode)}})
                                local exec = cursor:execute()
                                if exec == 1 then
                                    if connection:commit() then
                                        result = true
                                    else
                                        errorMsg = ErrorCodes.COMMIT_FAIL
                                    end
                                else
                                    errorMsg = ErrorCodes.DB_QUERY_EXECUTE_FAILED
                                end
                                -- Close the second cursor
                                if not cursor:close() then
                                    trace(ErrorCodes.FAILED_TO_CLOSE_DB_CURSOR)
                                end
                            else
                                errorMsg = ErrorCodes.FAILED_TO_CLOSE_DB_CURSOR
                            end
                        end
                    else
                        errorMsg = ErrorCodes.FAILED_TO_CLOSE_DB_CURSOR
                    end
                else
                    errorMsg = ErrorCodes.DB_LOCK_NOT_ACQUIRED
                end
                -- Ensure the connection is closed
                if not connection:close() then
                    trace(ErrorCodes.FAILED_TO_CLOSE_DB_CONNECTION)
                end
            else
                errorMsg = ErrorCodes.FAILED_TO_CLOSE_DB_CONNECTION
            end
            -- Ensure the db environment is closed
            if not env:close() then
                trace(ErrorCodes.FAILED_TO_CLOSE_DB_ENVIRONMENT)
            end
        else
            errorMsg = ErrorCodes.FAILED_TO_CLOSE_DB_ENVIRONMENT
        end
    else
        errorMsg = ErrorCodes.INVALID_REQUEST
    end
    return result, errorMsg
end

return Security