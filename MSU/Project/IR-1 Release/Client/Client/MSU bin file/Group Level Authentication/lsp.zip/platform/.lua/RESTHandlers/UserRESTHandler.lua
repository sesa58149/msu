local UserRESTHandler = {}

function UserRESTHandler.getUserList()
	local result, errorMsg = User.get()
	if not errorMsg then
		return ba.json.encode(result), nil
	else
		return nil, errorMsg
	end
end

function UserRESTHandler.getHandler(_ENV,path)
	local result, user, errorMsg = nil
    local method = request:method()
	local userRef = request:user()
	local authedUsername = nil
    local tUser = nil

    -- Ensure that the response is has a content type of JSON
    response:setheader('content-type', 'application/json; charset=UTF-8')
    -- http://domain/rest/user
    if(path == '') then
        if (method == 'GET') then
            -- Description: Get user list
            -- Method: GET
            -- URL: http://localhost/rest/user
            -- Rights: READ
			HTTPMethods.get(_ENV, UserRESTHandler.getUserList)
        elseif (method == 'POST') then
            -- Description: Create new user
            -- Method: PUT
            -- URL: http://localhost/rest/user
            -- Rights: READ/WRITE/CREATE
			HTTPMethods.post(_ENV, UserRESTHandler.createUser, {HTTPStatusCode.Conflict})
        else
            -- Not Implemented
            gf.sendError(_ENV)
        end
    else
        -- http://domain/rest/user/[username]
        -- Username must be all alphanumeric characters
        if not path:match("^[%w_]+$") and not path:match("^[%w_]+/.*$") then
            -- Respond Bad Request
            gf.sendError(_ENV, HTTPStatusCode.BadRequest, ErrorCodes.INVALID_REQUEST)
        else
            -- Grab the username from the path
            local username = path:match("^%w+")
            if (method == 'GET') then
				HTTPMethods.get(_ENV, UserRESTHandler.getUser, {}, username)
            elseif (method == 'PUT') then
				if userRef then
					authedUsername = userRef:match('[%w_]+')
                    tUser = User.get(authedUsername)
					if tUser[1]['isAdmin'] ~= 1 then
						gf.sendError(_ENV, HTTPStatusCode.BadRequest, ErrorCodes.INVALID_REQUEST)
						return
					end
				end
				HTTPMethods.put(_ENV, UserRESTHandler.updateUser)
            elseif (method == 'POST') then
				if userRef then
					authedUsername = userRef:match('[%w_]+')
					tUser = User.get(authedUsername)
                    -- Ensure the authorized user is an administrator
                    if tUser[1]['isAdmin'] ~= 1 then
						gf.sendError(_ENV, HTTPStatusCode.BadRequest, ErrorCodes.INVALID_REQUEST)
						return
					end
				end

                local userSession = request:session(false)
                local authedSID = nil
                if userSession ~= false then
                    authedSID = userSession:id()
                end

                -- POST http://localhost/rest/user/ :: Change the specific user's password
				HTTPMethods.post(_ENV, UserRESTHandler.changeUserPassword, {HTTPStatusCode.Conflict}, {username=username, authedUsername = authedUsername, authedSID=authedSID})
            elseif (method == 'DELETE') then
				if userRef then
					authedUsername = userRef:match('[%w_]+')
					tUser = User.get(authedUsername)
                    if tUser[1]['isAdmin'] ~= 1 then
						gf.sendError(_ENV, HTTPStatusCode.BadRequest, ErrorCodes.INVALID_REQUEST)
						return
					end
				end
                -- DELETE http://localhost/rest/user/tableName :: Delete user
				HTTPMethods.delete(_ENV, UserRESTHandler.deleteUser, false, {}, username)
            else
                gf.sendError(_ENV)
            end
        end
    end
end
function UserRESTHandler.getUser(username)
    local userData = User.get(username)
    if next(userData) ~= nil then
        -- If the table is not empty respond with it in JSON format
        return ba.json.encode(userData[1]), nil
    else
        -- Respond 404 as the user doesn't exist
        return nil, ErrorCodes.USER_DOES_NOT_EXIST
    end
end
function UserRESTHandler.createUser(userdata)
    if not userdata.username or userdata.username == "" then
        return nil, ErrorCodes.USERNAME_REQUIRED
    end
	local success, errorMsg = User.create(userdata)
    if success then
        return ba.json.encode({success = true}), nil
    else
        return nil, errorMsg
    end
end
function UserRESTHandler.updateUser(userdata)
    if not userdata.username or userdata.username == "" then
        return nil, ErrorCodes.USERNAME_REQUIRED
    end
    local success, errorMsg = User.update(userdata)
    if success then
        UserRESTHandler.terminateSession(userdata.username)
        return ba.json.encode({success = true}), nil
    else
        return nil, errorMsg
    end
end
function UserRESTHandler.deleteUser(username)
    local success, errorMsg = User.delete(username)
    if success then
		UserRESTHandler.terminateSession(username)
        return ba.json.encode({success = true}), nil
	else
		return nil, errorMsg
	end
end
function UserRESTHandler.changeUserPassword(userdata, extraParams)
    local username = extraParams.username
    local authedUsername = extraParams.authedUsername

	-- Ensure a new password is provided and that it doesn't go out of the max boundary of MAX_PASSWORD_LENGTH
	if userdata.newPassword and (userdata.newPassword):len() > 0 and
		(userdata.newPassword):len() < Constants.MAX_PASSWORD_LENGTH then

        local remindToChangePass = 1
        if username == authedUsername then
            -- if authedUser is the same as the user having their password changed then don't require remind.
            -- This is because the admin is changing their own password.
            remindToChangePass = 0
        end

		local success, errorMsg = User.changePassword(username, userdata, remindToChangePass)
		if success then
            UserRESTHandler.terminateSession(username, authedUsername, extraParams.authedSID)
			return ba.json.encode({success = true}), nil
		else
			return nil, errorMsg
		end
	else
		return nil, ErrorCodes.INVALID_PASSWORD
	end
end
function UserRESTHandler.terminateSession(username, authedUsername, authedSID)
    local authedUserPassChanged = username == authedUsername
    -- Terminate all sessions for that user
    for _,sesid in ipairs(ba.sessions(username)) do
        if authedUserPassChanged == true and sesid ~= authedSID or authedUserPassChanged == false then
            local s = ba.session(sesid) -- Fetch session using session ID.
            s:terminate()
        end
    end
end
return UserRESTHandler