local io = ba.openio(_G.diskIOName)
local VariableRESTHandler = io:dofile('platform/.lua/RESTHandlers/VariableRESTHandler.lua')

function VariableRESTHandler.getHandler(_ENV,path)
    local result, variableData, errorMsg = nil
    local method = request:method()

    -- Ensure that the response is has a content type of JSON
    response:setheader('content-type', 'application/json; charset=UTF-8')

    if(path == '') then
        -- domain/rest/variables :: Get list of namespace variables
        if method == 'GET' then
			HTTPMethods.get(_ENV, VariableRESTHandler.getVariables)
		elseif method == 'POST' then
			HTTPMethods.post(_ENV, VariableRESTHandler.getSelectedVariables)
        else
            gf.sendError(_ENV)
        end
    elseif path:lower() == 'getvariablevalues' then
		-- domain/rest/variables/getvariablevalues
        local result, errorMsg = VariableRESTHandler.getVariableValues(_ENV)
		if result == nil then
			response:senderror(HTTPStatusCode.BadRequest, errorMsg)
		else
			response:write(result)
		end	   
    elseif path:lower() == 'getmonitvariables' then
		-- domain/rest/variables/getmonitvariables
        local result, errorMsg = VariableRESTHandler.getMonitVariables(_ENV)
		if result == nil then
			response:senderror(HTTPStatusCode.BadRequest, errorMsg)
		else
			response:write(result)
		end	   
    elseif path:lower() == 'getsetupvariables' then
		-- domain/rest/variables/getsetupvariables
        local result, errorMsg = VariableRESTHandler.getSetupVariables(_ENV)
		if result == nil then
			response:senderror(HTTPStatusCode.BadRequest, errorMsg)
		else
			response:write(result)
		end	   
    end
end

function VariableRESTHandler.getSelectedVariables(data)
	local result, errorMsg = Variable.getSelectedVariables(data)
    if not result then
        return result, errorMsg
    end
    result, errorMsg = ba.json.encode(result)
    if not result then
        return result, errorMsg
    end
    return result
end

function VariableRESTHandler.getVariableValues(_ENV)
	local result, err, variables = nil, nil, nil
	variables, err = gf.getDecodedJSONPayload(_ENV)

	if variables ~= nil then
		result, err = Variable.getVariableValues(variables)
		if result ~= nil then
			result, err = ba.json.encode(result)
		end
	end
	return result, err
end

function VariableRESTHandler.getSetupVariables(_ENV)
	local mVariables, err = Variable.getSetupVariables()

	if mVariables ~= nil then
		return ba.json.encode(mVariables), err
	else
		return nil, err
	end
end

function VariableRESTHandler.getMonitVariables(_ENV)
	local mVariables, err = Variable.getMonitVariables()

	if mVariables ~= nil then
		return ba.json.encode(mVariables), err
	else
		return nil, err
	end
end

return VariableRESTHandler