local AutoTestRESTHandler = {}

function AutoTestRESTHandler.getHandler(_ENV,path)
    local method = request:method()
    response:setheader('content-type', 'application/json; charset=UTF-8')
    if path:len() < 1 then
        gf.sendError(_ENV, HTTPStatusCode.BadRequest, ErrorCodes.UNSPECIFIED_DIAG)
    elseif path:lower() == 'starttest' or path:lower() == 'starttest/' then
        if method == 'POST' then
            HTTPMethods.post(_ENV, AutoTestRESTHandler.startTest)
        else
            gf.sendError(_ENV)
        end
    elseif path:lower() == 'getstatus' or path:lower() == 'getstatus/' then
        if method == 'GET' then
            HTTPMethods.get(_ENV, AutoTestRESTHandler.getStatus)
        else
            gf.sendError(_ENV)
        end
    elseif path:match("getresult/[0-9]") then
        local typeTest = path:match("[0-9]")
        if method == 'GET' then
            HTTPMethods.get(_ENV, AutoTestRESTHandler.getResult, HTTPStatusCode.InternalServerError, typeTest)
        else
            gf.sendError(_ENV)
        end
    else
        gf.sendError(_ENV, HTTPStatusCode.BadRequest, ErrorCodes.DIAG_DOES_NOT_EXIST)
    end
end


function AutoTestRESTHandler.startTest(testType)
    testType = testType.testType
    if(testType) then
        local result, errorMsg = AutoTest.startTest(testType)
        if result then
            return ba.json.encode({result}), nil
        else
            return result, errorMsg
        end
    end

end

function AutoTestRESTHandler.getStatus()
    local status = AutoTest.getStatus()
    local result = {}
    local errorMsg = nil

    if(status) then
        result.status = status
    else
        errorMsg = ErrorObject.new(ErrorCodes.INVALID_RESPONSE_FROM_SERVER) 
    end
    return ba.json.encode(result), errorMsg
end

function AutoTestRESTHandler.getResult(testType)
    local test = testType
    local errorMsg = nil
    local result = AutoTest.getResult(test)
    result = ba.json.encode(result)
    return result, errorMsg
end

return AutoTestRESTHandler