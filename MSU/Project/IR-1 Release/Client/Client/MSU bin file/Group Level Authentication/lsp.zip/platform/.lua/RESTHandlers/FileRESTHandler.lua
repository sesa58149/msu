local FileRESTHandler = {}

function FileRESTHandler.getHandler(_ENV, path)
    local method = request:method()
    -- Ensure that the response is has a content type of JSON

	if (method == 'GET') then
		if (path) then
			local newPath = gf.split(path, '/');
			if newPath[1] == 'download' then
				FileRESTHandler.getThemeDL(_ENV, newPath[2])
			end
		end
	elseif (method == 'POST') then
		local userAgent = request:header('User-Agent');
		if FileSystem.UserAgentIsIE(userAgent) then
			response:setcontenttype('text/html; charset=UTF-8')
		else
			response:setcontenttype('application/json; charset=UTF-8')
		end
		if (path) then
			local newPath = gf.split(path, '/');
			if newPath[1] == 'logos' then
				FileSystem.handleUpload(_ENV, Constants.TEMP_UPLOAD_PATH, newPath[2], {logo = true})
			elseif newPath[1] == 'themes' then
				FileSystem.handleUpload(_ENV, Constants.TEMP_UPLOAD_PATH, newPath[2], {theme = true})
			else
				response:write(ba.json.encode({success = false, errorMsg = ErrorCodes.FILE_PATH_UNKNOWN}))
			end
		end
	else
		gf.sendError(_ENV, HTTPStatusCode.BadRequest, ErrorCodes.INVALID_REQUEST)
	end
end

function FileRESTHandler.getThemeDL(_ENV, themeName)
	local data, errorMsg = Theme.get(themeName)
	if not errorMsg then
		local d = ba.json.encode(data[1])
		response:setheader('Content-Disposition', 'attachment; filename="' .. themeName .. '.wtc"')
		response:setcontentlength(string.len(d))
		response:send(d)
	else
		gf.sendError(_ENV, HTTPStatusCode.BadRequest, ErrorCodes.INVALID_REQUEST)
	end
end

return FileRESTHandler