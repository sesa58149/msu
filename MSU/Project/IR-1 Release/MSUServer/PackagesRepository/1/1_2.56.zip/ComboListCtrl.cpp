/** @file ComboListCtrl.cpp
 *	<TABLE>
 *	@brief This file provides the class functionalities to populate 
 *         combo box within a list control
 *	@copy
 *	<TABLE>
 *	<TR><TD> Copyright </TD></TR>
 *	<TR>
 *	<TD>Schneider Electric India (Pvt) Ltd.
 *	Copyright (c) 2012 - All rights reserved.
 *	</TR>
 *	<TR>
 *	<TD> No part of this document may be reproduced in any form without the express
 * 	written consent of Schneider Electric India (Pvt) Ltd.</TD>
 *	</TR>
 *	</TABLE>
 *
 *	@par
 *	@author Arun Dhakshina
 *	@par HISTORY
 *
 *	<TABLE>
 *	<TR>
 *	<TD>Author</TD>		<TD>Date</TD>		<TD>Description</TD>
 *	</TR>
 *	<TR>
 *	<TD>Arun Dhakshina </TD>	<TD>29-Feb-2012</TD>	<TD>First creation</TD>
 *	</TR>
 *	</TABLE>
 *	</TABLE>
 *
 */

#include "stdafx.h"
#include "ComboListCtrl.h"
#include "InPlaceCombo.h"
#include "InPlaceEdit.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/**  @def FIRST_COLUMN 
*    @brief Macro to be defined for First Column (0)
*/
#define FIRST_COLUMN				0

/**  @def MIN_COLUMN_WIDTH
*    @brief Macro to be defined for Column Width (10)
*/
#define MIN_COLUMN_WIDTH			10

/**  @def MAX_DROP_DOWN_ITEM_COUNT
*    @brief Macro to be defined for Drop Down Item Count (10)
*/
#define MAX_DROP_DOWN_ITEM_COUNT	10

/////////////////////////////////////////////////////////////////////////////
// CComboListCtrl

/**  @fn CComboListCtrl( )
 *   @brief CComboListCtrl() is used as a constructor
 *   @details  CComboListCtrl() function is used to initialize the color properties for colrows 
 *             as well to overwrite the properties with windows specific style settings
 */
CComboListCtrl::CComboListCtrl()
{
	m_colRow1 = RGB(240,247,249);
	m_colRow2 = RGB(229,232,239);
	m_ComboSupportColumnsList.RemoveAll();
	m_ReadOnlyColumnsList.RemoveAll();
	m_strValidEditCtrlChars.Empty();
	m_dwEditCtrlStyle = ES_AUTOHSCROLL | ES_AUTOVSCROLL | ES_LEFT | ES_NOHIDESEL;
	m_dwDropDownCtrlStyle = WS_BORDER | WS_CHILD | WS_VISIBLE | ES_AUTOHSCROLL | ES_AUTOVSCROLL | 
							CBS_DROPDOWNLIST | CBS_DISABLENOSCROLL;
}

/**  @fn ~CComboListCtrl( )
 *   @brief ~CComboListCtrl() is used as a destructor
 *   @details  ~CComboListCtrl() function is used to delete the available instances
  */
CComboListCtrl::~CComboListCtrl()
{
	CInPlaceCombo::DeleteInstance();
	CInPlaceEdit::DeleteInstance();  
}


BEGIN_MESSAGE_MAP(CComboListCtrl, CListCtrl)
	//{{AFX_MSG_MAP(CComboListCtrl)
	ON_WM_ERASEBKGND()
	ON_NOTIFY_REFLECT(NM_CUSTOMDRAW, OnCustomDraw)
	ON_WM_HSCROLL()
	ON_WM_VSCROLL()
	ON_WM_LBUTTONDOWN()
	ON_NOTIFY_REFLECT(LVN_ENDLABELEDIT, OnEndLabelEdit)
	ON_NOTIFY_REFLECT(LVN_BEGINLABELEDIT, OnBeginLabelEdit)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CComboListCtrl message handlers

/**  @fn ShowInPlaceList( int iRowIndex, int iColumnIndex, CStringList& rComboItemsList, 
 *											   CString strCurSelecetion, int iSel )
 *   @brief ShowInPlaceList() creates and displays the in place combo box
 *   @details  ShowInPlaceList() function is used to create and display the in place combo box
 *             in the list control
 *   @param[in] : RowIndex - Row index of the list control
 *   @param[in] : ColumnIndex - Column index of the list control
 *   @param[in] : ComboItemsList - Pointer to the selected combo box control
 *   @param[in] : strCurSelecetion - Current string which was selected
 *   @return InPlaceCombo pointer descriptor if the operation is successful
 *           NULL pointer value if the operation is failed.
 *   @retval returns InPlaceCombo pointer descriptor ( integer value) if the operation is successful
 *   @retval 0 if failed 
 */
CInPlaceCombo* CComboListCtrl::ShowInPlaceList(int iRowIndex, int iColumnIndex, CStringList& rComboItemsList, 
											   CString strCurSelecetion /*= ""*/, int iSel /*= -1*/)
{
	// The returned obPointer should not be saved
	
	// Make sure that the item is visible
	if (!EnsureVisible(iRowIndex, TRUE))
	{
		return NULL;
	}

	// Make sure that iColumnIndex is valid 
	CHeaderCtrl* pHeader = static_cast<CHeaderCtrl*> (GetDlgItem(FIRST_COLUMN));

	int iColumnCount = pHeader->GetItemCount();

	if (iColumnIndex >= iColumnCount || GetColumnWidth(iColumnIndex) < MIN_COLUMN_WIDTH) 
	{
		return NULL;
	}

	// Calculate the rectangle specifications for the combo box
	CRect obCellRect(0, 0, 0, 0);
	CalculateCellRect(iColumnIndex, iRowIndex, obCellRect);

	int iHeight = obCellRect.Height();  
	int iCount = rComboItemsList.GetCount();

	iCount = (iCount < MAX_DROP_DOWN_ITEM_COUNT) ? 
		iCount + MAX_DROP_DOWN_ITEM_COUNT : (MAX_DROP_DOWN_ITEM_COUNT + 1); 

	obCellRect.bottom += iHeight * iCount; 

	// Create the in place combobox
	CInPlaceCombo* pInPlaceCombo = CInPlaceCombo::GetInstance();
	pInPlaceCombo->ShowComboCtrl(m_dwDropDownCtrlStyle, obCellRect, this, 0, iRowIndex, iColumnIndex, &rComboItemsList, 
								 strCurSelecetion, iSel);
	
	return pInPlaceCombo;
}

/**  @fn ShowInPlaceEdit( int iRowIndex, int iColumnIndex, CString& rstrCurSelection )
 *   @brief ShowInPlaceEdit() creates and displays the in place edit control
 *   @details  ShowInPlaceEdit() function is used to create and display the in place edit control
 *             in the list control
 *   @param[in] : RowIndex - Row index of the list control
 *   @param[in] : ColumnIndex - Column index of the list control
 *   @param[in] : strCurSelecetion - Current string which was selected
 *   @return InPlaceEdit pointer descriptor if the operation is successful           
 *   @retval returns InPlaceEdit pointer descriptor ( integer value) if the operation is successful
  */
CInPlaceEdit* CComboListCtrl::ShowInPlaceEdit(int iRowIndex, int iColumnIndex, CString& rstrCurSelection)
{
	// Create an in-place edit control
	CInPlaceEdit* pInPlaceEdit = CInPlaceEdit::GetInstance();
		
	CRect obCellRect(0, 0, 0, 0);
	CalculateCellRect(iColumnIndex, iRowIndex, obCellRect);
			
	pInPlaceEdit->ShowEditCtrl(m_dwEditCtrlStyle, obCellRect, this, 0, 
							   iRowIndex, iColumnIndex,
							   m_strValidEditCtrlChars, rstrCurSelection);

	return pInPlaceEdit;
}

/**  @fn OnHScroll( UINT iSBCode, UINT iPos, CScrollBar* pScrollBar )
 *   @brief OnHScroll() Sets the horizontal scroll
 *   @details  OnHScroll() function overrides the default OnHScroll function
 *   @param[in] : iSBCode - Specifies a scroll-bar code that indicates the scrolling request of the user
 *   @param[in] : iPos - Specifies the scroll-box position if the scroll-bar code is 
 *				  SB_THUMBPOSITION or SB_THUMBTRACK; otherwise, it is not used
 *   @param[in] : pScrollBar - If the scroll message came from a scroll-bar control, contains a pointer to the control
  */
void CComboListCtrl::OnHScroll(UINT iSBCode, UINT iPos, CScrollBar* pScrollBar) 
{
	// TODO: Add your message handler code here and/or call default

	if (GetFocus() != this)
	{
		SetFocus();
	}

	CListCtrl::OnHScroll(iSBCode, iPos, pScrollBar);
}

/**  @fn OnVScroll( UINT iSBCode, UINT iPos, CScrollBar* pScrollBar )
 *   @brief OnVScroll() Sets the vertical scroll
 *   @details  OnVScroll() function overrides the default OnVScroll function
 *   @param[in] : iSBCode - Specifies a scroll-bar code that indicates a scrolling request by the user
 *   @param[in] : iPos - Specifies the scroll-box position if the scroll-bar code is 
 *				  SB_THUMBPOSITION or SB_THUMBTRACK; otherwise, it is not used
 *   @param[in] : pScrollBar - If the scroll message came from a scroll-bar control, contains a pointer to the control
  */
void CComboListCtrl::OnVScroll(UINT iSBCode, UINT iPos, CScrollBar* pScrollBar) 
{
	// TODO: Add your message handler code here and/or call default

	if (GetFocus() != this)
	{
		SetFocus();
	}

	CListCtrl::OnVScroll(iSBCode, iPos, pScrollBar);
}

/**  @fn OnLButtonDown( UINT iFlags, CPoint obPoint )
 *   @brief OnHScroll() This method is called by the framework when the user presses the left mouse button
 *   @details  OnHScroll() function overrides the default on left mouse button clicked event
 *   @param[in] : iFlags - Indicates whether various virtual keys are down by setting appropriate flags
 *   @param[in] : obPoint - Specifies the x- and y-coordinate of the cursor 
  */
void CComboListCtrl::OnLButtonDown(UINT iFlags, CPoint obPoint) 
{
	// TODO: Add your message handler code here and/or call default

	int iColumnIndex = -1;
	int iRowIndex = -1;

	// Get the current column and row
	if (!HitTestEx(obPoint, &iRowIndex, &iColumnIndex))
	{
		return;
	}

	CListCtrl::OnLButtonDown(iFlags, obPoint);
	
	// If column is not read only then
	// If the SHIFT or CTRL key is down call the base class
	// Check the high bit of GetKeyState to determine whether SHIFT or CTRL key is down
	if ((GetKeyState(VK_SHIFT) & 0x80) || (GetKeyState(VK_CONTROL) & 0x80))
	{
		return;
	}

	// Get the current selection before creating the in place combo box
	CString strCurSelection = GetItemText(iRowIndex, iColumnIndex);
	
	if (-1 != iRowIndex)
	{
		UINT flag = LVIS_FOCUSED;
		
		if ((GetItemState(iRowIndex, flag ) & flag) == flag)
		{
			// Add check for LVS_EDITLABELS
			if (GetWindowLong(m_hWnd, GWL_STYLE) & LVS_EDITLABELS)
			{
				// If combo box is supported
				// Create and show the in place combo box
				if (IsCombo(iColumnIndex))
				{
					CStringList obComboItemsList;
										
					GetParent()->SendMessage(WM_SET_ITEMS, (WPARAM)iColumnIndex, (LPARAM)&obComboItemsList);  
					
					CInPlaceCombo* pInPlaceComboBox = ShowInPlaceList(iRowIndex, iColumnIndex, obComboItemsList, strCurSelection);
					ASSERT(pInPlaceComboBox); 
					
					// Set the selection to previous selection
					pInPlaceComboBox->SelectString(-1, strCurSelection);
				}
				// If combo box is not read only
				// Create and show the in place edit control
				else if (!IsReadOnly(iColumnIndex))
				{
					CInPlaceEdit* pInPlaceEdit = ShowInPlaceEdit(iRowIndex, iColumnIndex, strCurSelection);
				}
			}
		}
	}  
}

/**  @fn HitTestEx( CPoint &obPoint, int* pRowIndex, int* pColumnIndex )
 *   @brief HitTestEx() Returns the row & column index of the column on which mouse click event has occured
 *   @details  HitTestEx() function overrides the default on left mouse button clicked event
 *   @param[in] : obPoint - Specifies the x and y coordinates of the cursor 
 *   @param[in] : pRowIndex - Pointer which will get the updated row index information
 *   @param[in] : pColumnIndex - Pointer which will get the updated column index information
 *	 @return	: will return true if the operation is successful else false if the operation failed
  */
bool CComboListCtrl::HitTestEx(CPoint &obPoint, int* pRowIndex, int* pColumnIndex) const
{
	if (!pRowIndex || !pColumnIndex)
	{
		return false;
	}

	// Get the row index
	*pRowIndex = HitTest(obPoint, NULL);

	if (pColumnIndex)
	{
		*pColumnIndex = 0;
	}

	// Make sure that the ListView is in LVS_REPORT
	if ((GetWindowLong(m_hWnd, GWL_STYLE) & LVS_TYPEMASK) != LVS_REPORT)
	{
		return false;
	}

	// Get the number of columns
	CHeaderCtrl* pHeader = (CHeaderCtrl*)GetDlgItem(0);

	int iColumnCount = pHeader->GetItemCount();

	// Get bounding rect of item and check whether obPoint falls in it.
	CRect obCellRect;
	GetItemRect(*pRowIndex, &obCellRect, LVIR_BOUNDS);
	
	if (obCellRect.PtInRect(obPoint))
	{
		// Now find the column
		for (*pColumnIndex = 0; *pColumnIndex < iColumnCount; (*pColumnIndex)++)
		{
			int iColWidth = GetColumnWidth(*pColumnIndex);
			
			if (obPoint.x >= obCellRect.left && obPoint.x <= (obCellRect.left + iColWidth))
			{
				return true;
			}
			obCellRect.left += iColWidth;
		}
	}
	return false;
}

/**  @fn SetComboColumns( int iColumnIndex, bool bSet )
 *   @brief SetComboColumns() Sets/Resets the column which support the in place combo box
 *   @details  SetComboColumns() function Sets/Resets the column which support the in place combo box
 *   @param[in] : iColumnIndex - Specifies the column index
 *   @param[in] : bSet - sets or resets the combo in the respective column specified
  */
void CComboListCtrl::SetComboColumns(int iColumnIndex, bool bSet /*= true*/)
{
	// If the Column Index is not present && Set flag is false
	// Then do nothing 
	// If the Column Index is present && Set flag is true
	// Then do nothing
	POSITION Pos = m_ComboSupportColumnsList.Find(iColumnIndex);

	// If the Column Index is not present && Set flag is true
	// Then Add to list
	if ((NULL == Pos) && bSet) 
	{
		m_ComboSupportColumnsList.AddTail(iColumnIndex); 
	}

	// If the Column Index is present && Set flag is false
	// Then Remove from list
	if ((NULL != Pos) && !bSet) 
	{
		m_ComboSupportColumnsList.RemoveAt(Pos); 
	}
}

/**  @fn SetReadOnlyColumns( int iColumnIndex, bool bSet )
 *   @brief SetReadOnlyColumns() Sets/Resets the column which support the in place edit control
 *   @details  SetReadOnlyColumns() Sets/Resets the column which support the in place edit control
 *   @param[in] : iColumnIndex - Specifies the column index
 *   @param[in] : bSet - sets or resets the read only property in the respective column specified
  */
void CComboListCtrl::SetReadOnlyColumns(int iColumnIndex, bool bSet /*= true*/)
{
	// If the Column Index is not present && Set flag is false
	// Then do nothing 
	// If the Column Index is present && Set flag is true
	// Then do nothing
	POSITION Pos = m_ReadOnlyColumnsList.Find(iColumnIndex);

	// If the Column Index is not present && Set flag is true
	// Then Add to list
	if ((NULL == Pos) && bSet) 
	{
		m_ReadOnlyColumnsList.AddTail(iColumnIndex); 
	}

	// If the Column Index is present && Set flag is false
	// Then Remove from list
	if ((NULL != Pos) && !bSet) 
	{
		m_ReadOnlyColumnsList.RemoveAt(Pos); 
	}
}

/**  @fn IsReadOnly( int iColumnIndex )
 *   @brief IsReadOnly() Checks whether column is read only
 *   @details  IsReadOnly() Checks whether column is read only
 *   @param[in] : iColumnIndex - Specifies the column index
 *	 @return	: will return true if the operation is successful else false if the operation failed
  */
bool CComboListCtrl::IsReadOnly(int iColumnIndex)
{
	if (m_ReadOnlyColumnsList.Find(iColumnIndex))
	{
		return true;
	}
	
	return false;
}

/**  @fn IsCombo( int iColumnIndex )
 *   @brief IsCombo() Checks whether column supports in place combo box
 *   @details  IsCombo() Checks whether column supports in place combo box
 *   @param[in] : iColumnIndex - Specifies the column index
 *	 @return	: will return true if the operation is successful else false if the operation failed
  */
bool CComboListCtrl::IsCombo(int iColumnIndex)
{
	if (m_ComboSupportColumnsList.Find(iColumnIndex))
	{
		return true;
	}

	return false;
}

/**  @fn CalculateCellRect( int iColumnIndex, int iRowIndex, CRect& robCellRect )
 *   @brief CalculateCellRect() Calculates the cell rect
 *   @details  CalculateCellRect() Checks whether column supports in place combo box
 *   @param[in] : iColumnIndex - Specifies the column index
 *   @param[in] : iRowIndex - Specifies the row index
 *   @param[in] : robCellRect - updates the address with the updated value
  */
void CComboListCtrl::CalculateCellRect(int iColumnIndex, int iRowIndex, CRect& robCellRect)
{
	GetItemRect(iRowIndex, &robCellRect, LVIR_BOUNDS);
	
	CRect rcClient;
	GetClientRect(&rcClient);

	if (robCellRect.right > rcClient.right) 
	{
		robCellRect.right = rcClient.right;
	}

	ScrollToView(iColumnIndex, robCellRect); 
}

/**  @fn OnEndLabelEdit( NMHDR* pNMHDR, LRESULT* pResult )
 *   @brief OnEndLabelEdit() Update the item text with the new text
 *   @details  OnEndLabelEdit() Update the item text with the new text
 *   @param[in] : pNMHDR - This structure contains information about a notification message
 *   @param[in] : pResult - A 32-bit value returned from a window procedure or callback function
  */
void CComboListCtrl::OnEndLabelEdit(NMHDR* pNMHDR, LRESULT* pResult) 
{
	LV_DISPINFO* pDispInfo = (LV_DISPINFO*)pNMHDR;
	// TODO: Add your control notification handler code here
	
	// Update the item text with the new text
	SetItemText(pDispInfo->item.iItem, pDispInfo->item.iSubItem, pDispInfo->item.pszText);

	GetParent()->SendMessage(WM_VALIDATE, GetDlgCtrlID(), (LPARAM)pDispInfo); 
	
	*pResult = 0;
}

/**  @fn SetValidEditCtrlCharacters( CString &rstrValidCharacters )
 *   @brief SetValidEditCtrlCharacters() Sets the valid characters for the edit ctrl
 *   @details  SetValidEditCtrlCharacters() Sets the valid characters for the edit ctrl
 *   @param[in] : rstrValidCharacters - CString value which needs to be evaluated
  */
void CComboListCtrl::SetValidEditCtrlCharacters(CString &rstrValidCharacters)
{
	m_strValidEditCtrlChars = rstrValidCharacters;
}

/**  @fn EnableHScroll( bool bEnable )
 *   @brief EnableHScroll() Sets the horizontal scroll
 *   @details  EnableHScroll() Sets the horizontal scroll
 *   @param[in] : bEnable - TRUE to enable or FALSE to disable
  */
void CComboListCtrl::EnableHScroll(bool bEnable /*= true*/)
{
	if (bEnable)
	{
		m_dwDropDownCtrlStyle |= WS_HSCROLL;
	}
	else
	{
		m_dwDropDownCtrlStyle &= ~WS_HSCROLL;
	}	
}

/**  @fn EnableVScroll( bool bEnable )
 *   @brief EnableVScroll() Sets the vertical scroll
 *   @details  EnableVScroll() Sets the vertical scroll
 *   @param[in] : bEnable - TRUE to enable or FALSE to disable
  */
void CComboListCtrl::EnableVScroll(bool bEnable /*= true*/)
{
	if (bEnable)
	{
		m_dwDropDownCtrlStyle |= WS_VSCROLL;
	}
	else
	{
		m_dwDropDownCtrlStyle &= ~WS_VSCROLL;
	}
}

/**  @fn ScrollToView( int iColumnIndex, CRect& robCellRect )
 *   @brief ScrollToView() Scrolls the list ctrl to bring the in place ctrl to the view
 *   @details  ScrollToView() Scrolls the list ctrl to bring the in place ctrl to the view
 *   @param[in] : iColumnIndex - Specifies the column index
 *   @param[in] : robCellRect -  CRect contains member variables that define the top-left 
 *				  and bottom-right points of a rectangle
  */
void CComboListCtrl::ScrollToView(int iColumnIndex, /*int iOffSet, */CRect& robCellRect)
{
	// Now scroll if we need to expose the column
	CRect rcClient;
	GetClientRect(&rcClient);

	int iColumnWidth = GetColumnWidth(iColumnIndex);

	// Get the column iOffset
	int iOffSet = 0;
	for (int iIndex_ = 0; iIndex_ < iColumnIndex; iIndex_++)
	{
		iOffSet += GetColumnWidth(iIndex_);
	}

	// If x1 of cell rect is < x1 of ctrl rect or
	// If x1 of cell rect is > x1 of ctrl rect or **Should not ideally happen**
	// If the width of the cell extends beyond x2 of ctrl rect then
	// Scroll

	CSize obScrollSize(0, 0);

	if (((iOffSet + robCellRect.left) < rcClient.left) || 
		((iOffSet + robCellRect.left) > rcClient.right))
	{
		obScrollSize.cx = iOffSet + robCellRect.left;
	}
	else if ((iOffSet + robCellRect.left + iColumnWidth) > rcClient.right)
	{
		obScrollSize.cx = iOffSet + robCellRect.left + iColumnWidth - rcClient.right;
	}

	Scroll(obScrollSize);
	robCellRect.left -= obScrollSize.cx;
	
	// Set the width to the column width
	robCellRect.left += iOffSet;
	robCellRect.right = robCellRect.left + iColumnWidth;
}

/**  @fn OnBeginLabelEdit( NMHDR* pNMHDR, LRESULT* pResult )
 *   @brief OnBeginLabelEdit() Message handler to the window for editing
 *   @details  OnBeginLabelEdit() Message handler to the window for editing, will not 
 *			   update if the windows is readonly
 *   @param[in] : pNMHDR - This structure contains information about a notification message
 *   @param[in] : pResult - A 32-bit value returned from a window procedure or callback function
  */
void CComboListCtrl::OnBeginLabelEdit(NMHDR* pNMHDR, LRESULT* pResult) 
{
	LV_DISPINFO* pDispInfo = (LV_DISPINFO*)pNMHDR;
	// TODO: Add your control notification handler code here
	if (IsReadOnly(pDispInfo->item.iSubItem))
	{
		*pResult = 1;
		return;
	}

	*pResult = 0;
}

/**  @fn OnCustomDraw( NMHDR* pNMHDR, LRESULT* pResult )
 *   @brief OnCustomDraw() Modify item text / sub item text and or background
 *   @details  OnCustomDraw() Message handler to the window for Modify item text / 
 *			   sub item text and or background
 *   @param[in] : pNMHDR - This structure contains information about a notification message
 *   @param[in] : pResult - A 32-bit value returned from a window procedure or callback function
  */
void CComboListCtrl::OnCustomDraw(NMHDR* pNMHDR, LRESULT* pResult)
{
  *pResult = 0;

  LPNMLVCUSTOMDRAW  lplvcd = (LPNMLVCUSTOMDRAW)pNMHDR;
  int iRow = lplvcd->nmcd.dwItemSpec;

  switch(lplvcd->nmcd.dwDrawStage)
  {
    case CDDS_PREPAINT :
    {
      *pResult = CDRF_NOTIFYITEMDRAW;
      return;
    }

    // Modify item text and or background
    case CDDS_ITEMPREPAINT:
    {
      lplvcd->clrText = RGB(0,0,0);
      // If you want the sub items the same as the item,
      // set *pResult to CDRF_NEWFONT
      *pResult = CDRF_NOTIFYSUBITEMDRAW;
      return;
    }

    // Modify sub item text and/or background
    case CDDS_SUBITEM | CDDS_PREPAINT | CDDS_ITEM:
    {
		
        if(iRow %2){
         lplvcd->clrTextBk = m_colRow2;
        }
        else{
          lplvcd->clrTextBk = m_colRow1;
        }
		

        *pResult = CDRF_DODEFAULT;
        return;
    }
  }
}

/**  @fn OnEraseBkgnd( CDC* pDC) )
 *   @brief OnEraseBkgnd() Modify display context associated with the client area of a window
 *   @details  OnEraseBkgnd() Message handler to the display context associated with the client area of a window
 *   @param[in] : pDC - CDC object provides member functions for working with a device context, such as a display or printer, 
 *			      as well as members for working with a display context associated with the client area of a window.
 *   @return	: will return TRUE if operation successful else FALSE if failed
  */
BOOL CComboListCtrl::OnEraseBkgnd(CDC* pDC) 
{
	// TODO: Add your message handler code here and/or call default
	
  CRect rect;
  CComboListCtrl::GetClientRect(rect);


  POINT mypoint;  
  
  CBrush brush0(m_colRow1);
  CBrush brush1(m_colRow2);


 
 int chunk_height=GetCountPerPage();
 pDC->FillRect(&rect,&brush1);

 for (int i=0;i<=chunk_height;i++)
 {
		
	
	GetItemPosition(i,&mypoint);
	rect.top=mypoint.y ;
	GetItemPosition(i+1,&mypoint);
	rect.bottom =mypoint.y;
	pDC->FillRect(&rect,i %2 ? &brush1 : &brush0);


 }

  brush0.DeleteObject();
  brush1.DeleteObject();

  return FALSE;
}
