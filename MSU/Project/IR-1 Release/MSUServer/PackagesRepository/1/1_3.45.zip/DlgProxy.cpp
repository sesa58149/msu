/** @file DlgProxy.cpp
 *	<TABLE>
 *	@brief This file provides the MFC dialog functions w.r.to windows properties
 *	@copy
 *	<TABLE>
 *	<TR><TD> Copyright </TD></TR>
 *	<TR>
 *	<TD>Schneider Electric India (Pvt) Ltd.
 *	Copyright (c) 2012 - All rights reserved.
 *	</TR>
 *	<TR>
 *	<TD> No part of this document may be reproduced in any form without the express
 * 	written consent of Schneider Electric India (Pvt) Ltd.</TD>
 *	</TR>
 *	</TABLE>
 *
 *	@par
 *	@author Arun Dhakshina
 *	@par HISTORY
 *
 *	<TABLE>
 *	<TR>
 *	<TD>Author</TD>		<TD>Date</TD>		<TD>Description</TD>
 *	</TR>
 *	<TR>
 *	<TD>Arun Dhakshina </TD>	<TD>29-Feb-2012</TD>	<TD>First creation</TD>
 *	</TR>
 *	</TABLE>
 *	</TABLE>
 *
 */

#include "stdafx.h"
#include "MSU_SERVER.h"
#include "DlgProxy.h"
#include "MSU_SERVERDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMSU_SERVERDlgAutoProxy

IMPLEMENT_DYNCREATE(CMSU_SERVERDlgAutoProxy, CCmdTarget)

CMSU_SERVERDlgAutoProxy::CMSU_SERVERDlgAutoProxy()
{
	EnableAutomation();
	
	// To keep the application running as long as an automation 
	//	object is active, the constructor calls AfxOleLockApp.
	AfxOleLockApp();

	// Get access to the dialog through the application's
	//  main window pointer.  Set the proxy's internal pointer
	//  to point to the dialog, and set the dialog's back pointer to
	//  this proxy.
	ASSERT (AfxGetApp()->m_pMainWnd != NULL);
	ASSERT_VALID (AfxGetApp()->m_pMainWnd);
	ASSERT_KINDOF(CMSU_SERVERDlg, AfxGetApp()->m_pMainWnd);
	m_pDialog = (CMSU_SERVERDlg*) AfxGetApp()->m_pMainWnd;
	m_pDialog->m_pAutoProxy = this;
}

CMSU_SERVERDlgAutoProxy::~CMSU_SERVERDlgAutoProxy()
{
	// To terminate the application when all objects created with
	// 	with automation, the destructor calls AfxOleUnlockApp.
	//  Among other things, this will destroy the main dialog
	if (m_pDialog != NULL)
		m_pDialog->m_pAutoProxy = NULL;
	AfxOleUnlockApp();
}

void CMSU_SERVERDlgAutoProxy::OnFinalRelease()
{
	// When the last reference for an automation object is released
	// OnFinalRelease is called.  The base class will automatically
	// deletes the object.  Add additional cleanup required for your
	// object before calling the base class.

	CCmdTarget::OnFinalRelease();
}

BEGIN_MESSAGE_MAP(CMSU_SERVERDlgAutoProxy, CCmdTarget)
	//{{AFX_MSG_MAP(CMSU_SERVERDlgAutoProxy)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

BEGIN_DISPATCH_MAP(CMSU_SERVERDlgAutoProxy, CCmdTarget)
	//{{AFX_DISPATCH_MAP(CMSU_SERVERDlgAutoProxy)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_DISPATCH_MAP
END_DISPATCH_MAP()

// Note: we add support for IID_IMSU_SERVER to support typesafe binding
//  from VBA.  This IID must match the GUID that is attached to the 
//  dispinterface in the .ODL file.

// {56B7D2B9-8112-44D2-BA5A-2A28D278D371}
static const IID IID_IMSU_SERVER =
{ 0x56b7d2b9, 0x8112, 0x44d2, { 0xba, 0x5a, 0x2a, 0x28, 0xd2, 0x78, 0xd3, 0x71 } };

BEGIN_INTERFACE_MAP(CMSU_SERVERDlgAutoProxy, CCmdTarget)
	INTERFACE_PART(CMSU_SERVERDlgAutoProxy, IID_IMSU_SERVER, Dispatch)
END_INTERFACE_MAP()

// The IMPLEMENT_OLECREATE2 macro is defined in StdAfx.h of this project
// {FF5A873C-62A3-41CC-8194-3370FBE34F85}
IMPLEMENT_OLECREATE2(CMSU_SERVERDlgAutoProxy, "MSU_SERVER.Application", 0xff5a873c, 0x62a3, 0x41cc, 0x81, 0x94, 0x33, 0x70, 0xfb, 0xe3, 0x4f, 0x85)

/////////////////////////////////////////////////////////////////////////////
// CMSU_SERVERDlgAutoProxy message handlers
